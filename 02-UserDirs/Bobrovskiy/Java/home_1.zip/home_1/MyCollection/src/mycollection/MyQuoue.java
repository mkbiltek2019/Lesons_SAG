package mycollection;

/**
 *
 * @author Администратор
 */
import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;

class MyQueue implements Queue
{
    private Object[] array;
    private int maxIndex;
    volatile private int head;
    volatile private int tail;

    public MyQueue(int amount)
    {
        array = new Object[amount];
        maxIndex = amount - 1;
        head = 0;
        tail = 0;
    }

    synchronized public void put(Object obj)
    {
        if (addValue(head) != tail)
        {
            head = addValue(head);
            array[head] = obj;
        } else
        {
            throw new RuntimeException("Queue overloaded");
        }
    }

    public Object get()
    {
        Object result = null;

        if (tail != head)
        {
            result = array[tail];
            tail = addValue(tail);            
        }
        
        return result;
    }

    private int addValue(int value)
    {
        if (value == maxIndex)
        {
            value = 0;
        } else
        {
            value++;
        }
        
        return value;
    }

    public boolean add(Object e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean offer(Object e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object remove() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object poll() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object element() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object peek() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int size() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean contains(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Iterator iterator() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object[] toArray() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object[] toArray(Object[] a) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean remove(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean containsAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean addAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean removeAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean retainAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void clear() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
