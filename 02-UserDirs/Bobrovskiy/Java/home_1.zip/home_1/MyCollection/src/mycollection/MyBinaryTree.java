package mycollection;

/**
 *
 * @author Администратор
 */
import java.util.TreeSet;

public class MyBinaryTree extends  TreeSet
{ 
    private Node root;

    public void BinaryTree(int value)
    {      
        this.root = new Node(value);
    }

    public void add(int value)
    {
        insert(this.root, value);
    }

    private void insert(Node node, int value)
    {
    if (value < node.value)
    {
      if (node.left != null)
      {
        insert(node.left, value);
      }
      else
      {       
        node.left = new Node(value);
      }
    }
    else if (value > node.value)
    {
      if (node.right != null)
      {
        insert(node.right, value);
      }
      else
      {
         node.right = new Node(value);
      }
    }
  }

  public void printTree()
  {
    consolePrintInOrder(this.root);
  }

  private void consolePrintInOrder(Node node)
  {
    if (node != null)
    {
      consolePrintInOrder(node.left);
      System.out.println("  Traversed " + node.value);
      consolePrintInOrder(node.right);
    }
  }  

}
