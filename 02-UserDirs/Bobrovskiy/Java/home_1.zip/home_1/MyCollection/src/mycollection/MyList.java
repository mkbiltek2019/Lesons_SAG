package mycollection;

/**
 *
 * @author Администратор
 * sample
 *
public class MyList
{
    private int element;
    private MyList next;

    public int getElement()
    {
        return element;
    }

    public void setElement(int e)
    {
        element = e;
    }

    public MyList getNext()
    {
        return next;
    }

    public void setNext(MyList n)
    {
        next = n;
    }

}
 */
//
//public class MyList
//{
//    private Node head;
//    private Node tail;
//    private int count;
//
//    private int search(int value)
//    {
//        return 0;
//    }
//
//    public MyList()
//    {
//        head = null;
//        tail = null;
//        count = 0;
//    }
//
//    public void addHead(Node node)
//    {
//        if (this.head !=null)
//	{
//            node.left = head;
//            node.right = null;
//            this.head.right = node;
//            this.head = node;
//	}
//	else
//	{
//            node.left = null;
//            node.right = null;
//            this.head = node;
//            this.tail = node;
//	}
//
//	this.count++;
//    }
//
//    public void addTail(Node node)
//    {
//         if (this.tail !=null)
//	{
//            node.left = tail;
//            node.right = null;
//            this.tail.right = node;
//            this.tail = node;
//	}
//	else
//	{
//            node.left = null;
//            node.right = null;
//            this.head = node;
//            this.tail = node;
//	}
//
//        this.count++;
//    }
//
//    public void insert(Node node, int position)
//    {
//        if (position == 0)
//	{
//		addHead(node);
//	}
//	else if (position == count)
//	{
//		addTail(node);
//	}
//	else if (position > 0 && position < count)
//	{
//		Node curentNode = this.head;
//
//		for (int i = 1; i < position; i++)
//                {
//                    curentNode = curentNode.left;
//                }
//
//		curentNode.left.right = node;
//		node.left = curentNode.left;
//		node.right = curentNode;
//		curentNode.left = node;
//
//		this.count++;
//	}
//    }
//
//    public void delete(int value)
//    {
//        Node curentNode = this.head;
//
//        Node  currentNode = this.head;
//	if (currentNode!=null)
//	{
//            while (currentNode == currentNode.left)
//            {
//                if(currentNode.left.getValue()==value)
//                {
//                    if(currentNode.left ==this.head)
//                    {
//                        //delete head
//                    }else
//                    if(currentNode.left ==this.tail)
//                    {
//                      //delete tail
//                    }
//                    else
//                    {
//                       //delete middle
//                    }
//
//                }
//            }
//        }
//
//        this.count--;
//    }
//
//    public void clear(Node node)
//    {
//        Node  currentNode = this.head;
//	if (currentNode!=null)
//	{
//            while (currentNode == currentNode.left)
//            {
//                currentNode.right = null;
//            }
//
//            this.tail = null;
//            this.head = null;
//            count = 0;
//	}
//    }
//
//    public void consolePrint()
//    {
//        Node  currentNode = this.head;
//
//	if (this.head==null)
//        {
//	   throw new RuntimeException("List are Empty.");
//        }
//
//	while (currentNode!=null)
//	{
//            System.out.println("  Traversed " + currentNode.value);
//            currentNode = currentNode.left;
//	}
//    }
//
//}
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class MyList implements List
{
    public int size() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean contains(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Iterator iterator() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object[] toArray() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object[] toArray(Object[] a) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean add(Object e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean remove(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean containsAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean addAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean addAll(int index, Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean removeAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean retainAll(Collection c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void clear() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object get(int index) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object set(int index, Object element) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void add(int index, Object element) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Object remove(int index) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int indexOf(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int lastIndexOf(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public ListIterator listIterator() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public ListIterator listIterator(int index) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public List subList(int fromIndex, int toIndex) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}