/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mycollection;

/**
 *
 * @author Администратор
 */
public class Node
{
    public Node left;
    public Node right;
    int value;

    public Node(int value)
    {
        this.value = value;
    }

    public int getValue()
    {
        return this.value;
    }
}
