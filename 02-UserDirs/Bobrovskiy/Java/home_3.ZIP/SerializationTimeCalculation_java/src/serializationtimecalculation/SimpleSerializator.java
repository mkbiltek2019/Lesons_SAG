package serializationtimecalculation;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author Администратор
 */
public class SimpleSerializator {

    private Person person;
        
    public SimpleSerializator() {
        person = new Person();
        person.Name = "Petro";
        person.age = 23;
        person.salary = 1000;
        person.weight = 80.6;
    }

    public void Serialize() throws IOException {
        ByteArrayOutputStream byteArrayoutputStream =
                new ByteArrayOutputStream();

        ObjectOutputStream objectOutputStream =
                new ObjectOutputStream(byteArrayoutputStream);

        objectOutputStream.writeObject(person);

        objectOutputStream.close();
        byteArrayoutputStream.close();
    }
}
