/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package serializationtimecalculation;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

/**
 *
 * @author Администратор
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, IOException
    {
        final int repeatTime = 10000000;//10000000;

        TimeCalculator myTimer = new TimeCalculator();
       
        System.out.println("Please wait untile processe are finish!!!");

        double result = 
                myTimer.CalculateAvarageExecutionTimeOfMethod(repeatTime);

          //MessageFormater format = "After repeate {0} times \n Average serialization time is: {1} in .NET.";

        System.out.print("Result: ");
        System.out.print(result);
        System.out.println("\n");
    }

}
