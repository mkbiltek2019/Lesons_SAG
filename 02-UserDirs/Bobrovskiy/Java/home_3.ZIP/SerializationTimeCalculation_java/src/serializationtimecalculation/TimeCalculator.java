package serializationtimecalculation;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

/**
 *
 * @author Администратор
 */
public class TimeCalculator
{
  private long start;
  private long end;

  private SimpleSerializator serializator = new SimpleSerializator();

  public TimeCalculator() {
    reset();
  }

  public void start() {
    start = System.nanoTime();
  }

  public void end() {
    end = System.nanoTime();
  }

  public long duration(){
    return (end-start);
  }

  public final void reset() {
    start = 0;
    end   = 0;
  }

  public double CalculateAvarageExecutionTimeOfMethod(int repeatTime)
          throws IllegalAccessException, InvocationTargetException, IOException
  {
      double result = 0;
      final double convertValue = (double)1/(double)1000000;

      for(int i=0; i<repeatTime; i++)
      {
        this.start();
        serializator.Serialize();
        this.end();
       // System.out.println(this.duration());
        result += this.duration()*convertValue;
        
        this.reset();
      }     

     return(double)(result/(double)repeatTime);
  }
  

}
