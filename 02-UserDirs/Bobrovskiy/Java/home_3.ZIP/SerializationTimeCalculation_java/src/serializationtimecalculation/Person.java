package serializationtimecalculation;

import java.io.Serializable;
/**
 *
 * @author Администратор
 */
public class Person implements Serializable
{
    public int age;
    public int salary;
    public double weight;
    public String Name;

}
