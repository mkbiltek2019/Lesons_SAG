﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SerializationTime_Checker_for.NET
{
    public class SimpleSerializator
    {
        private Person person;

        public SimpleSerializator()
        {
            person = new Person() { 
            age = 23, 
            Name = "Petro",
            salary = 1000,
            weight = 80.6};
        }

        public void Serialize()
        {
            Stream stream = new MemoryStream();
            BinaryFormatter bformatter = new BinaryFormatter();
         
            bformatter.Serialize(stream, person);
            stream.Close();
        }
    }
}
