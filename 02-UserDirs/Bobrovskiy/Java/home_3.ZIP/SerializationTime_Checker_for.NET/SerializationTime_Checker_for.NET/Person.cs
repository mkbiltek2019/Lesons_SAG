﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SerializationTime_Checker_for.NET
{
    [Serializable]
    public class Person
    {
        public int age;
        public int salary;
        public double weight;
        public string Name;
    }
}
