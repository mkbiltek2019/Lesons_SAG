﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace SerializationTime_Checker_for.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            const int repeatTime = 1000000;//10000000;

            TimeCalculator myTimer = new TimeCalculator();
            SimpleSerializator serializator = new SimpleSerializator();

            System.Console.WriteLine("Please wait untile processe are finish!!!");

            double result = myTimer.CalculateAvarageExecutionTimeOfMethod(repeatTime, serializator.Serialize);

            string format = "After repeate {0} times \n Average serialization time is: {1} in .NET.";

            System.Console.WriteLine(format, repeatTime, result);
            System.Console.ReadKey();
        }
    }
}
