﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace SerializationTime_Checker_for.NET
{
    public class TimeCalculator
    {
        private Stopwatch stopWatch = new Stopwatch();

        public double CalculateAvarageExecutionTimeOfMethod(int repeatTime, Action method)
        {
            double time = 0;

            for (int i = 0; i < repeatTime; i++ )
            {                
                stopWatch.Start();
                
                method.Invoke();

                stopWatch.Stop();

                time += stopWatch.Elapsed.TotalMilliseconds;
                
                stopWatch.Reset();
            }

            return (time/(double)repeatTime);
        }
    }
}
