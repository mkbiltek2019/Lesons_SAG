package activerecord;

import Business.TicketBookingSystem;

/**
 *
 * @author Администратор
 */
public class Main
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        final int customerId = 1;
        final int ticketId = 2;

        TicketBookingSystem bookingSystem = new TicketBookingSystem();

        bookingSystem.BookTicket(customerId, ticketId);

        System.out.print("-------");
    }
}
