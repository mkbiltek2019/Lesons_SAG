/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package activerecord.database;

import Abstraction.Identity;

/**
 *
 * @author Администратор
 */
public class TicketDB extends Identity
{    
    private double ticketPrice;
    private int customerId;
    final int defaultId = -1;

    public TicketDB(int id, double ticketPrice)
    {
        super(id);
        this.ticketPrice = ticketPrice;
        this.customerId = defaultId;
    }   

    /**
     * @return the ticketPrice
     */
    public double getTicketPrice() {
        return ticketPrice;
    }

    /**
     * @param ticketPrice the ticketPrice to set
     */
    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    /**
     * @return the customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
}
