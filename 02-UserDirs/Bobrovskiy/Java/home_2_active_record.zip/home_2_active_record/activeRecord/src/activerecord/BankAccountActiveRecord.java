/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package activerecord;

import Abstraction.ActiveRecord;
import activerecord.database.BankAccountCollectionDB;
import activerecord.database.BankAccountDB;

/**
 *
 * @author Администратор
 */
public final class BankAccountActiveRecord extends
        ActiveRecord<BankAccountDB, BankAccountCollectionDB>
{
   BankAccountCollectionDB collection = new BankAccountCollectionDB();
   
   public BankAccountActiveRecord(int id)
   {
      super.instantiate(id, this.collection);
   }

   public void withDrawMoney(double value)
   {
     this.getActiveRecord().setBalance(
             this.getActiveRecord().getBalance()- value);
   }
}
