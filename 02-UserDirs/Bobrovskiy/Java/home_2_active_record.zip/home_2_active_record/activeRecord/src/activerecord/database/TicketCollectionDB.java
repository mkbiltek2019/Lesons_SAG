/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package activerecord.database;

import Abstraction.DBOperator;
import java.util.ArrayList;

/**
 *
 * @author Администратор
 */
public class TicketCollectionDB extends DBOperator<TicketDB>
{
    public TicketCollectionDB()
    {
        super.setObjectList(new ArrayList<TicketDB>());
        super.create(new TicketDB(1,  5));
        super.create(new TicketDB(2,  15));
        super.create(new TicketDB(3,  25));
        super.create(new TicketDB(4,  35));
        super.create(new TicketDB(5,  45));        
    }
}
