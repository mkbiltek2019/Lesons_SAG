package activerecord;

import Abstraction.ActiveRecord;
import activerecord.database.CustomerDB;
import activerecord.database.CustomerDBCollection;

/**
 *
 * @author Администратор
 */
public final class CustomerActiveRecord extends
        ActiveRecord<CustomerDB, CustomerDBCollection>
{
   CustomerDBCollection collection = new CustomerDBCollection();
   BankAccountActiveRecord bankAccount;
   
   public CustomerActiveRecord(int id)
   {
      super.instantiate(id, this.collection);
      bankAccount = new BankAccountActiveRecord(
                          this.getActiveRecord().getBankAccountId());
   }

   public void WithDrawMoneyFromBankAccount(double value)
   {
       bankAccount.withDrawMoney(value);
   }
}
