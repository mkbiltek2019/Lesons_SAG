package activerecord.database;

import Abstraction.Identity;

/**
 *
 * @author Администратор
 */
public class BankAccountDB extends Identity
{   
    private double balance;
    
    public BankAccountDB(int id, double balance)
    {
        super(id); 
        this.balance= balance;
    }    

    /**
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

}
