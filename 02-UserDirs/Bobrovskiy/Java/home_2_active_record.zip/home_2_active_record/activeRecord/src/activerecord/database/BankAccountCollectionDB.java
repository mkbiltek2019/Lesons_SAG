package activerecord.database;

import Abstraction.DBOperator;
import java.util.ArrayList;

/**
 *
 * @author Администратор
 */
public class BankAccountCollectionDB extends DBOperator<BankAccountDB>
{    
    public BankAccountCollectionDB()
    {
        super.setObjectList(new ArrayList<BankAccountDB>());
        super.create(new BankAccountDB(1,  200));
        super.create(new BankAccountDB(2,  300));
        super.create(new BankAccountDB(3,  400));
        super.create(new BankAccountDB(4,  500));
        super.create(new BankAccountDB(5,  600));       
    }
}
