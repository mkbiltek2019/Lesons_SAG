package activerecord.database;

import Abstraction.DBOperator;
import java.util.ArrayList;

/**
 *
 * @author Администратор
 */
public class CustomerDBCollection extends DBOperator<CustomerDB>
{       
    public CustomerDBCollection()
    {
        super.setObjectList(new ArrayList<CustomerDB>());
        super.create(new CustomerDB(1, "Jon", "Doe", 1));
        super.create(new CustomerDB(2, "Michael", "Lee", 2));
        super.create(new CustomerDB(3, "Bob", "Gordon", 3));
        super.create(new CustomerDB(4, "Jim", "Norton", 4));       
    }
    
}
