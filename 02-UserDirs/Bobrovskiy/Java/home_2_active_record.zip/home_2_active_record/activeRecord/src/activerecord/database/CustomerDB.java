package activerecord.database;

import Abstraction.Identity;

/**
 *
 * @author Администратор
 */

public class CustomerDB extends Identity
{   
    private String firstName;
    private String lastName;
    private int bankAccountId;

    public CustomerDB(int id, String firstName, String lastName, int bankAccountId)
    {
        super(id);
        this.firstName = firstName;
        this.lastName = lastName;        
        this.bankAccountId = bankAccountId; 
    }   

     /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @param bankAccountId the bankAccountId to set
     */
    public void setBankAccountId(int bankAccountId) {
        this.bankAccountId = bankAccountId;
    }    

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @return the bankAccountId
     */
    public int getBankAccountId() {
        return bankAccountId;
    }   

}
