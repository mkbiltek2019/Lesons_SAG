package activerecord;

import Abstraction.ActiveRecord;
import activerecord.database.TicketCollectionDB;
import activerecord.database.TicketDB;

/**
 *
 * @author Администратор
 */
public final class TicketActiveRecord extends
        ActiveRecord<TicketDB, TicketCollectionDB>
{
    TicketCollectionDB collection = new TicketCollectionDB();

    public TicketActiveRecord(int id)
    {
        super.instantiate(id, this.collection);
    }

    public double getTicketPrice()
    {
        return this.getActiveRecord().getTicketPrice();
    }
}
