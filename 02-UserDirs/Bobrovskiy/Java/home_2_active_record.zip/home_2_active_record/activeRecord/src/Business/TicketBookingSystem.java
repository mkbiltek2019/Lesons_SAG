package Business;

import activerecord.CustomerActiveRecord;
import activerecord.TicketActiveRecord;

/**
 *
 * @author Администратор
 */
public class TicketBookingSystem
{
    public void BookTicket(int customerId, int ticketId)
    {
       CustomerActiveRecord customer = 
               new CustomerActiveRecord(customerId);

       TicketActiveRecord ticket =
               new TicketActiveRecord(ticketId);

        customer.WithDrawMoneyFromBankAccount(ticket.getTicketPrice());
    }
}
