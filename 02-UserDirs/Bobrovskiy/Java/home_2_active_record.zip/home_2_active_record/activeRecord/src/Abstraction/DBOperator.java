package Abstraction;

import java.util.ArrayList;

/**
 *
 * @author Администратор
 */
public abstract class DBOperator<T extends Identity> extends BaseOperator<T>
{
    private  ArrayList <T> objectList;

    public T find(int id)
    {
        T result= null;

        for(T currentObject: this.getObjectList())
        {
            if(currentObject.getId()==id)
            {
                result = currentObject;
                break;
            }
        }

        return result;
    }
    
    public  void create(T value)
    {
         this.getObjectList().add(value);
    }

    public void update(T value)
    {
        this.delete(value.getId());
        this.getObjectList().add(value);
    }

    public void delete(int id)
    {
        T oldData = this.find(id);
        this.getObjectList().remove(oldData);
    }   

    /**
     * @return the objectList
     */
    public ArrayList<T> getObjectList() {
        return objectList;
    }

    /**
     * @param objectList the objectList to set
     */
    public void setObjectList(ArrayList<T> objectList) {
        this.objectList = objectList;
    }
}
