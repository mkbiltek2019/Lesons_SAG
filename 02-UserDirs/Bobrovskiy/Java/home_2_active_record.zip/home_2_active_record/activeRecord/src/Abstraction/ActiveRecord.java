/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Abstraction;

/**
 *
 * @author Администратор
 */
public class ActiveRecord<Model, Collection extends BaseOperator<Model>>
{
    private Model activeRecord;
    private Collection collection;    

    protected ActiveRecord()
    {}
    
    protected void instantiate(int id, Collection collection)
    {
        this.collection = collection;

        this.activeRecord = this.collection.find(id);
    }

    private Model find(int id)
    {
        return this.collection.find(id);
    }

    private void insert(Model value)
    {
        this.collection.create(value);
    }

    private void update()
    {
        this.collection.update(getActiveRecord());
    }

    /**
     * @return the activeRecord
     */
    public Model getActiveRecord() {
        return activeRecord;
    }

    /**
     * @param activeRecord the activeRecord to set
     */
    public void setActiveRecord(Model activeRecord) {
        this.activeRecord = activeRecord;
        this.update();
    }
}
