/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Abstraction;

/**
 *
 * @author Администратор
 */
public class Identity
{
    private final int id;

    public Identity(int id)
    {
        this.id = id;
    }
    /**
     * @return the id
     */
    public int getId() {
        return this.id;
    }

}
