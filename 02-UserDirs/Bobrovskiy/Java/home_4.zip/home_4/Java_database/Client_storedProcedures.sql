-- ================================================
use ClientRegistry
go
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[Client.GetAllClients]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
	   [Id]
      ,[FirstName]
      ,[SecondName]
      ,[Gender]
      ,[Age]
  FROM [ClientRegistry].[dbo].[Client]
END
GO

--==============================================
ALTER PROCEDURE [dbo].[Client.GetClientById]	
		@Id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
	   [Id]
      ,[FirstName]
      ,[SecondName]
      ,[Gender]
      ,[Age]
  FROM [ClientRegistry].[dbo].[Client]
  WHERE 
		[Id]=@Id
END
GO

-- ==========================================
ALTER PROCEDURE [dbo].[Client.CreateNewClient]	
	   @FirstName nvarchar(250),
       @SecondName nvarchar(250),
       @Gender bit,
       @Age int		
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [ClientRegistry].[dbo].[Client]
           ([FirstName]
           ,[SecondName]
           ,[Gender]
           ,[Age])
     VALUES
           (@FirstName
           ,@SecondName
           ,@Gender
           ,@Age)
END
GO
-- ===========================================
ALTER PROCEDURE [dbo].[Client.UpdateClient]	
		@Id int,
		@FirstName nvarchar(250),
        @SecondName nvarchar(250),
        @Gender bit,
        @Age int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
   UPDATE [ClientRegistry].[dbo].[Client]
   SET [FirstName] = @FirstName
      ,[SecondName] = @SecondName
      ,[Gender] = @Gender
      ,[Age] = @Age
   WHERE [Id] = @Id 
 
END
GO

--=================================================
ALTER PROCEDURE [dbo].[Client.DeleteClient]	
		@Id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE FROM 
		[ClientRegistry].[dbo].[Client]     
	WHERE 
		[Id]=@Id
END
GO