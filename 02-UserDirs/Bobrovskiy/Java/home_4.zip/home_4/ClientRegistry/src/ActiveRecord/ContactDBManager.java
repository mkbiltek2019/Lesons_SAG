/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ActiveRecord;

import Abstraction.BaseOperator;
import Model.Contact;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Администратор
 */
public class ContactDBManager extends BaseOperator<Contact>
{
    private final String dbDriverClassName
            = DBConfiguration.getDbDriverClassName();
    private final String connectionString
            = DBConfiguration.getConnectionString();

    private final String login = DBConfiguration.getLogin();
    private final String password= DBConfiguration.getPassword();

    // field name must be equal to data base fields
    private final String id = "Id";
    private final String address = "Address";
    private final String email = "Email";
    private final String phone = "Phone";

    private final String Client_GetContactByClientId = "EXECUTE [dbo].[Client.GetContactByClientId] ?";

    @Override
    public Contact find(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void create(Contact value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void update(Contact value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<Contact> getAll() {
        return null;
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<Contact> getAllById(int id) {
        
        Connection connection = DBConfiguration.dbConnect(connectionString, login,
                                               password);
        List<Contact> result = new ArrayList<Contact>();
        try
        {
            CallableStatement getAll = connection.prepareCall(Client_GetContactByClientId);
            getAll.setInt(this.id, id);
            ResultSet selectResult = getAll.executeQuery();

            while (selectResult.next())
            {
                result.add(new Contact(
                        selectResult.getInt(this.id),
                        selectResult.getString(this.address),
                        selectResult.getString(this.email),
                        selectResult.getString(this.phone)
                        ));
            }

            getAll.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                connection.close();
            } catch (SQLException ex)
            {
                Logger.getLogger(ClientDBManager.class.getName())
                                 .log(Level.SEVERE, null, ex);
            }
        }

        return result;
    }
}
