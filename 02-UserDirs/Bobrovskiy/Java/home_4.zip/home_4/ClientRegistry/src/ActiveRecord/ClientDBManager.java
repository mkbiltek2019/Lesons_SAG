package ActiveRecord;

import Abstraction.BaseOperator;
import Model.Client;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Администратор
 */
public final class ClientDBManager extends BaseOperator<Client>
{
    private final String dbDriverClassName
                            = DBConfiguration.getDbDriverClassName();
    private final String connectionString
                            = DBConfiguration.getConnectionString();
    
    private final String login = DBConfiguration.getLogin();
    private final String password= DBConfiguration.getPassword();

    // field name must be equal to data base fields
    private final String id = "Id";
    private final String firstName = "FirstName";
    private final String secondName = "SecondName";
    private final String gender = "Gender";
    private final String age = "Age";
    // stored procedures
    private final String Client_GetAllClients = "EXECUTE [ClientRegistry].[dbo].[Client.GetAllClients]";
    private final String Client_GetClientById = "EXECUTE [ClientRegistry].[dbo].[Client.GetClientById] ?";
    private final String Client_CreateNewClient = "EXECUTE [ClientRegistry].[dbo].[Client.CreateNewClient] ?,?,?,?";
    private final String Client_UpdateClient = "EXECUTE [ClientRegistry].[dbo].[Client.UpdateClient] ?,?,?,?,?";
    private final String Client_DeleteClient = "EXECUTE [ClientRegistry].[dbo].[Client.DeleteClient] ?";

    @Override
    public List<Client> getAll()
    {          
        Connection connection = DBConfiguration.dbConnect(connectionString, login,
                                               password);
        List<Client> result = new ArrayList<Client>();        
        try
        {    
            CallableStatement getAll = connection.prepareCall(Client_GetAllClients);
            ResultSet selectResult = getAll.executeQuery();
            
            while (selectResult.next())
            {
                result.add(new Client(
                        selectResult.getInt(this.id),
                        selectResult.getString(this.firstName),
                        selectResult.getString(this.secondName),
                        selectResult.getInt(this.gender),
                        selectResult.getInt(this.age)));
            }
            
            getAll.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                connection.close();
            } catch (SQLException ex)
            {
                Logger.getLogger(ClientDBManager.class.getName())
                                 .log(Level.SEVERE, null, ex);
            }
        }

        return result;
    }

    @Override
    public List<Client> getAllById(int id)
    {       
       return null;
    }
    
   @Override
    public Client find(int id)
    {      
        Connection connection = DBConfiguration.dbConnect(connectionString, login,
                                               password);
        Client result = null;

        try
        {
            CallableStatement getById = connection.prepareCall(Client_GetClientById);
            getById.setInt(this.id, id);
            ResultSet selectResult = getById.executeQuery();

           while (selectResult.next())
            {                
                result = new Client(
                    selectResult.getInt(this.id),
                    selectResult.getString(this.firstName),
                    selectResult.getString(this.secondName),
                    selectResult.getInt(this.gender),
                    selectResult.getInt(this.age));
                break;
            }
            //getById.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                connection.close();
            } catch (SQLException ex)
            {
                Logger.getLogger(ClientDBManager.class.getName())
                                 .log(Level.SEVERE, null, ex);
            }
        }

        return result;
    }

    @Override
    public void create(Client value)
    {  
        Connection connection = DBConfiguration.dbConnect(connectionString, login,
                                               password);
        try
        {      
            CallableStatement createNew = connection.prepareCall(Client_CreateNewClient);
            createNew.setString(this.firstName, value.getFirstName());
            createNew.setString(this.secondName, value.getSecondName());
            createNew.setInt(this.gender, value.getGender());
            createNew.setInt(this.age, value.getAge());

            int rowCount = createNew.executeUpdate();
           // createNew.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                connection.close();
            } catch (SQLException ex)
            {
                Logger.getLogger(ClientDBManager.class.getName())
                                 .log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void update(Client value)
    {
        Connection connection = DBConfiguration.dbConnect(connectionString, login,
                                                          password);
        try
        {
            CallableStatement updateClient = connection.prepareCall(Client_UpdateClient);
            updateClient.setInt(this.id, value.getId());
            updateClient.setString(this.firstName, value.getFirstName());
            updateClient.setString(this.secondName, value.getSecondName());
            updateClient.setInt(this.gender, value.getGender());
            updateClient.setInt(this.age, value.getAge());

            int resulr = updateClient.executeUpdate();
           // updateClient.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                connection.close();
            } catch (SQLException ex)
            {
                Logger.getLogger(ClientDBManager.class.getName())
                                 .log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void delete(int id)
    {  
        Connection connection = DBConfiguration.dbConnect(connectionString, login,
                                               password);
        try
        {
            CallableStatement updateClient = connection.prepareCall(Client_DeleteClient);
            updateClient.setInt(this.id, id);

            int rowCount = updateClient.executeUpdate();
            updateClient.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                connection.close();
            } catch (SQLException ex)
            {
                Logger.getLogger(ClientDBManager.class.getName())
                                 .log(Level.SEVERE, null, ex);
            }
        }
    }   
}
