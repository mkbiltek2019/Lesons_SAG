/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ActiveRecord;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Администратор
 */
public class DBConfiguration
{
    private static final String dbDriverClassName
            = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String connectionString
            = "jdbc:sqlserver://192.168.12.129:1433;DatabaseName=ClientRegistry";

    private static final String login = "bobrovskiy";
    private static final String password= "1";

    public static Connection dbConnect(String db_connect_string, String db_userid,
                                 String db_password)
    {
        Connection result = null;
        try
        {
            Class.forName(DBConfiguration.dbDriverClassName);
            result = DriverManager.getConnection(db_connect_string, db_userid,
                                                 db_password);
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * @return the dbDriverClassName
     */
    public static String getDbDriverClassName() {
        return dbDriverClassName;
    }

    /**
     * @return the connectionString
     */
    public static String getConnectionString() {
        return connectionString;
    }

    /**
     * @return the login
     */
    public static String getLogin() {
        return login;
    }

    /**
     * @return the password
     */
    public static String getPassword() {
        return password;
    }
}
