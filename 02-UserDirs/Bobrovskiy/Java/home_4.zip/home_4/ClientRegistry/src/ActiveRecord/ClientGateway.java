/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ActiveRecord;

import Model.Client;
import java.util.List;

/**
 *
 * @author Администратор
 */
public final class ClientGateway
{
    private final static ClientDBManager clientManager = new ClientDBManager();

    public static List<Client> getAllClients()
    {
        return clientManager.getAll();
    }

    public static void update(Client newClient)
    {
        clientManager.update(newClient);
    }

    public static void create(Client newClient)
    {
         clientManager.create(newClient);
    }

    public static Client getById(int id)
    {
        return clientManager.find(id);
    }

    public static void delete(int id)
    {
         clientManager.delete(id);
    }
}
