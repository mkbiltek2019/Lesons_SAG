/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ActiveRecord;


import Model.Contact;
import java.util.List;

/**
 *
 * @author Администратор
 */
public final class ContactGateway
{   
    private static final ContactDBManager contactManager = new ContactDBManager();

    public static List<Contact> getAllContactsById(int id)
    {
        return contactManager.getAllById(id);
    }
    
}
