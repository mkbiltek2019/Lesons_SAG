/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Abstraction;

import java.util.List;

/**
 *
 * @author Администратор
 */
public abstract class BaseOperator<T>
{ 
   public abstract T find(int id);
   public abstract void create(T value);
   public abstract void update(T value);
   public abstract void delete(int id);
   public abstract List<T> getAll();
   public abstract List<T> getAllById(int id);   
}
