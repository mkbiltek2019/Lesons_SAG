
import clientsregistry.ClientsRegistry;
import javax.swing.*;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manekovskiy
 */
public class Program {
    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                javax.swing.JFrame frame = new javax.swing.JFrame("Client Registry");
//                javax.swing.JMenuBar menu = new JMenuBar();
//                 // build the File menu
//                javax.swing.JMenu fileMenu = new javax.swing.JMenu("File");
//                JMenuItem openMenuItem = new JMenuItem("Close");
//                //openMenuItem.addActionListener((ActionListener) frame);
//                fileMenu.add(openMenuItem);
//
//                // build the Edit menu
//                JMenu editMenu = new JMenu("View");
//                JMenuItem silverMenuItem = new JMenuItem("Silver");
//                JMenuItem windowsMenuItem = new JMenuItem("Windows");
//                JMenuItem motifMenuItem = new JMenuItem("Motif");
//                editMenu.add(silverMenuItem);
//                editMenu.add(windowsMenuItem);
//                editMenu.add(motifMenuItem);
//
//                // add menus to menubar
//                menu.add(fileMenu);
//                menu.add(editMenu);
//
//                // put the menubar on the frame
//                frame.setJMenuBar(menu);

                
                frame.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
                frame.getContentPane().add(new ClientsRegistry());
                frame.pack();
                frame.setVisible(true);
            }
        });
    }
}
