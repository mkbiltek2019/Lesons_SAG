/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 *
 * @author Администратор
 */
public class Contact 
{
    private int Id;
    private String Address;
    private String Email;   
    private String Phone;   

    public Contact(int id, String address, String email, String phone)
    {
        this.Id = id;
        this.Address = address;
        this.Email = email;
        this.Phone = phone;
    }

     // <editor-fold defaultstate="collapsed" desc="PropertyChange Stuff">
    private final PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    // </editor-fold>
    
    /**
     * @return the Address
     */
    public String getAddress()
    {
        return Address;
    }

    /**
     * @param Address the Address to set
     */
    public void setAddress(String address)
    {
        String oldAddress = this.Address;
        this.Address = address;
        changeSupport.firePropertyChange("Address", oldAddress, address);      
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String email)
    {
        String oldEmail = this.Email;
        this.Email = email;
        changeSupport.firePropertyChange("Email", oldEmail, email);
    }

    /**
     * @return the Phone
     */
    public String getPhone() {
        return Phone;
    }

    /**
     * @param Phone the Phone to set
     */
    public void setPhone(String phone)
    {
        String oldPhone = this.Phone;
        this.Phone = phone;
        changeSupport.firePropertyChange("Phone", oldPhone, phone);
    }

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }
}
