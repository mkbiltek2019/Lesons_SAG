/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 *
 * @author Администратор
 */
public class ClientToContact  
{
    private int ContactId;
    private int ClientId;

    public ClientToContact(int clientId, int contactId)
    {
        this.ClientId = clientId;
        this.ContactId = contactId;
    }

       // <editor-fold defaultstate="collapsed" desc="PropertyChange Stuff">
    private final PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    // </editor-fold>

    /**
     * @return the ContactId
     */
    public int getContactId() {
        return ContactId;
    }

    /**
     * @param ContactId the ContactId to set
     */
    public void setContactId(int contactId)
    {
        int oldContactId = this.ContactId;
        this.ContactId = contactId;
        changeSupport.firePropertyChange("ContactId", oldContactId, contactId);
    }

    /**
     * @return the ClientId
     */
    public int getClientId() {
        return ClientId;
    }

    /**
     * @param ClientId the ClientId to set
     */
    public void setClientId(int clientId) {

        int oldClientId = this.ContactId;
        this.ClientId = clientId;
        changeSupport.firePropertyChange("ClientId", oldClientId, clientId);
    }
}
