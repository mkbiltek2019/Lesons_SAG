/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 *
 * @author Администратор
 */
public class Client 
{
    private int Id;
    private String FirstName;
    private String SecondName;
     /** Gender of the client (0 - female, 1 - male). */
    private int Gender;
    /** Age of the client. */
    private int Age;

    public Client(int id, String firstName, String secondName, int gender, int age)
    {
        this.Id = id;
        this.FirstName = firstName;
        this.SecondName = secondName;
        this.Gender = gender;
        this.Age =age;
    }
    
    public static Client createDefault()
    {         
        return new Client(-1, "John", "Unknown", 1, 10);
    }

     // <editor-fold defaultstate="collapsed" desc="PropertyChange Stuff">
    private final PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    // </editor-fold>
   
    /**
     * @return the FirstName
     */
    public String getFirstName() {
        return FirstName;
    }

    /**
     * @param FirstName the FirstName to set
     */
    public void setFirstName(String firstName)
    {
        String oldFirstName = this.FirstName;
        this.FirstName = firstName;
        changeSupport.firePropertyChange("FirstName", oldFirstName, firstName);
    }

    /**
     * @return the SecondName
     */
    public String getSecondName() {
        return SecondName;
    }

    /**
     * @param SecondName the SecondName to set
     */
    public void setSecondName(String secondName) {
        String oldSecondName = this.SecondName;
        this.SecondName = secondName;
        changeSupport.firePropertyChange("SecondName", oldSecondName, secondName);
    }

    /**
     * @return the Gender
     */
    public int getGender() {
        return Gender;
    }

    /**
     * @param Gender the Gender to set
     */
    public void setGender(int gender)
    {
        int oldGender = this.Gender;
        this.Gender = gender;
        changeSupport.firePropertyChange("Gender", oldGender, gender);
    }

    /**
     * @return the Age
     */
    public int getAge() {
        return Age;
    }

    /**
     * @param Age the Age to set
     */
    public void setAge(int age) {
        int oldAge = this.Age;
        this.Age = age;
        changeSupport.firePropertyChange("Age", oldAge, age);
    }

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }
}
