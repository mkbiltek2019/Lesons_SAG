﻿
namespace SMODemo.Template
{
    public static class ModelTemplate
    {
        public static string GenerateModelBaseClass(string pakageName)
        {
            return string.Format(
                            "package Entities;\n\n" +
                            "\npublic class EntityBase \n{{"+
                            "\nprivate Integer id;"+
                            "\npublic EntityBase(Integer id) \n{{ this.id = id;\n}}\n\n"+
                            "\npublic Integer getId() \n{{\nreturn id;\n}}\n\n"+
                            "\npublic void setId(int id) \n{{\nthis.id = id;\n}}\n }}", pakageName);
        }

        public static string GenerateHeader(string pakageName,string className, string baseClass)
        {
            return string.Format("package {0}; \n\n public class {1} extends {2} \n {{\n",pakageName, className, baseClass);
        }

        public static string generateFields(string fieldType, string fieldName)
        {

            string headerString = 
                string.Format("\tprivate {0} {1};\n",fieldType, fieldName);
            return headerString;
        }

        public static string generateConstructor(string className)
        {
            string result = string.Format("\npublic {0}() \n{{\n\t super(null); \n}}\n", className);
            return result;
        }

        public static string generateGetters(string fieldType, string fieldName)
        {
            string result = 
                string.Format("\npublic {0} get{1}()\n{{\n\t return {2};\n}}\n",
                                    fieldType, StringHelper.FirstLetterToUpperCase(fieldName), fieldName);
            return result;
        }

        public static string generateSetters(string fieldType, string fieldName)
        {
            string result =
                string.Format("\npublic void set{0}({1} {2}) \n{{\n\tthis.{2} = {2};\n}}\n",
                                     StringHelper.FirstLetterToUpperCase(fieldName), fieldType, fieldName);
            return result;
        }

        public static string GenerateFooter()
        {
            return "\n}";
        }
    }
}
