﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SMODemo.Helpers;

namespace SMODemo.Template
{
    public class ModelBuilder
    {
        private string pakageName = "Entities";
        private string className;
        private string baseClassName="EntityBase";//create too

        private List<FieldModel> fields = new List<FieldModel>();

        public void SetTableName(string tableName)
        {
            this.className = tableName;
        }

        public void SetFieldsList(string fieldName, string fieldType)
        {
            fields.Add(new FieldModel()
                           {
                               Name = fieldName,
                               Type = StringHelper.ConvertTypes(fieldType)
                           }); 
        }
      
        public void Generate()
        {
            DirectoryInfo dir = Directory.CreateDirectory(pakageName);

              using (FileStream fs = File.Create(dir.FullName+"\\"+className + ".java"))
              {
                      writeUTFStringToToStream(fs, ModelTemplate.GenerateHeader(pakageName, className, baseClassName));
                  
                  foreach (FieldModel field in fields)
                  {
                      if (field.Name.ToLower() != "id")
                      {
                          writeUTFStringToToStream(fs, ModelTemplate.generateFields( field.Type, field.Name));
                      }
                  }

                      writeUTFStringToToStream(fs, ModelTemplate.generateConstructor(className));
                 
                  foreach (FieldModel field in fields)
                  {
                      if (field.Name.ToLower() != "id")
                      {
                          writeUTFStringToToStream(fs, ModelTemplate.generateGetters(field.Type, field.Name));
                      }
                  }

                  foreach (FieldModel field in fields)
                  {
                      if (field.Name.ToLower() != "id")
                      {
                          writeUTFStringToToStream(fs, ModelTemplate.generateSetters(field.Type, field.Name));
                      }
                  }

                      writeUTFStringToToStream(fs, ModelTemplate.GenerateFooter());
              }

              //========== generate base class
              using (FileStream fs = File.Create(dir.FullName + "\\"+"EntityBase.java"))
              {
                  writeUTFStringToToStream(fs, ModelTemplate.GenerateModelBaseClass(pakageName));
                  
              }
            
            ClearData();
        }

        private void writeUTFStringToToStream(FileStream fs, string value)
        {
            Byte[] buffer = new UTF8Encoding(true).GetBytes(value);
            fs.Write(buffer, 0, buffer.Length);
        }

        private void ClearData()
        {
            this.className = string.Empty;
            if(this.fields!=null)
            {
                this.fields.Clear();
            }
        }

    }
}
