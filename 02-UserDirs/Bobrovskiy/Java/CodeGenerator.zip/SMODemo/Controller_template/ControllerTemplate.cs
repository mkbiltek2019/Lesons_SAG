﻿
using SMODemo.Template;

namespace SMODemo.Controller_template
{
    public class ControllerTemplate
    {
        public static string GenerateBaseClass(string pakageName, string baseClassName)
        {
            return string.Format(
                    "package {0};\n" +
                    "import java.sql.SQLException;\n" +
                    "import java.util.List;\n" +

                    "\n\npublic abstract class {1}<Model, DataProvider>\n" +
                    "{{\n" +

                    "protected DataProvider dataProvider;\n" +

                    "public abstract List<Model> GetAll() throws ClassNotFoundException, SQLException ;\n" +

                    "public abstract void Delete(Model model) throws ClassNotFoundException, SQLException ;\n" +

                    "public abstract Integer Save(Model model) throws ClassNotFoundException, SQLException ;\n" +

                    "public abstract Model GetById(Integer id) throws ClassNotFoundException, SQLException ;\n" +

                    "\n\n}}", pakageName, baseClassName);
        }

        public static string GenerateControllerHeaderConstructor(string pakageName, string modelName,
                                                    string dataAccessPakageName, string modelPakageName)
        {
            return string.Format(
                            "package {0};\n\n" +

                            "import {1}.{3}DataProvider;\n" +
                            "import {2}.{3};\n" +
                            "import java.sql.SQLException;\n" +
                            "import java.util.List;\n\n" +

                            "public class {3}Controller extends BaseController<{3}, {3}DataProvider>\n {{\n" +

                            "\tpublic {3}Controller()\n {{\n" +
                            "\t\tdataProvider = new {3}DataProvider();\n" +
                            "}}\n", pakageName, dataAccessPakageName, modelPakageName, modelName);
        }

        public static string GenerateGetAllMethod(string modelName)
        {
            return string.Format("\npublic List<{0}> GetAll() throws ClassNotFoundException, SQLException \n{{" +
                                    "\t return dataProvider.GetAll();\n" +
                                 "}}\n\n", modelName);
        }

        public static string GenerateGetByIdMethod(string modelName)
        {
            return string.Format("\npublic {0} GetById(Integer id) throws ClassNotFoundException, SQLException \n{{" +
                                    "\t  return dataProvider.GetById(id);\n" +
                                 "}}\n\n", modelName);
        }

        public static string GenerateDeleteMethod(string modelName)
        {
            return string.Format("\npublic void Delete({0} {1}) throws ClassNotFoundException, SQLException \n{{" +
                                    "\t  dataProvider.Delete({1}); \n" +
                                 "}}\n\n", modelName, StringHelper.FirstLetterToLowerCase(modelName));
        }

        public static string GenerateSaveMethod(string modelName)
        {
            return string.Format(
            "\npublic Integer Save({0} {1}) throws ClassNotFoundException, SQLException \n{{" +

            "\n\tInteger result;"+

            "\n\tif({1}.getId() == null) \n{{"+

            "\n\t\tresult = dataProvider.Insert({1});" +
            "\n}}"+

            "\n\telse \n{{"+

           "\n\t\tresult = dataProvider.Update({1});" +
           " \n\t}}"+

           " \nreturn result;"+
            "\n}}", modelName, StringHelper.FirstLetterToLowerCase(modelName));
        }
        
        public static string GenerateFooter()
        {
            return "\n}";
        }
    }
}
