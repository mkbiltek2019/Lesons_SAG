﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SMODemo.Helpers;

namespace SMODemo.Controller_template
{
    public class ControllerBuilder
    {
        private string pakageName = "BL";
        private string dataProviderPakageName = "DAL";
        private string modelPakageName = "Entities";
        private string baseClassName = "BaseController";//create too

        List<StoredProcedureList> spList = new List<StoredProcedureList>();
        List<TableList> tableList = new List<TableList>();

        public void SetCompleteTableList(List<TableList> tableList)
        {
            this.tableList = tableList;
        }

        public void SetCompleteSPList(List<StoredProcedureList> spList)
        {
            this.spList = spList;
        }

        public void Generate()
        {
            DirectoryInfo dir = Directory.CreateDirectory(pakageName);

            foreach (TableList list in tableList)
            {
                using (FileStream fs = File.Create(dir.FullName + "\\" + list.TableName + "Controller.java"))
                {
                    writeUTFStringToToStream(fs,
                        ControllerTemplate.GenerateControllerHeaderConstructor(pakageName, list.TableName, dataProviderPakageName, modelPakageName));

                    writeUTFStringToToStream(fs, ControllerTemplate.GenerateDeleteMethod(list.TableName));

                    writeUTFStringToToStream(fs, ControllerTemplate.GenerateGetAllMethod(list.TableName));

                    writeUTFStringToToStream(fs, ControllerTemplate.GenerateGetByIdMethod(list.TableName));

                    writeUTFStringToToStream(fs, ControllerTemplate.GenerateSaveMethod(list.TableName));

                    writeUTFStringToToStream(fs,ControllerTemplate.GenerateFooter());
                }
            }


            // generate base class
            using (FileStream fs = File.Create(dir.FullName + "\\" + baseClassName + ".java"))
            {
                writeUTFStringToToStream(fs,
                                         ControllerTemplate.GenerateBaseClass(baseClassName, pakageName));
            }
        }

        private void writeUTFStringToToStream(FileStream fs, string value)
        {
            Byte[] buffer = new UTF8Encoding(true).GetBytes(value);
            fs.Write(buffer, 0, buffer.Length);
        }
    }
}
