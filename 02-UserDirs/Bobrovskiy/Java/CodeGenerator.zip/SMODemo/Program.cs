﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
using SMODemo.Controller_template;
using SMODemo.DataProvider_template;
using SMODemo.Helpers;
using SMODemo.StoredProcedure_template;
using SMODemo.Template;

namespace SMODemo
{
    class Program
    {
        static void Main(string[] args)
        {
           try{ ServerConnection serverConnection = new ServerConnection("192.168.12.129", "bobrovskiy", "1");
           
            Server server = new Server(serverConnection);
            var clientRegistry = server.Databases
                                .Cast<Database>()
                                .Single(db => db.Name == "ClientRegistry");

            List<string> databaseTableNames = new List<string>();
            ModelBuilder modelBuilder = new ModelBuilder();
           
            List<FieldModel> fieldList = null;
            List<StoredProcedureList> spList = new List<StoredProcedureList>();
            List<TableList> tableList = new List<TableList>();

            DataProviderBuilder providerBuilder = new DataProviderBuilder();
            ControllerBuilder controllerBuilder = new ControllerBuilder();
            SP_Builder spBuilder = new SP_Builder();
            //============================
            Console.WriteLine("[DATABASE] {0}:", clientRegistry.Name);
            foreach (Table table in clientRegistry.Tables)
            {
                if (table.Name!="sysdiagrams")
                {
                    Console.WriteLine("\t[TABLE] {0}:", table.Name);
                    databaseTableNames.Add(table.Name);
                    modelBuilder.SetTableName(table.Name);

                    fieldList = new List<FieldModel>();
                    foreach (Column column in table.Columns)
                    {
                        fieldList.Add(new FieldModel()
                                          {
                                              Name = column.Name,
                                              Type = column.DataType.Name 
                                          });

                        modelBuilder.SetFieldsList(column.Name, column.DataType.Name);

                        Console.WriteLine("\t\t{0}:{1}", column.Name, column.DataType);
                    }
                    tableList.Add(new TableList() { FieldList = fieldList, TableName = table.Name});
                    
                    modelBuilder.Generate();
                }
            }
            spBuilder.SetCompleteTableList(tableList);
            controllerBuilder.SetCompleteTableList(tableList);
            providerBuilder.SetCompleteTableList(tableList);

           
            //============================
            Console.WriteLine("[Stored procedures] {0}:", "---------------");
            foreach (StoredProcedure storedProcedure in clientRegistry.StoredProcedures)
            {
                
                foreach (string tableName in databaseTableNames)
                {
                    if (storedProcedure.Name.Contains(tableName))
                    {
                        Console.WriteLine("\t[SP] {0}:", storedProcedure.Name);

                        fieldList = new List<FieldModel>();
                        foreach (StoredProcedureParameter column in storedProcedure.Parameters)
                        {
                            fieldList.Add(new FieldModel()
                            {
                                Name = column.Name,
                                Type = column.DataType.Name
                            });

                            //SqlPropertyInfo[] info = column.Properties.EnumPropertyInfo();
                            Console.WriteLine("\t\t{0}:{1}", 
                                                column.Name, 
                                                column.DataType.Name);
                        }

                        spList.Add(new StoredProcedureList() { FieldList = fieldList, SpName = storedProcedure.Name, TableName = tableName});
                    }
                }
            }

            controllerBuilder.SetCompleteSPList(spList);
            providerBuilder.SetCompleteSPList(spList);

            controllerBuilder.Generate();
            providerBuilder.Generate();
            spBuilder.Generate();
            //==========================
            serverConnection.Disconnect();
            
            Console.ReadKey(); 
            
        }catch(Exception e)
           {
            Console.WriteLine("Connection proble please config connection string and try again..");
           }
        }
    
    }
}
