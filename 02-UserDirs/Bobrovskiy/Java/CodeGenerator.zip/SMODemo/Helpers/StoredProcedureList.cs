﻿using System.Collections.Generic;

namespace SMODemo.Helpers
{
    public class StoredProcedureList
    {
        public static string Insert = "Insert";
        public static string Update = "Update";
        public static string Delete = "Delete";
        public static string GetAll = "GetAll";
        public static string GetById = "GetById";
      
        public List<FieldModel> FieldList { get; set; }
        public string SpName { get; set; }
        public string TableName { get; set; }
    }

    public class TableList
    {
        public List<FieldModel> FieldList { get; set; }
        public string TableName { get; set; }
    }
}
