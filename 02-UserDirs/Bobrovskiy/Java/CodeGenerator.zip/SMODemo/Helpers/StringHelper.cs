﻿using System.Linq;
using System;

namespace SMODemo.Template
{
    public class StringHelper
    {
        public static string FirstLetterToUpperCase(string value)
        {
            string upper = value.ToUpper();
            string result = value.Insert(0, upper.ElementAt(0).ToString()).Remove(1, 1);

            return result;
        }

        public static string FirstLetterToLowerCase(string value)
        {
            string lower = value.ToLower();
            string result = value.Insert(0, lower.ElementAt(0).ToString()).Remove(1, 1);

            return result;
        }

        public static string RemoovePoint(string spName)
        {
            return spName.Replace('.', '_');
        }

        public static string removeTokken(string value)
        {
            const int start = 0;
            const int count = 1;
            return value.Remove(start, count); //remove first character from string
        }

        private enum dataTypes
        {
            db_bit,
            db_int,
            db_nvarchar
        }

        public static string ConvertTypes(string typeName)
        {
            string result = "String";//default type is String
            string modifier = "db_";
            dataTypes value = (dataTypes)Enum.Parse(typeof(dataTypes), modifier+typeName, false); ;

            switch(value)
            {
                case dataTypes.db_bit: 
                case dataTypes.db_int:
                    {
                        result = "Integer";
                    }
                    break;
                case dataTypes.db_nvarchar:
                    {
                        result = "String";
                    }
                    break;
            }
          

            return result;
        }

        public static string ConvertTypesForFunc(string typeName)
        {
            string result = "String";//default type is String
            string modifier = "db_";
            dataTypes value = (dataTypes)Enum.Parse(typeof(dataTypes), modifier + typeName, false); ;

            switch (value)
            {
                case dataTypes.db_bit:
                case dataTypes.db_int:
                    {
                        result = "Int";
                    }
                    break;
                case dataTypes.db_nvarchar:
                    {
                        result = "String";
                    }
                    break;
            }


            return result;
        }
    }
}
