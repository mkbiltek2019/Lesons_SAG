﻿using System.Collections.Generic;
using SMODemo.Helpers;

namespace SMODemo.StoredProcedure_template
{
    public class SPTemplate
    {
        public static string GenerateHeader(string databaseName)
        {
            return string.Format("USE {0} \nGO\n SET ANSI_NULLS ON \nGO\n SET QUOTED_IDENTIFIER ON \nGO\n", databaseName);
        }

        public static string GenerateGetAllSP(string databaseName, string tableName, List<FieldModel> fields)
        {
            string start = string.Format("CREATE PROCEDURE [{0}].[dbo].[{1}.GetAll]\n" +
                                        "AS\n" +
                                        "BEGIN\n" +
                                        "-- SET NOCOUNT ON added to prevent extra result sets from\n" +
                                        "-- interfering with SELECT statements.\n" +
                                        "SET NOCOUNT ON;\n" +
                                        "SELECT\n", databaseName, tableName);
            string param = string.Empty;

            foreach (FieldModel fieldModel in fields)
            {
                param += "\t"+fieldModel.Name + ",\n";
            }

            string selectFields = param.Remove(param.Length - 2, 2);

            string end = string.Format(
                                        "\nFROM {0}\n" +
                                        "END\n" +
                                        "GO\n\n", tableName);
            return string.Format("{0}{1}{2}", start, selectFields, end);
        }

        public static string GenerateUpdatetSP()
        {
            return string.Format("");
        }

        public static string GenerateDeletetSP()
        {
            return string.Format("");
        }

        public static string GenerateInsertSP()
        {
            return string.Format("");
        }

        public static string GenerateGetByIdSP(string databaseName, string tableName, List<FieldModel> fields)
        {
            string start = string.Format("CREATE PROCEDURE [{0}].[dbo].[{1}.GetById]\n" +
                                        "@Id int\n" +
                                        "AS\n" +
                                        "BEGIN\n" +
                                        "-- SET NOCOUNT ON added to prevent extra result sets from\n" +
                                        "-- interfering with SELECT statements.\n" +
                                        "SET NOCOUNT ON;\n" +
                                        "SELECT\n", databaseName, tableName);
            string param = string.Empty;

            foreach (FieldModel fieldModel in fields)
            {
                param += "\t" + fieldModel.Name + ",\n";
            }

            string selectFields = param.Remove(param.Length - 2, 2);

            string end = string.Format(
                                        "\nFROM {0}\n" +
                                        "WHERE Id = @Id "+
                                        "END\n" +
                                        "GO\n\n", tableName);
            return string.Format("{0}{1}{2}", start, selectFields, end);
        }
    }
}
