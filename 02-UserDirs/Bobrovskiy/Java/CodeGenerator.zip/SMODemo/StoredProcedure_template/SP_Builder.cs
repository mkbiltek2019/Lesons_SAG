﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SMODemo.Helpers;

namespace SMODemo.StoredProcedure_template
{
    public class SP_Builder
    {
        private string databaseName = "ClientRegistry";
      
        List<TableList> tableList = new List<TableList>();

        public void SetCompleteTableList(List<TableList> tableList)
        {
            this.tableList = tableList;
        }

        public void Generate()
        {
            DirectoryInfo dir = Directory.CreateDirectory(databaseName);

            foreach (TableList list in tableList)
            {
                using (FileStream fs = File.Create(dir.FullName + "\\" + list.TableName + "_storedProcuderes.sql"))
                {
                    //writeUTFStringToToStream(fs, SPTemplate.GenerateHeader(databaseName));
                    writeUTFStringToToStream(fs, SPTemplate.GenerateGetAllSP(databaseName, list.TableName, list.FieldList));
                    writeUTFStringToToStream(fs, SPTemplate.GenerateGetByIdSP(databaseName, list.TableName, list.FieldList));

                }
            }

        }

        private void writeUTFStringToToStream(FileStream fs, string value)
        {
            Byte[] buffer = new UTF8Encoding(true).GetBytes(value);
            fs.Write(buffer, 0, buffer.Length);
        }

    }
}
