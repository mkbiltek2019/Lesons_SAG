﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SMODemo.Helpers;
using SMODemo.Template;

namespace SMODemo.DataProvider_template
{
    public class DataProviderBuilder
    {
        private string pakageName = "DAL";
        private string baseClassName = "DataProviderBase";//create too

        List<StoredProcedureList> spList = new List<StoredProcedureList>();
        List<TableList> tableList = new List<TableList>();

        public void SetCompleteTableList(List<TableList> tableList)
        {
            this.tableList = tableList;
        }

        public void SetCompleteSPList(List<StoredProcedureList> spList)
        {
            this.spList = spList;
        }

        public void Generate()
        {
            DirectoryInfo dir = Directory.CreateDirectory(pakageName);

            foreach (TableList list in tableList)
            {
                using (FileStream fs = File.Create(dir.FullName + "\\" + list.TableName + "DataProvider.java"))
                {
                    writeUTFStringToToStream(fs, DataProviderTemplate.GenerateHeader(pakageName, list.TableName, baseClassName));

                    foreach (FieldModel fieldModel in list.FieldList)
                    {
                        writeUTFStringToToStream(fs, DataProviderTemplate.generateFields(fieldModel.Name));
                    }

                    foreach (StoredProcedureList s in spList)
                    {
                        if (s.TableName==list.TableName)
                        {
                            writeUTFStringToToStream(fs, DataProviderTemplate.generateStoredProcedures(s.SpName, s.FieldList.Count));
                        }
                    }
                    //-----1---
                    foreach (StoredProcedureList s in spList)
                    {
                        if (s.SpName.Contains(StoredProcedureList.GetAll) && s.TableName == list.TableName)
                        {
                            writeUTFStringToToStream(fs, DataProviderTemplate.generateGetAllMethod(list.TableName, s.SpName, list.FieldList));
                        }
                    }
                    //----2-
                    foreach (StoredProcedureList s in spList)
                    {
                        if (s.SpName.Contains(StoredProcedureList.GetById) && s.TableName == list.TableName)
                        {
                            writeUTFStringToToStream(fs, DataProviderTemplate.generateGetByIdMethod(list.TableName, s.SpName, list.FieldList));
                        }
                    }
                    //-----3

                    foreach (StoredProcedureList s in spList)
                    {
                        if (s.SpName.Contains(StoredProcedureList.Delete) && s.TableName == list.TableName)
                        {
                            writeUTFStringToToStream(fs, DataProviderTemplate.generateDeleteMethod(list.TableName, s.SpName, list.FieldList));
                        }
                    }
                    //-----4

                    foreach (StoredProcedureList s in spList)
                    {
                        if (s.SpName.Contains(StoredProcedureList.Insert) && s.TableName == list.TableName)
                        {
                            writeUTFStringToToStream(fs, DataProviderTemplate.generateInsertMethod(list.TableName, s.SpName, list.FieldList));
                        }
                    }
                    //-----5

                    foreach (StoredProcedureList s in spList)
                    {
                        if (s.SpName.Contains(StoredProcedureList.Update) && s.TableName == list.TableName)
                        {
                            writeUTFStringToToStream(fs, DataProviderTemplate.generateUpdateMethod(list.TableName, s.SpName, list.FieldList));
                        }
                    }

                    writeUTFStringToToStream(fs, DataProviderTemplate.GenerateFooter());
                }
            }

            // generate base class
            using (FileStream fs = File.Create(dir.FullName + "\\" + baseClassName + ".java"))
            {
                writeUTFStringToToStream(fs,
                                         DataProviderTemplate.GenerateBaseClass(baseClassName, pakageName));
            }
        }

        private void writeUTFStringToToStream(FileStream fs, string value)
        {
            Byte[] buffer = new UTF8Encoding(true).GetBytes(value);
            fs.Write(buffer, 0, buffer.Length);
        }
       
    }
}
