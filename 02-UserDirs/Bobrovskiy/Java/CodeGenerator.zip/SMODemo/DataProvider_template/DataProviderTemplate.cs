﻿using System.Collections.Generic;
using SMODemo.Helpers;

namespace SMODemo.Template
{
    public static class DataProviderTemplate
    {
        public static string GenerateBaseClass(string baseClassName, string pakageName)
        {
            return string.Format(
                    "package {0};\n"+

                    "\nimport java.sql.SQLException;\n"+

                    "\nimport java.util.List;\n"+

                    "\npublic abstract class {1}<Model> \n{{"+

                    "\n\tpublic abstract List<Model> GetAll() throws ClassNotFoundException, SQLException;" +

                    "\n\tpublic abstract Model GetById(Integer id) throws ClassNotFoundException, SQLException;" +

                    "\n\tpublic abstract Integer Insert(Model client) throws ClassNotFoundException, SQLException;" +

                    "\n\tpublic abstract Integer Update(Model client) throws ClassNotFoundException, SQLException;" +

                    "\n\tpublic abstract void Delete(Model client) throws ClassNotFoundException, SQLException; \n\n}}",  pakageName,baseClassName);
        }

        public static string GenerateHeader(string pakageName,string className, string baseClass)
        {
            return string.Format("package {0}; \nimport Entities.{1}; \nimport java.sql.*;"+
                " \nimport java.util.ArrayList; \nimport java.util.List;"+
                " \n\npublic class {1}DataProvider extends {2}<{1}> \n{{\n", pakageName, className, baseClass);
        }

        private static string GenerateParams(int count)
        {
            string result = string.Empty;

            if(count>0)
            {
                for (int i = 0; i < count-1; i++)
                {
                    result += " ?,";
                }
                
                result += " ?";
            }

            return result;
        }

        public static string generateStoredProcedures(string spName, int paramCount)
        {
            string headerString =
                string.Format("\tprivate final String sp_{0} = \"EXECUTE {1} {2}\";\n", 
                                    StringHelper.RemoovePoint(spName), spName, GenerateParams(paramCount)); 
            return headerString;
        }

        public static string generateFields(string tableFieldName)
        {
            string headerString =
                string.Format("\tprivate final String fn_{0} = \"{0}\";\n", tableFieldName);
            return headerString;
        }

        public static string generateGetAllMethod(string modelName, string spName, List<FieldModel> fields)
        {
            string funcHeader = string.Format("\n\npublic List<{0}> GetAll() throws ClassNotFoundException, SQLException \n{{\n ", modelName);

            string start = string.Format("\tList<{0}> result = new ArrayList<{0}>();"+
                "\n\tConnection connection = null;"+
                "\n\ttry {{\n\tconnection = DbConnectionProvider.GetConnection();"+
                "\n\tCallableStatement getAll = connection.prepareCall({1});"+
                "\n\tResultSet selectResult = getAll.executeQuery();\n"+
                "\twhile (selectResult.next()) {{\n\t{0} {2} = new {0}();\n",
                modelName, StringHelper.RemoovePoint("sp_"+spName), StringHelper.FirstLetterToLowerCase(modelName));

            string middle = string.Empty;

            foreach (FieldModel fieldModel in fields)
            {
                middle += string.Format("\t\t{0}.set{1}(selectResult.get{2}(this.fn_{1}));\n",
                          StringHelper.FirstLetterToLowerCase(modelName), fieldModel.Name, StringHelper.ConvertTypesForFunc(fieldModel.Type));
            }

            string end = string.Format( "\t\tresult.add({0});\n"+
                                        "\t}}\n\tgetAll.close();\n"+
                                        "\t}} catch(SQLException e)\n \t{{\n \t\t// TODO: handle exceptions \n\t}}\n"+
                                        "\tfinally \n\t{{\n"+
                                        " \t\tif(connection != null)\n"+
                                        "\t\tconnection.close();\n"+
                                        "\t}}\n\treturn result;\n }}\n", StringHelper.FirstLetterToLowerCase(modelName));

            return string.Format("{0}{1}{2}{3}", funcHeader, start, middle, end);
        }

        public static string generateGetByIdMethod(string modelName, string spName, List<FieldModel> fields)
        {
            string funcHeader = string.Format("\n\npublic {0} GetById(Integer id) throws ClassNotFoundException, SQLException \n{{\n ", modelName);

            string start = string.Format("\t {0} result = null;" +
                "\n\tConnection connection = null;" +
                "\n\ttry {{\n\tconnection = DbConnectionProvider.GetConnection();" +
                "\n\tCallableStatement getById = connection.prepareCall({1});" +
                "\n\tgetById.setInt(this.fn_id, id);" +
                "\n\tResultSet selectResult = getById.executeQuery();\n" +
                "\twhile (selectResult.next()) {{\n\t{0} {2} = new {0}();\n",
                modelName, StringHelper.RemoovePoint("sp_" + spName), StringHelper.FirstLetterToLowerCase(modelName));

            string middle = string.Empty;

            foreach (FieldModel fieldModel in fields)
            {
                middle += string.Format("\t\t{0}.set{1}(selectResult.get{2}(this.fn_{1}));\n",
                          StringHelper.FirstLetterToLowerCase(modelName), fieldModel.Name, StringHelper.ConvertTypesForFunc(fieldModel.Type));
            }

            string end = string.Format( "\n\t result= {0}; \n\t\tbreak;"+
                                        "\t}}\n\tgetById.close();\n" +
                                        "\t}} catch(SQLException e)\n \t{{\n \t\t// TODO: handle exceptions \n\t}}\n" +
                                        "\tfinally \n\t{{\n" +
                                        " \t\tif(connection != null)\n" +
                                        "\t\tconnection.close();\n" +
                                        "\t}}\n\treturn result;\n }}\n", StringHelper.FirstLetterToLowerCase(modelName));

            return string.Format("{0}{1}{2}{3}", funcHeader, start, middle, end);
        }

        public static string generateDeleteMethod(string modelName, string spName, List<FieldModel> fields)
        {
            string funcHeader = string.Format("\n\npublic void Delete({0} {1}) throws ClassNotFoundException, SQLException \n{{\n ",
                                               modelName, StringHelper.FirstLetterToLowerCase(modelName));

            string start = string.Format(
                "\n\tConnection connection = null;" +
                "\n\ttry {{\n\tconnection = DbConnectionProvider.GetConnection();" +
                "\n\tCallableStatement deleteCommand = connection.prepareCall({0});" +
                "\n\tdeleteCommand.setInt(this.fn_id, {1}.getId());" +
                "\n\t int resut = deleteCommand.executeUpdate();\n",
                StringHelper.RemoovePoint("sp_" + spName), StringHelper.FirstLetterToLowerCase(modelName));

            string end = string.Format(
                                        "\n\tdeleteCommand.close();\n" +
                                        "\t}} catch(SQLException e)\n \t{{\n \t\t// TODO: handle exceptions \n\t}}\n" +
                                        "\tfinally \n\t{{\n" +
                                        " \t\tif(connection != null)\n" +
                                        "\t\tconnection.close();\n" +
                                        "\t}}\n }}\n");

            return string.Format("{0}{1}{2}", funcHeader, start, end);
        }

        public static string generateInsertMethod(string modelName, string spName, List<FieldModel> fields)
        {
            string funcHeader = string.Format("\n\npublic void Insert({0} {1}) throws ClassNotFoundException, SQLException \n{{\n ",
                                              modelName, StringHelper.FirstLetterToLowerCase(modelName));

            string start = string.Format(
                "\n\tConnection connection = null;\n \t int result =0;\n" +
                "\n\ttry {{\n\tconnection = DbConnectionProvider.GetConnection();" +
                "\n\tCallableStatement insert = connection.prepareCall({0});", StringHelper.RemoovePoint("sp_" + spName));

            string spParams = string.Empty;
            foreach (FieldModel fieldModel in fields)
            {
                spParams += string.Format("\n\tinsert.set{0}(this.fn_{1}, {2}.get{1}());", 
                                           StringHelper.ConvertTypesForFunc(fieldModel.Type),
                                           fieldModel.Name, 
                                           StringHelper.FirstLetterToLowerCase(modelName));
            }

            string insertOpExecute = "\n\t int result = insert.executeUpdate();\n";

            string end = string.Format(
                                        "\n\tinsert.close();\n" +
                                        "\t}} catch(SQLException e)\n \t{{\n \t\t// TODO: handle exceptions \n\t}}\n" +
                                        "\tfinally \n\t{{\n" +
                                        " \t\tif(connection != null)\n" +
                                        "\t\tconnection.close();\n" +
                                        "\t}}\n\treturn result;\n }}\n");

            return string.Format("{0}{1}{2}{3}{4}", funcHeader, start, spParams, insertOpExecute, end);
        }

        public static string generateUpdateMethod(string modelName, string spName, List<FieldModel> fields)
        {
            string funcHeader = string.Format("\n\npublic void Update({0} {1}) throws ClassNotFoundException, SQLException \n{{\n ",
                                              modelName, StringHelper.FirstLetterToLowerCase(modelName));

            string start = string.Format(
                "\n\tConnection connection = null;\n \t int result =0;\n" +
                "\n\ttry {{\n\tconnection = DbConnectionProvider.GetConnection();" +
                "\n\tCallableStatement update = connection.prepareCall({0});", StringHelper.RemoovePoint("sp_" + spName));

            string spParams = string.Empty;
            foreach (FieldModel fieldModel in fields)
            {
                spParams += string.Format("\n\tupdate.set{0}(this.fn_{1}, {2}.get{1}());",
                                           StringHelper.ConvertTypesForFunc(fieldModel.Type),
                                           fieldModel.Name,
                                           StringHelper.FirstLetterToLowerCase(modelName));
            }

            string insertOpExecute = "\n\t int result = update.executeUpdate();\n";

            string end = string.Format(
                                        "\n\tupdate.close();\n" +
                                        "\t}} catch(SQLException e)\n \t{{\n \t\t// TODO: handle exceptions \n\t}}\n" +
                                        "\tfinally \n\t{{\n" +
                                        " \t\tif(connection != null)\n" +
                                        "\t\tconnection.close();\n" +
                                        "\t}}\n\treturn result;\n }}\n");

            return string.Format("{0}{1}{2}{3}{4}", funcHeader, start, spParams, insertOpExecute, end);
            return string.Empty;
        }

        public static string GenerateFooter()
        {
            return "\n}";
        }
    }
}
