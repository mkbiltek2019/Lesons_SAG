/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package clienteditor;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Администратор
 */
public class ClientCollection 
{
    private List<Client> clientList;

    private final PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }

    public ClientCollection()
    {
        clientList = new ArrayList<Client>();

        Client john = new Client();
        john.setFirstName("John");
        john.setSurname("Smith");
        john.setNickname("jsmith-1955");
        john.setAge(30);

        john.setEmail("smith@foo.org");
        john.setWeb("https://beansbinding.dev.java.net");
        john.setIm("ICQ: 53 25 89 11");

        john.setSex(1);
        john.setMaritalStatus(1);

        Client caitlyn = new Client();
        caitlyn.setFirstName("Caitlyn");
        caitlyn.setSurname("Smith");
        caitlyn.setNickname("jsmith-77");
        caitlyn.setAge(30);

        caitlyn.setEmail("caitlyn@foo.org");
        caitlyn.setWeb("https://beansbinding.dev.java.net");
        caitlyn.setIm("ICQ: 53 25 89 22");

        caitlyn.setSex(0);
        caitlyn.setMaritalStatus(3);

        clientList.add(john);
        clientList.add(caitlyn);

    }

    public List<Client> getClientList()
    {        
        return clientList;
    }

    public Client createNewClient()
    {
        Client client = new Client();
        client.setFirstName("George");
        client.setSurname("Foo");
        client.setNickname("Juraj");
        client.setAge(30);

        client.setEmail("g.foo@foo.org");
        client.setWeb("https://beansbinding.dev.java.net");
        client.setIm("ICQ: 53 25 89 76");

        client.setSex(1);
        client.setMaritalStatus(2);

        return client;
    }

    public void addClient(Client client)
    {
        ArrayList<Client> oldList = (ArrayList<Client>) this.clientList;
        clientList.add(client);
        changeSupport.firePropertyChange("clientList", oldList, this.clientList);
    }

    public void deleteClient(int id)
    {
        ArrayList<Client> oldList = (ArrayList<Client>) this.clientList;
        clientList.remove(id);
        changeSupport.firePropertyChange("clientList", oldList, this.clientList);
    }

    public Client getClientById(int id)
    {
        Client client = null;
        
        try
        {
            client = clientList.get(id);
        }
        catch(IndexOutOfBoundsException ex)
        {
            System.out.print("Ixdex out of range + "+ex);
        }

        return client;
    }

    /**
     * @param clientList the clientList to set
     */
    public void setClientList(List<Client> clientList) {
        ArrayList<Client> oldList = (ArrayList<Client>) this.clientList;
        this.clientList = clientList;
        changeSupport.firePropertyChange("clientList", oldList, this.clientList);
    }
}
