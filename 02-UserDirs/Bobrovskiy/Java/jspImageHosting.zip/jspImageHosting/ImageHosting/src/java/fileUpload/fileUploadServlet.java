package fileUpload;

import BL.ImageFileController;
import Entities.ImageFile;
import com.oreilly.servlet.MultipartRequest;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.coobird.thumbnailator.Thumbnailator;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class fileUploadServlet extends HttpServlet {

    private String fileUploadDirectory = "E:\\java_hometask\\jspImageHosting\\ImageHosting\\web\\upload\\";
    private final String redirectPage = "index.jsp";
    private final String imageTitle = "imageTitle";
    private final String fileOptions = "fileOptions";
    private final String imageDescription = "imageDescription";
    private final String fileOption = "fileOptions";
    private final int MAX_POST_SIZE = 5 * 1024 * 1024;
    private final static Logger log = Logger.getLogger(fileUploadServlet.class.toString());

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet fileUploadServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet fileUploadServlet at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
        } finally {
            out.close();
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        MultipartRequest multi =
                new MultipartRequest(request, fileUploadDirectory, MAX_POST_SIZE,
                new com.oreilly.servlet.multipart.DefaultFileRenamePolicy());
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);

        if (isMultipart)
        {
            Enumeration files = multi.getFileNames();

            String name = (String) files.nextElement();
            String filename = multi.getFilesystemName(name);
            String original = multi.getOriginalFileName(name);
            String type = multi.getContentType(name);

        // while (files.hasMoreElements())
        {
        File file = multi.getFile(name);

        if (file != null)
        {
            SaveFile(name, type, isMultipart, filename, file);

            CreateThumbnail(file, original);

            addDataToDataBase(multi, original);
        }
        }
        }
        request.getRequestDispatcher(redirectPage).forward(request, response);
    }

    private void SaveFile(String name, String type, boolean isMultipart, String filename, File file) {
        DiskFileItem item = new DiskFileItem(name, type, isMultipart, filename, (int) file.length(), file);
        try {
            item.write(file);
        } catch (Exception e) {
        }
    }

    private void CreateThumbnail(File file, String original) 
    {
        final int thumbnailWidth = 100;
        final int thumbnailHeight = 100;
        final String thumbnailExt = "jpg";
        try
        {
            BufferedImage bi = Thumbnailator.createThumbnail(file, thumbnailWidth, thumbnailHeight); // retrieve image
            File outputfile = new File(fileUploadDirectory + fileTools.createThumbNail(original));
            ImageIO.write(bi, thumbnailExt, outputfile);
        } catch (IOException e)
        {
        }
    }

    private void addDataToDataBase(MultipartRequest multi, String fileName) 
    {
        final String dateFormat = "dd/MM/yyyy";
        ImageFile imageFile = new ImageFile();
        //TODO: get current Date
        SimpleDateFormat dateformat = new SimpleDateFormat(dateFormat);
        Date newDate = new Date();
        String newdate = dateformat.format(newDate);

        int isHidden = 0;
        if (multi.getParameter(fileOption) != null) {
            isHidden = 1;
        }

        imageFile.setCreateDate(newdate);
        imageFile.setFileDescription(multi.getParameter(imageDescription));
        imageFile.setFileName(fileName);
        imageFile.setFileTitle(multi.getParameter(imageTitle));
        imageFile.setThumbName(fileTools.createThumbNail(fileName));
        imageFile.setIsHidden(isHidden);

        try {
            (new ImageFileController()).Save(imageFile);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(fileUploadServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(fileUploadServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "file upload servlet";
    }// </editor-fold>
}
