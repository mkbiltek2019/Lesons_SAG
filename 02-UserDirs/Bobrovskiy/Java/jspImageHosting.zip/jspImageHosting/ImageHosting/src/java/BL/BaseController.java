package BL;
import java.sql.SQLException;
import java.util.List;


public abstract class BaseController<Model, DataProvider>
{
protected DataProvider dataProvider;
public abstract List<Model> GetAll() throws ClassNotFoundException, SQLException ;
public abstract void Delete(Model model) throws ClassNotFoundException, SQLException ;
public abstract Integer Save(Model model) throws ClassNotFoundException, SQLException ;
public abstract Model GetById(Integer id) throws ClassNotFoundException, SQLException ;


}