package Entities;

public class EntityBase {

    private Integer id;

    public EntityBase(Integer id) {
        this.id = id;
    }

    public Integer getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }
}
