package BL;

import DAL.CommentDataProvider;
import Entities.Comment;
import java.sql.SQLException;
import java.util.List;

public class CommentController extends BaseController<Comment, CommentDataProvider> {

    public CommentController() {
        dataProvider = new CommentDataProvider();
    }

    @Override
    public void Delete(Comment comment) throws ClassNotFoundException, SQLException {
        dataProvider.Delete(comment);
    }

    @Override
    public List<Comment> GetAll() throws ClassNotFoundException, SQLException {
        return dataProvider.GetAll();
    }

    @Override
    public Comment GetById(Integer id) throws ClassNotFoundException, SQLException {
        return dataProvider.GetById(id);
    }

    @Override
    public Integer Save(Comment comment) throws ClassNotFoundException, SQLException {
        Integer result;
        if (comment.getid() == null) {
            result = dataProvider.Insert(comment);
        } else {
            result = dataProvider.Update(comment);
        }
        return result;
    }
}
