package Entities;

public class ImageFile extends EntityBase {

    private String fileName;
    private String thumbName;
    private String fileTitle;
    private String fileDescription;
    private String createDate;
    private Integer isHidden;

    public ImageFile() {
        super(null);
    }

    public String getFileName() {
        return fileName;
    }

    public String getThumbName() {
        return thumbName;
    }

    public String getFileTitle() {
        return fileTitle;
    }

    public String getFileDescription() {
        return fileDescription;
    }

    public String getCreateDate() {
        return createDate;
    }

    public Integer getIsHidden() {
        return isHidden;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setThumbName(String thumbName) {
        this.thumbName = thumbName;
    }

    public void setFileTitle(String fileTitle) {
        this.fileTitle = fileTitle;
    }

    public void setFileDescription(String fileDescription) {
        this.fileDescription = fileDescription;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setIsHidden(Integer isHidden) {
        this.isHidden = isHidden;
    }
}
