package DAL;

import Entities.ImageFile;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ImageFileDataProvider extends DataProviderBase<ImageFile> {

    private final String fn_id = "id";
    private final String fn_fileName = "fileName";
    private final String fn_thumbName = "thumbName";
    private final String fn_fileTitle = "fileTitle";
    private final String fn_fileDescription = "fileDescription";
    private final String fn_createDate = "createDate";
    private final String fn_isHidden = "isHidden";
    private final String sp_ImageFile_Delete = "EXECUTE [dbo].[ImageFile.Delete]  ?";
    private final String sp_ImageFile_GetAll = "EXECUTE [dbo].[ImageFile.GetAll]";
    private final String sp_ImageFile_GetById = "EXECUTE [dbo].[ImageFile.GetById]  ?";
    private final String sp_ImageFile_Insert = "EXECUTE [dbo].[ImageFile.Insert]  ?, ?, ?, ?, ?, ?";
    private final String sp_ImageFile_Update = "EXECUTE [dbo].[ImageFile.Update]  ?, ?, ?, ?, ?, ?, ?";

    @Override
    public List<ImageFile> GetAll() throws ClassNotFoundException, SQLException {
        List<ImageFile> result = new ArrayList<ImageFile>();
        Connection connection = null;
        try {
            connection = DbConnectionProvider.GetConnection();
            CallableStatement getAll = connection.prepareCall(sp_ImageFile_GetAll);
            ResultSet selectResult = getAll.executeQuery();
            while (selectResult.next()) {
                ImageFile imageFile = new ImageFile();
                imageFile.setid(selectResult.getInt(this.fn_id));
                imageFile.setFileName(selectResult.getString(this.fn_fileName));
                imageFile.setThumbName(selectResult.getString(this.fn_thumbName));
                imageFile.setFileTitle(selectResult.getString(this.fn_fileTitle));
                imageFile.setFileDescription(selectResult.getString(this.fn_fileDescription));
                imageFile.setCreateDate(null);//selectResult.getDate(this.fn_createDate).toString());
                imageFile.setIsHidden(selectResult.getInt(this.fn_isHidden));
                result.add(imageFile);
            }
            getAll.close();
        } catch (SQLException e) {
            // TODO: handle exceptions
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
        return result;
    }

    @Override
    public ImageFile GetById(Integer id) throws ClassNotFoundException, SQLException {
        ImageFile result = null;
        Connection connection = null;
        try {
            connection = DbConnectionProvider.GetConnection();
            CallableStatement getById = connection.prepareCall(sp_ImageFile_GetById);
            getById.setInt(this.fn_id, id);
            ResultSet selectResult = getById.executeQuery();
            while (selectResult.next()) {
                ImageFile imageFile = new ImageFile();
                imageFile.setid(selectResult.getInt(this.fn_id));
                imageFile.setFileName(selectResult.getString(this.fn_fileName));
                imageFile.setThumbName(selectResult.getString(this.fn_thumbName));
                imageFile.setFileTitle(selectResult.getString(this.fn_fileTitle));
                imageFile.setFileDescription(selectResult.getString(this.fn_fileDescription));
                imageFile.setCreateDate(selectResult.getDate(this.fn_createDate).toString());
                imageFile.setIsHidden(selectResult.getInt(this.fn_isHidden));

                result = imageFile;
                break;
            }
            getById.close();
        } catch (SQLException e) {
            // TODO: handle exceptions
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
        return result;
    }

    public void Delete(ImageFile imageFile) throws ClassNotFoundException, SQLException {

        Connection connection = null;
        try {
            connection = DbConnectionProvider.GetConnection();
            CallableStatement deleteCommand = connection.prepareCall(sp_ImageFile_Delete);
            deleteCommand.setInt(this.fn_id, imageFile.getid());
            int resut = deleteCommand.executeUpdate();

            deleteCommand.close();
        } catch (SQLException e) {
            // TODO: handle exceptions
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }

    @Override
    public Integer Insert(ImageFile imageFile) throws ClassNotFoundException, SQLException {
        Connection connection = null;
        int result = 0;

        try {
            connection = DbConnectionProvider.GetConnection();
            CallableStatement insert = connection.prepareCall(sp_ImageFile_Insert);

            insert.setString(this.fn_fileName, imageFile.getFileName());
            insert.setString(this.fn_thumbName, imageFile.getThumbName());
            insert.setString(this.fn_fileTitle, imageFile.getFileTitle());
            insert.setString(this.fn_fileDescription, imageFile.getFileDescription());
            insert.setString(this.fn_createDate, null);// imageFile.getCreateDate().toString());
            insert.setInt(this.fn_isHidden, imageFile.getIsHidden());

            result = insert.executeUpdate();
            insert.close();
        } catch (SQLException e) {
            // TODO: handle exceptions
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
        return result;
    }

    @Override
    public Integer Update(ImageFile imageFile) throws ClassNotFoundException, SQLException {
        Connection connection = null;
        int result = 0;

        try {
            connection = DbConnectionProvider.GetConnection();
            CallableStatement update = connection.prepareCall(sp_ImageFile_Update);
            update.setInt(this.fn_id, imageFile.getid());
            update.setString(this.fn_fileName, imageFile.getFileName());
            update.setString(this.fn_thumbName, imageFile.getThumbName());
            update.setString(this.fn_fileTitle, imageFile.getFileTitle());
            update.setString(this.fn_fileDescription, imageFile.getFileDescription());
            update.setString(this.fn_createDate, imageFile.getCreateDate().toString());
            update.setInt(this.fn_isHidden, imageFile.getIsHidden());
            result = update.executeUpdate();

            update.close();
        } catch (SQLException e) {
            // TODO: handle exceptions
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
        return result;
    }
}
