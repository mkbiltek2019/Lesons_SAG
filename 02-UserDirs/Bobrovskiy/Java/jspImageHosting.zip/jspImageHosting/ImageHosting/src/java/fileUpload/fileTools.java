/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fileUpload;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Администратор
 */
public class fileTools
{

    public static String createThumbNail(String fileName) {
        // throw new UnsupportedOperationException("Not yet implemented");
        return String.format("%s%s", "thumb_", fileName);
    }
     public static Boolean filterFileExtention(String fileName) {
        final String png = "png";
        final String jpg = ".jpg";
        final String gif = ".gif";
        final char fileExtentionSpliter = '.';
        List<String> extList = new ArrayList<String>();
        extList.add(png);
        extList.add(jpg);
        extList.add(gif);
        String fileExtention = "";

        if (!fileName.isEmpty() && fileName != null) {
            fileExtention = fileName.substring(fileName.indexOf(fileExtentionSpliter), fileName.length());
        }

        return extList.contains(fileExtention);
    }
}
