package Entities;

import java.sql.Date;

public class Comment extends EntityBase {

    private String comment;
    private Integer fileId;
    private Date createDate;

    public Comment() {
        super(null);
    }

    public String getComment() {
        return comment;
    }

    public Integer getFileId() {
        return fileId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setFileId(Integer fileId) {
        this.fileId = fileId;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}
