package BL;

import DAL.ImageFileDataProvider;
import Entities.ImageFile;
import java.sql.SQLException;
import java.util.List;

public class ImageFileController extends BaseController<ImageFile, ImageFileDataProvider> {

    public ImageFileController() {
        dataProvider = new ImageFileDataProvider();
    }

    @Override
    public void Delete(ImageFile imageFile) throws ClassNotFoundException, SQLException {
        dataProvider.Delete(imageFile);
    }

    @Override
    public List<ImageFile> GetAll() throws ClassNotFoundException, SQLException {
        return dataProvider.GetAll();
    }

    @Override
    public ImageFile GetById(Integer id) throws ClassNotFoundException, SQLException {
        return dataProvider.GetById(id);
    }

    @Override
    public Integer Save(ImageFile imageFile) throws ClassNotFoundException, SQLException {
        Integer result;
        if (imageFile.getid() == null) {
            result = dataProvider.Insert(imageFile);
        } else {
            result = dataProvider.Update(imageFile);
        }
        return result;
    }
}
