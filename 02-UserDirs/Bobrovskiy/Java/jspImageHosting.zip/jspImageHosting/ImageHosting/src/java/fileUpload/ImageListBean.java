package fileUpload;

import BL.ImageFileController;
import Entities.ImageFile;
import java.io.Serializable;
import java.util.List;

public class ImageListBean implements Serializable
{
    private List<ImageFile> imageCollection = null;
    private ImageFileController controller = new ImageFileController();;
    
    public void ImageListBean()
    {
        
    }

    public String getPath()
    {
        return "upload/";
    }

    public String getServerName()
    {
        return "http://localhost:8084/ImageHosting/";
    }

    public List<ImageFile> getImageList()
    {      
        try
        {
            imageCollection = controller.GetAll();
        }catch(Exception ex)
        {}
        
        return imageCollection;
    }

    private int id;
    private String thumbName;
    private String fileTitle;
    private String fileDescription;
    
    /**
     * @return the thumbName
     */
    public String getThumbName() {
        return thumbName;
    }

    /**
     * @param thumbName the thumbName to set
     */
    public void setThumbName(String thumbName) {
        this.thumbName = thumbName;
    }

    /**
     * @return the fileTitle
     */
    public String getFileTitle() {
        return fileTitle;
    }

    /**
     * @param fileTitle the fileTitle to set
     */
    public void setFileTitle(String fileTitle) {
        this.fileTitle = fileTitle;
    }

    /**
     * @return the fileDescription
     */
    public String getFileDescription() {
        return fileDescription;
    }

    /**
     * @param fileDescription the fileDescription to set
     */
    public void setFileDescription(String fileDescription) {
        this.fileDescription = fileDescription;
    }
   
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
