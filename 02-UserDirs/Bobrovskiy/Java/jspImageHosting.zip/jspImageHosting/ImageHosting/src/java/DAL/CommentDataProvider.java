package DAL; 
import Entities.Comment; 
import java.sql.SQLException;
import java.util.List;

public class CommentDataProvider extends DataProviderBase<Comment> 
{
	private final String fn_id = "id";
	private final String fn_comment = "comment";
	private final String fn_fileId = "fileId";
	private final String fn_createDate = "createDate";

    @Override
    public List<Comment> GetAll() throws ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Comment GetById(Integer id) throws ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Integer Insert(Comment client) throws ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Integer Update(Comment client) throws ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void Delete(Comment client) throws ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}