-- ================================================
use ImageRepository
go
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ImageFile.GetAll]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	SELECT
	  [id]
      ,[fileName]
      ,[thumbName]
      ,[fileTitle]
      ,[fileDescription]
      ,[createDate]
      ,[isHidden]
  FROM [ImageFile]
END
GO

--==============================================
CREATE PROCEDURE [dbo].[ImageFile.GetById]	
		@id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
	   [id]
      ,[fileName]
      ,[thumbName]
      ,[fileTitle]
      ,[fileDescription]
      ,[createDate]
      ,[isHidden]
  FROM [ImageFile]
  WHERE 
		[id]=@Id
END
GO

-- ==========================================
CREATE PROCEDURE [dbo].[ImageFile.Insert]	
	   @fileName nvarchar(100)
      ,@thumbName nvarchar(100)
      ,@fileTitle nvarchar(100)
      ,@fileDescription nvarchar(100)
      ,@createDate datetime
      ,@isHidden int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	INSERT INTO [ImageFile]
          ([fileName]
		  ,[thumbName]
		  ,[fileTitle]
		  ,[fileDescription]
		  ,[createDate]
		  ,[isHidden])
     VALUES
           (@fileName 
		  ,@thumbName 
		  ,@fileTitle 
		  ,@fileDescription 
		  ,@createDate 
		  ,@isHidden)
END
GO
-- ===========================================
CREATE PROCEDURE [dbo].[ImageFile.Update]	
	   @id int
	  ,@fileName nvarchar(100)
      ,@thumbName nvarchar(120)
      ,@fileTitle nvarchar(200)
      ,@fileDescription nvarchar(300)
      ,@createDate datetime
      ,@isHidden int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
   UPDATE [ImageFile]
   SET 
	   [fileName] = @fileName
	  ,[thumbName] = @thumbName
	  ,[fileTitle] = @fileTitle
	  ,[fileDescription] = @fileDescription
	  ,[createDate] = @createDate
	  ,[isHidden] = @isHidden

   WHERE [id] = @Id 
 
END
GO

--=================================================
CREATE PROCEDURE [dbo].[ImageFile.Delete]	
		@id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	DELETE FROM 
		[ImageFile]     
	WHERE 
		[id]=@id
END
GO