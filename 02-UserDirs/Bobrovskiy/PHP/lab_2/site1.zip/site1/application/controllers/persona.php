<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class persona extends CI_Controller
{
    function __construct()
	{
	}

    function index()
    {
        //$redirectUrl = 'hire/hireperson/';

        $pname = $this->input->post('department');
        echo     $pname;
        //$data = array('name' => $pname);
       //TODO: add validation rules for user name

       // if(is_string($pname)&&(strlen($pname)>0))
       // {
       //    $this->db->insert('people',$data);
       // }

        //redirect('http://localhost');
    }
}


 
