<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends CI_Controller {

	function __construct()
	{
		parent::__construct();
	}

	function index()
	{
        $this->load->model("tables/personTable");		
		
        $this->add();
        
        $data['personTable'] = $this->personTable->show();	
			
		$this->load->model("tables/departmentTable");
        $data['departmentTable'] = $this->departmentTable->show();

        $this->load->model("departmentmodel");
        $data['department'] = $this->departmentmodel->getAll();

		$this->load->view('site',$data);		
		       
	}

    function add()
    {
        $depname = $this->input->post('departmentName');
        //TODO: add validation rules for new department name
        $this->load->model("departmentmodel");

        if(is_string($depname)&&(strlen($depname)>0))
        {
          $this->departmentmodel->addRecord($depname);
        }

        $pname = $this->input->post('peopleName');

        $data = array('name' => $pname);
       //TODO: add validation rules for user name

        if(is_string($pname)&&(strlen($pname)>0))
        {
           $this->db->insert('people',$data);
        }
    }
	
	function deplist()
	{	
		$departmentid = $this->input->post('department');
				
		$this->load->model('employeeModel');
		
		$data['employeetable']=$this->employeeModel->getEmployees($departmentid);
		
		$this->load->view('employee',$data);
		//open view and pass table to that view
	
	}

}

/* End of file site.php */
/* Location: ./application/controllers/site.php */