<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class hire extends CI_Controller
{       
    function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{	
		$departmentid = $this->input->post('department');
		$positionid = $this->input->post('position');
		$personid = $this->input->post('personid');
		
		//TODO: validate id's
		$this->load->model('employeeModel');
		
		$this->employeeModel->addEmployee($departmentid, $personid, $positionid);
				
			
		echo "Працівник успішно доданий"."</br>";
		
		redirect("http://localhost");	
	}
	
	function hirePerson($personid)
	{	
		$this->load->model('positionmodel');
		$this->load->model('departmentmodel');
				
		$data['position'] = $this->positionmodel->getAll();
		$data['department'] = $this->departmentmodel->getAll();
		$data['personid'] = $personid;
				
		$this->load->view('hire',$data);		
	}    
    
}
 
