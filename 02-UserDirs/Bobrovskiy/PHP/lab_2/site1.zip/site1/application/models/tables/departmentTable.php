<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class departmentTable extends CI_Model
{
  function __construct()
  {
     parent::__construct();
     // Your own constructor code
  }

  function show()
  {
    $firstHeader = '����� �����';
	$secondHeader = '��������';
	$list = '������';
	$delete = '��������';
	$listRedirectUrl = 'hire/hireperson/';
	$deleteRedirectUrl = 'hire/hireperson/';

    $this->load->library('table');
	$this->load->model('departmentmodel');
    $peopleData = $this->departmentmodel->getDepartments();

    $this->table->clear();
    $this->table->set_heading($firstHeader, $secondHeader);

    foreach($peopleData as $row)
    {
       if($row!=null)
       {
         $this->table->add_row($row->name,
			  "<a href=".site_url($listRedirectUrl.$row->id,$row->id).">"
			  .$list."</a>"
			  ."<a href=".site_url($deleteRedirectUrl.$row->id,$row->id).">"
			  .$delete."</a>");
       }
     }

    return $this->table->generate();
  }

}