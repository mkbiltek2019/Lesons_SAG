<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class employeeModel extends CI_Model
{       
    function __construct()
	{
	}

    function getEmployees($departmentid)
    {
		$this->db->select('p.name, d.name');
		$this->db->from('people p');
		$this->db->where('e.departmentid', $departmentid);
		$this->db->join('employee e','e.peopleid = p.id');
		$this->db->join('employeeposition ep','e.positionid = ep.id');
		$this->db->join('department d','e.departmentid = d.id');
		
		$result = $this->db->get();
		$data[] = null;
		
        if($result->num_rows()>0)
        {
            foreach($result as $row)
            {
               $data[]=$row;
            }
        }
        
        return   $data;
    }
	
	function show($departmentid)
	{		
    $firstHeader = 'Імя працівника';
	$secondHeader = 'Відділ';	
	
    $this->load->library('table');   
    $peopleData = $this->getEmployees($departmentid);

    $this->table->clear();
    $this->table->set_heading($firstHeader,$secondHeader);

    foreach($peopleData as $row)
    {
       if($row!=null)
       {
         $this->table->add_row($row->name);			  
       }	   
     }
	
    return $this->table->generate();
  
	}
	
	function updatebyid($employeeid, $departmentid, $peopleid, $positionid)
	{
		$data=array('departmentid'=>$departmentid,
					'peopleid'=>$peopleid,
					'positionid'=> $positionid);

		$this->db->where('id',$employeeid);
		$this->db->update('employee',$data); 
	}
	
	function addEmployee($departmentid, $peopleid, $positionid)
	{
		$data=array('departmentid'=>$departmentid,
					'peopleid'=>$peopleid,
					'positionid'=> $positionid);
					
		$this->db->insert('employee', $data); 
	}
	
	function getdepartmentid($employeeid)
	{
		//$data = $this->db->get_where('employee', array('id' => $id), $limit, $offset);
		
		//return $data;
	}
	
	
	
	
	
   
}
 
