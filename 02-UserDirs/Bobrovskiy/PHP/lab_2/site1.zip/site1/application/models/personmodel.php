<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class personModel extends CI_Model
{       
    function __construct()
	{
	}

    function getAll()
    {
        $q= $this->db->query("SELECT id, name FROM people");
        $data[] = null;

        if($q->num_rows()>0)
        {
            foreach($q->result() as $row)
            {
               $data[]=$row;
            }
        }
        
        return   $data;
    }

    function addRecord($name)
    {
       $data = array('name' => $name);
       $this->db->insert('people',$data); 
    }    
}
 
