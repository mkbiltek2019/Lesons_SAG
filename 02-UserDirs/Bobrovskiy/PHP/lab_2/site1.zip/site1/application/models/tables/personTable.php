<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class personTable extends CI_Model
{
  function __construct()
  {
     parent::__construct();
     // Your own constructor code
  }

  function show()
  {
    $firstHeader = '��� ����������';
	$secondHeader = '��������';
	$btnName = '�������';
	$redirectUrl = 'hire/hireperson/';
	
    $this->load->library('table');   
    $peopleData = $this->personModel->getAll();

    $this->table->clear();
    $this->table->set_heading($firstHeader,$secondHeader);

    foreach($peopleData as $row)
    {
       if($row!=null)
       {
         $this->table->add_row($row->name,               
			  "<a href=".site_url($redirectUrl.$row->id,$row->id).">"
			  .$btnName."</a>");			  
       }	   
     }
	
    return $this->table->generate();
  }

}