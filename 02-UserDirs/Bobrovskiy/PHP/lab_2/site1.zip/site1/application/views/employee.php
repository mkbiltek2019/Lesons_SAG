<html lang="en">
<head>	
	<title> Відділ кадрів</title>
	<link rel="stylesheet" href="../../css/ui-lightness/jquery.ui.all.css">
	<script src="/jquery/ui/jquery-1.4.4.js"></script>
	<script src="/jquery/ui/jquery.ui.core.js"></script>
	<script src="/jquery/ui/jquery.ui.widget.js"></script>
	<script src="/jquery/ui/jquery.ui.tabs.js"></script>
	<script src="/jquery/ui/jquery.ui.button.js"></script>
	<link rel="stylesheet" href="/css/ui-lightness/jquery.ui.tabs.css">
    <link rel="stylesheet" href="../../css/ui-lightness/nice.css">

	<script>	
	
	$(function() {
	    $( "a,button", ".nice" ).button();

	    $("button").click(function() 
		{ 	
			//window.location.reload("\..\..\hire.php");	
		});

		$( "#tabs" ).tabs();
	});
	
	</script>	
	

</head>
<body>

<div class="nice">    

<div id="tabs">
	<ul>		
		<li><a href="#tabs-1">Працівники по відділу</a></li>
	</ul>

    <div id="tabs-1">
    <?php
         echo form_open();
         echo $employeetable."</br>"; 
		
         echo form_close();		 
		
    ?>
	 <a href="<?php echo base_url(); ?>">Повернутись</a>
    </div>     
     
</div>
</div>


</body>
</html>
