<html lang="en">
<head>	
	<title> Призначення відділу та посади</title>
	<link rel="stylesheet" href="/../css/ui-lightness/jquery.ui.all.css">
	<script src="/jquery/ui/jquery-1.4.4.js"></script>
	<script src="/jquery/ui/jquery.ui.core.js"></script>
	<script src="/jquery/ui/jquery.ui.widget.js"></script>
	<script src="/jquery/ui/jquery.ui.tabs.js"></script>
	<script src="/jquery/ui/jquery.ui.button.js"></script>
	<link rel="stylesheet" href="/css/ui-lightness/jquery.ui.tabs.css">
    <link rel="stylesheet" href="/../css/ui-lightness/nice.css">

	<script>	
	
	$(function() {
	    $( "a, button", ".nice" ).button();

	    $("button").click(function() 
		{ 			
				
		});		
	});
	
	</script>	
	

</head>
<body>

<div class="nice">  	  
	<div class="ui-state-highlight ui-corner-all" style=" margin-top: 20px; padding: 1.7em;">	
	 <?php
         echo form_open("http://localhost/index.php/hire/");
		 echo form_hidden('personid',$personid);
		 echo form_label("Найняти :".'$peopleName')."</br>";       
         echo form_label("На посаду :")
		 				.form_dropdown('position', 
		 				$position)."</br>";  
         echo form_label("У відділ :")
		 				.form_dropdown('department', 
		 				$department)."</br>";
		   
         echo "<button type=\"submit\">Додати</button>";
		 
         echo form_close();
     ?>	
	</div>	   
	   
	   <a href="<?php base_url(); >">Повернутись</a>
	  	  
</div>

</body>
</html>
