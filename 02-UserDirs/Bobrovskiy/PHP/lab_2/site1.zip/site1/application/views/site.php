<html lang="en">
<head>	
	<title> ³��� �����</title>
	<link rel="stylesheet" href="../../css/ui-lightness/jquery.ui.all.css">
	<script src="./jquery/ui/jquery-1.4.4.js"></script>
	<script src="./jquery/ui/jquery.ui.core.js"></script>
	<script src="./jquery/ui/jquery.ui.widget.js"></script>
	<script src="./jquery/ui/jquery.ui.tabs.js"></script>
	<script src="./jquery/ui/jquery.ui.button.js"></script>
	<link rel="stylesheet" href="/css/ui-lightness/jquery.ui.tabs.css">
    <link rel="stylesheet" href="../../css/ui-lightness/nice.css">

	<script>	
	
	$(function() {
	    $( "a,button", ".nice" ).button();

	    $("button").click(function() 
		{ 	
			//window.location.reload("\..\..\hire.php");	
		});

		$( "#tabs" ).tabs();
	});
	
	</script>	
	

</head>
<body>

<div class="nice">    

<div id="tabs">
	<ul>
		<li><a href="#tabs-1">�������� ����</a></li>
		<li><a href="#tabs-2">³����</a></li>
		<li><a href="#tabs-3">���������� �� �����</a></li>
	</ul>

    <div id="tabs-1">
    <?php		
         echo form_open();
         echo $personTable."</br>";
          $data = array(
              'name'        => 'peopleName',
              'id'          => 'peopleName',
              'value'       => '',
              'maxlength'   => '100',
              'size'        => '50'
            );
          
          $buttonData = array(
              'name'        => 'subm',
              'id'          => 'text',
              'value'       => '������');

         echo form_label("��� ������: ").
              form_input($data);
             
		 echo "<button type=\"submit\">������</button>";
         echo form_close();
    ?>
     </div>
     
     <div id="tabs-2">
           <?php
         echo form_open();
		 echo $departmentTable."</br>";
                   
          $depdata = array(
              'name'        => 'departmentName',
              'id'          => 'departmentName',
              'value'       => '',
              'maxlength'   => '100',
              'size'        => '50'
            );          

         echo form_label("�����: ").
              form_input($depdata);
             
		 echo "<button type=\"submit\">������</button>";	  
         echo form_close();
    ?>
     </div>

    <div id="tabs-3">
       <?php
         echo form_open("/site/deplist");		 

         echo "<p>".form_label("³��� :")
		 				.form_dropdown('department', $department)
                        ."</p>";
         echo "<button type=\"submit\">�����������</button>";

         echo form_close();        
       ?>
	  	  
    </div>
</div>
</div>


</body>
</html>
