﻿<html>
<head>
	<meta charset="utf-8">
</head>
<body>
	<h2>Список відділів<h2>
</body>
</html>