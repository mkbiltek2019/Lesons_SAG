<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class hire_controller extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $departmentid = $this->input->post('department');
        $positionid = $this->input->post('position');
        $name = $this->input->post('name');
        $id = $this->input->post('id');
        //TODO: validate id's
        $this->load->model('employee_model');

        $this->employee_model->updateById($id, $departmentid, $positionid, $name);

        redirect(base_url());
    }

    function hirePerson($employeeid) {
        $this->load->model('employee_model');
        $this->load->model('position_model');
        $this->load->model('department_model');

        $data['position'] = $this->position_model->getAll();
        $data['department'] = $this->department_model->getAll();
        $data['employeename'] = $this->employee_model->getNameById($employeeid);
        $data['employeeid'] = $employeeid;

        $this->load->view('hire_view', $data);
    }

    function firePerson($employeeid) {
        $this->load->model('employee_model');
        $this->employee_model->fire($employeeid);

        redirect(base_url());
    }

}