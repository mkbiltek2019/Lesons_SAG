<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class department_controller extends CI_Controller {

   function __construct() {
        parent::__construct();
   }

   function delete($departmentid)
   {
        $this->load->model('department_model');
        $this->load->model('employee_model');

        $this->department_model->deleteRecord($departmentid);
        
        $this->employee_model->updateDepartmentById($departmentid);
        
        redirect(base_url());
   }

}