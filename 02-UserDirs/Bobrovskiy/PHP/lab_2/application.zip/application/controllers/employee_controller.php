<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class employee_controller extends CI_Controller {

    function __construct() {
        parent::__construct();
        // Your own constructor code
    }

    function getList($id){		
     $this->load->model('tables/employee_table');
     $this->load->model('department_model');

     $data['employee_table'] = 
	  $this->employee_table->showFireList($id);
     $data['departmentName'] = $this->department_model->getNameById($id);

     $this->load->view('employee_view',$data);
    }


}