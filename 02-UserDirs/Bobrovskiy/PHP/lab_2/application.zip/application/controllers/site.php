<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Site extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->load->model("tables/employee_table");

        $this->add();

        $data['personTable'] = $this->employee_table->show();

        $this->load->model("tables/department_table");
        $data['department_table'] = $this->department_table->show();

       // $this->load->model("department_model");
       // $data['department'] = $this->department_model->getAll();

        $this->load->view('site_view', $data);
    }

    function add() {
      //  $this->load->library('form_validation');
       // $this->form_validation->set_rules('peopleName',
      //          'PeopleName',
      //          'trim|required|alpha_numeric|min_length[3]');

       // if ($this->form_validation->run() == FALSE) {
            $depname = $this->input->post('departmentName');
               
            //TODO: add validation rules for new department name

            if (is_string($depname) && (strlen($depname) >= 2)) {
                $this->load->model("department_model");
                $this->department_model->addRecord($depname);
            }

            $pname = $this->input->post('peopleName');

            //TODO: add validation rules for user name use form_validator

            if (is_string($pname) && (strlen($pname) > 2)) {
                $this->load->model("employee_model");
                $this->employee_model->addEmployee(0, 0, $pname);
                $pname = '';
            }
       // }
    }

    function deplist() {
        //$departmentid = $this->input->post('department');
        // $this->load->model('employeeModel');
        // $data['employeetable']=$this->employeeModel->getEmployees($departmentid);
        // $this->load->view('employee',$data);
        //open view and pass table to that view
    }

}

/* End of file site.php */
/* Location: ./application/controllers/site.php */