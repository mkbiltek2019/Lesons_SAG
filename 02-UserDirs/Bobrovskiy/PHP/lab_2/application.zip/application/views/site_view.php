<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title> Відділ кадрів</title>
	<link rel="stylesheet" href="../../css/ui-lightness/jquery.ui.all.css">
        <script type="text/javascript"  src="./jquery/ui/jquery-1.4.4.js"></script>
	<script type="text/javascript" src="./jquery/ui/jquery.ui.core.js"></script>
	<script type="text/javascript" src="./jquery/ui/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="./jquery/ui/jquery.ui.tabs.js"></script>
	<script type="text/javascript" src="./jquery/ui/jquery.ui.button.js"></script>
	<link rel="stylesheet" href="/css/ui-lightness/jquery.ui.tabs.css">
        <link rel="stylesheet" href="../../css/ui-lightness/nice.css">

        <script type="text/javascript" >
	
	$(function() {
	    $( "a,button", ".nice" ).button();
	    $("button").click(function() 
		{ 		
		});
	    $( "#tabs" ).tabs();
	});
	
	</script>	
	

</head>
<body>

<div class="nice">    

<div id="tabs">
	<ul>
		<li><a href="#tabs-1">Список незайнятих людей</a></li>
		<li><a href="#tabs-2">Відділи</a></li>		
	</ul>

    <div id="tabs-1">
    <?php		
         echo form_open();
         echo $personTable."</br>";
          $data = array(
              'name'        => 'peopleName',
              'id'          => 'peopleName',
              'value'       => '',
              'maxlength'   => '100',
              'size'        => '50'
            );
          
          $buttonData = array(
              'name'        => 'subm',
              'id'          => 'text',
              'value'       => 'Додати');

         echo form_label("Додати працівника: ").
              form_input($data);
             
	 echo "<button type=\"submit\">Додати</button>";
         echo form_close();
    ?>
     </div>
     
     <div id="tabs-2">
           <?php
         echo form_open();
		 echo $department_table."</br>";
                   
          $depdata = array(
              'name'        => 'departmentName',
              'id'          => 'departmentName',
              'value'       => '',
              'maxlength'   => '100',
              'size'        => '50'
            );          

         echo form_label("Додати новий відділ: ").
              form_input($depdata);
             
		 echo "<button type=\"submit\">Додати</button>";
         echo form_close();
    ?>
     </div>

</div>
</div>

</body>
</html>
