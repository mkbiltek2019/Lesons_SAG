<html lang="en">
<head>	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title> Призначення відділу та посади</title>
	<link rel="stylesheet" href="/../css/ui-lightness/jquery.ui.all.css">
        <script type="text/javascript"  src="/jquery/ui/jquery-1.4.4.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.core.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.tabs.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.button.js"></script>
	<link rel="stylesheet" href="/css/ui-lightness/jquery.ui.tabs.css">
        <link rel="stylesheet" href="/../css/ui-lightness/nice.css">

	<script type="text/javascript">
	
	$(function() {
	    $( "a, button", ".nice" ).button();

	    $("button").click(function() 
		{ 			
				
		});		
	});
	
	</script>	
	

</head>
<body>

<div class="nice">  	  
	<div class="ui-state-highlight ui-corner-all " style=" margin-top: 20px; padding: 1.7em;">
	 <?php
         echo form_open( base_url().'index.php/hire_controller/');
         echo form_hidden('name', $employeename);
         echo form_hidden('id', $employeeid);
	 echo '<p>'.form_label("Працівник :".$employeename)."</p>";
         echo '<p>'.form_label("Посада :")
                        .form_dropdown('position',
                        $position)."</p>";
         echo '<p>'.form_label("Відділ :")
                        .form_dropdown('department',
                        $department)."</p>";
		   
         echo "<button type=\"submit\">Найняти</button>";
		 
         echo form_close();
     ?>	
	</div>	   
	   
	   <a href="<?php echo base_url(); ?>">Повернутись</a>
	  	  
</div>

</body>
</html>
