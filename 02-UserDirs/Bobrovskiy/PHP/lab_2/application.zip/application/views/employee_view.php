<html lang="en">
<head>	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title> Призначення відділу та посади</title>
	<link rel="stylesheet" href="/../css/ui-lightness/jquery.ui.all.css">
    <script type="text/javascript"  src="/jquery/ui/jquery-1.4.4.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.core.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.tabs.js"></script>
	<script type="text/javascript" src="/jquery/ui/jquery.ui.button.js"></script>
	<link rel="stylesheet" href="/css/ui-lightness/jquery.ui.tabs.css">
    <link rel="stylesheet" href="/../css/ui-lightness/nice.css">

	<script type="text/javascript">
	
	$(function() {
	    $( "a, button", ".nice" ).button();

	    $("button").click(function() 
		{ 		
		});
            $( "#tabs" ).tabs();
	});
	
	</script>	
	

</head>
<body>

<div class="nice">  	  
	<div id="tabs">
	<ul>		
	   <li><a href="#tabs-2">
                   Список працівників відділу <?php echo '<strong>'.$departmentName.'</strong>'; ?>
               </a></li>
	</ul>

            <div id="tabs-1">
               <?php
                 echo form_open();

                 echo $employee_table;

                 echo form_close();
              ?>
            </div>	 	   
	
    <a href="<?php echo base_url()?>">Повернутись</a>
	</div>   
</div>

</body>
</html>
