<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class employee_table extends CI_Model {

    function __construct() {
        parent::__construct();       
    }

    function show() {
        $firstHeader = 'Імя працівника';
        $secondHeader = 'Операція';
        $btnName = 'Найняти';
        $redirectUrl = 'hire_controller/hireperson/';

        $this->load->library('table');
        $this->load->model('employee_model');
        $peopleData = $this->employee_model->getUnemployedPersons();

        $this->table->clear();
        $this->table->set_heading($firstHeader, $secondHeader);

        foreach ($peopleData as $row) {            
            if ($row != null) {
                $this->table->add_row($row->name,
                        "<a href=" . 
						site_url($redirectUrl.$row->id, $row->id) . ">"
                        . $btnName . "</a>");
            }
        }

        return $this->table->generate();
    }

    function showFireList($departmentid) {
        $firstHeader = 'Імя працівника';
        $secondHeader = 'Посада';
        $thirdHeader = 'Операція';
        $btnName = 'Звільнити';
        $redirectUrl = 'hire_controller/firePerson/';

        $this->load->library('table');
        $this->load->model('employee_model');
		
        $peopleData = $this->employee_model->getEmployeesByDepartmentId($departmentid);

        $this->table->clear();
        $this->table->set_heading($firstHeader, 
                                  $secondHeader,
                                  $thirdHeader);

        foreach ($peopleData->result() as $row) {
            if ($row != null) {
			
             $this->table->add_row($row->ename,
			           $row->pname,
            "<a href=" . site_url($redirectUrl.$row->id, $row->id).">"
                        . $btnName . "</a>");
            }
        }
		
        return $this->table->generate();
    }

}