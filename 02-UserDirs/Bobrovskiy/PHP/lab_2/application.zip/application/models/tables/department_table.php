<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class department_table extends CI_Model
{
  function __construct()
  {
     parent::__construct();
     // Your own constructor code
  }

  function show()
  {
    $firstHeader = 'Назва відділу';
    $secondHeader = 'Операція';
    $list = 'список працівників';
    $delete = 'видалити';
    $listRedirectUrl = 'employee_controller/getlist/';
    $deleteRedirectUrl = 'department_controller/delete/';

    $this->load->library('table');
    $this->load->model('department_model');
    $peopleData = $this->department_model->getDepartments();

    $this->table->clear();
    $this->table->set_heading($firstHeader, $secondHeader);

    foreach($peopleData as $row)
    {
       if($row!=null)
       {
         $this->table->add_row($row->name,
              "<a href=".site_url($listRedirectUrl.$row->id,$row->id).">"
              .$list."</a>"
              ."<a href=".site_url($deleteRedirectUrl.$row->id,$row->id).">"
              .$delete."</a>");
       }
     }

    return $this->table->generate();
  }

}