<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class employee_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    function getUnemployedPersons()
    {
        $q = $this->db->query("SELECT id, name 
                                FROM employee
                                WHERE departmentid=0 OR positionid=0");
        $data[] = null;

        if ($q->num_rows() > 0) {
            foreach ($q->result() as $row) {
                $data[] = $row;
            }
        }

        return $data;       
    }

    function getEmployeesByDepartmentId($departmentid)
    {
       $sql="SELECT e.id as id,
		    e.name as ename,
                    ep.name as pname
             FROM employee as e, employeeposition as ep
             WHERE e.departmentid= ? AND e.positionid=ep.id";
				
        $query = $this->db->query($sql, array($departmentid));	

        return $query;
    }

    function getNameById($employeeid)
    {
        $sql = "SELECT name FROM employee where id= ? LIMIT 1";
        $query = $this->db->query($sql, array($employeeid));
        $row = $query->row_array();        

        return $row['name'];
    }

    function show($departmentid) {
        $firstHeader = 'Імя працівника';
        $secondHeader = 'Відділ';

        $this->load->library('table');
        $peopleData = $this->getEmployees($departmentid);

        $this->table->clear();
        $this->table->set_heading($firstHeader, $secondHeader);

        foreach ($peopleData as $row) {
            if ($row != null) {
                $this->table->add_row($row->name);
            }
        }

        return $this->table->generate();
    }

    function updateById($employeeid, $departmentid, $positionid, $employeename) {
        $data = array('departmentid' => $departmentid,
                      'positionid' => $positionid,
                      'name' => $employeename);

        $this->db->where('id', $employeeid);
        $this->db->update('employee', $data);
    }

    function updateDepartmentById($departmentid) {
        $data = array('departmentid' => 0,
                      'positionid' => 0);

        $this->db->where('departmentid', $departmentid);
        $this->db->update('employee', $data);
    }

    function fire($employeeid)
    {
       $data = array('departmentid' => 0,
                      'positionid' => 0);

        $this->db->where('id', $employeeid);
        $this->db->update('employee', $data);
    }

    function addEmployee($departmentid, $positionid, $employeename)
    {
        $data = array('departmentid' => $departmentid,
                      'positionid' => $positionid,
                      'name' => $employeename);
       
        $this->db->insert('employee', $data);
    }

}

