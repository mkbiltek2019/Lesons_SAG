<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class department_model extends CI_Model {

    function __construct() {
         parent::__construct();
    }

    function getAll() {
        // this function used to generate data for dropdown
        $this->db->from('department');
        $this->db->order_by('id');
        $result = $this->db->get();
        $return = array();

        if ($result->num_rows() > 0) {
            $return[''] = 'Обіріть відділ:';

            foreach ($result->result_array() as $row) {
                $return[$row['id']] = $row['name'];
            }
        }

        return $return;
    }

    function getDepartments() {
        $q = $this->db->query("SELECT id, name FROM department");
        $data[] = null;

        if ($q->num_rows() > 0) {
            foreach ($q->result() as $row) {
                $data[] = $row;
            }
        }

        return $data;
    }

    function addRecord($name) {
        $data = array('name' => $name);
        $this->db->insert('department', $data);
    }

    function deleteRecord($id)
    {
        $this->db->delete('department', array('id' => $id));
    }

    function getNameById($departmetnid)
    {
        $sql = "SELECT name FROM department where id= ? LIMIT 1";
        $query = $this->db->query($sql, array($departmetnid));
        $row = $query->row_array();

        return $row['name'];
    }

}

