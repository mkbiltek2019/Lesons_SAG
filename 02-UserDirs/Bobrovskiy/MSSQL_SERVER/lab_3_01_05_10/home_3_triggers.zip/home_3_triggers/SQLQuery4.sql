USE [AdventureWorksLT2008]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[SalesLT.SalesOrderHeader.RestoreDeleted]	
	  @SalesOrderID   int = null,	 		

	@UpdatedID int OUTPUT
AS
BEGIN
    
	UPDATE  [SalesLT].[SalesOrderHeader]
	SET			
       [SalesLT].[SalesOrderHeader].[IsDeleted] = null		 
	FROM 
	    [AdventureWorksLT2008].[SalesLT].[SalesOrderHeader]
	WHERE
	    [AdventureWorksLT2008].[SalesLT].[SalesOrderHeader].[SalesOrderID] = @SalesOrderID		    

 RETURN @@IDENTITY;
END


GO

--DECLARE @RC int = 0
--DECLARE @SalesOrderID int = 71774
--DECLARE @UpdatedID int = null

---- TODO: Set parameter values here.

--EXECUTE @RC = [AdventureWorksLT2008].[dbo].[SalesLT.SalesOrderHeader.RestoreDeleted] 
--   @SalesOrderID
--  ,@UpdatedID OUTPUT
--GO

