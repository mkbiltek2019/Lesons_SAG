USE [AdventureWorksLT2008]
GO

/****** Object:  StoredProcedure [dbo].[SalesLT.Customer.Update]    Script Date: 05/16/2010 23:28:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[SalesLT.SalesOrderDetail.Update]	
	  @SalesOrderID   int = null,
	  @SalesOrderDetailID   int = null,
      @OrderQty       smallint = null,
      @ProductID      int = null,
      @UnitPrice      money = null,
      @UnitPriceDiscount   money = null,
      @rowguid      uniqueidentifier = null,
      @ModifiedDate     datetime = null,
      @IsDeleted     bit = null,		

	@UpdatedID int OUTPUT
AS
BEGIN
    
	UPDATE  [SalesLT].[SalesOrderDetail]
	SET
			[SalesOrderID] = @SalesOrderID
           ,[OrderQty] = @OrderQty
           ,[ProductID] = @ProductID
           ,[UnitPrice] = @UnitPrice
           ,[UnitPriceDiscount] = @UnitPriceDiscount
           ,[rowguid] = @rowguid
           ,[ModifiedDate] = @ModifiedDate
           ,[IsDeleted] = @IsDeleted			 
	FROM 
	    [AdventureWorksLT2008].[SalesLT].[SalesOrderDetail]
	WHERE
	   [SalesLT].[SalesOrderDetail].SalesOrderDetailID = @SalesOrderDetailID		    

 RETURN @@IDENTITY;
END

