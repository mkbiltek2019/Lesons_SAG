USE [AdventureWorksLT2008]
GO

/****** Object:  StoredProcedure [dbo].[SalesLT.Customer.Delete]    Script Date: 05/16/2010 23:39:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SalesLT.SalesOrderDetaile.Delete]
	@SalesOrderDetailID int = NULL,
	@AffectedRows int = 0 OUTPUT
AS
BEGIN
	DELETE FROM 
	      [SalesLT].[SalesOrderDetail]
	WHERE 
	      [SalesLT].[SalesOrderDetail].[SalesOrderDetailID] = @SalesOrderDetailID
	
	RETURN @@ROWCOUNT;
END

GO