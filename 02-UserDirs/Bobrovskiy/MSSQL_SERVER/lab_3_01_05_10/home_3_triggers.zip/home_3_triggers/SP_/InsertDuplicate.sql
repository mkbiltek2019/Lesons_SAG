USE [AdventureWorksLT2008]
GO

/****** Object:  StoredProcedure [dbo].[SalesLT.SalesOrderDetail.Insert]    Script Date: 05/17/2010 21:10:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[SalesLT.SalesOrderDetail.InsertDuplicate]	 
      @OrderQty       smallint = null,
      @ProductID      int = null,
      @UnitPrice      money = null,
      @UnitPriceDiscount   money = null,
      @rowguid      uniqueidentifier = null,
      @ModifiedDate     datetime = null,
      @IsDeleted     bit = null,	

	@InsertedID int OUTPUT
AS
BEGIN
    SET IDENTITY_INSERT [SalesLT].[SalesOrderDetail]  ON 

	INSERT INTO [SalesLT].[SalesOrderDetail](
	        [OrderQty]
           ,[ProductID]
           ,[UnitPrice]
           ,[UnitPriceDiscount]
           ,[rowguid]
           ,[ModifiedDate]
           ,[IsDeleted])
	VALUES(
	  @OrderQty       ,
      @ProductID     ,
      @UnitPrice     ,
      @UnitPriceDiscount  ,
      @rowguid ,
      @ModifiedDate     ,
      @IsDeleted      
	);
	
 SET IDENTITY_INSERT [SalesLT].[SalesOrderDetail]  OFF 
 
 RETURN @@IDENTITY;
END

GO


