USE [AdventureWorksLT2008]
GO

/****** Object:  StoredProcedure [dbo].[SalesLT.SalesOrderDetail.Update]    Script Date: 05/17/2010 00:53:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- 
-- =============================================
ALTER PROCEDURE [dbo].[SalesLT.SalesOrderDetail.Update]	
	  @SalesOrderID   int = null,
	  @SalesOrderDetailID   int = null,
      @OrderQty       smallint = null,
      @ProductID      int = null,
      @UnitPrice      money = null,
      @UnitPriceDiscount   money = null,
      @rowguid      uniqueidentifier = null,
      @ModifiedDate     datetime = null,
      @IsDeleted     bit = null,		

	@UpdatedID int OUTPUT
AS
BEGIN
    
	UPDATE  [SalesLT].[SalesOrderDetail]
	SET
			[SalesOrderID] = @SalesOrderID
           ,[OrderQty] = @OrderQty
           ,[ProductID] = @ProductID
           ,[UnitPrice] = @UnitPrice
           ,[UnitPriceDiscount] = @UnitPriceDiscount
           ,[rowguid] = @rowguid
           ,[ModifiedDate] = @ModifiedDate
           ,[IsDeleted] = @IsDeleted			 
	FROM 
	    [AdventureWorksLT2008].[SalesLT].[SalesOrderDetail]
	WHERE
	   [SalesLT].[SalesOrderDetail].SalesOrderDetailID = @SalesOrderDetailID		    

 RETURN @@IDENTITY;
END


GO


--USE [AdventureWorksLT2008]
--GO

--ALTER TABLE [SalesLT].[SalesOrderHeader]  
--WITH CHECK ADD  
--CONSTRAINT [CK_SalesOrderHeader_SubTotal] CHECK  (([SubTotal]>=(0.00)))
--GO

--ALTER TABLE [SalesLT].[SalesOrderHeader] 
--CHECK CONSTRAINT [CK_SalesOrderHeader_SubTotal]
--GO

--EXEC sys.sp_addextendedproperty 
--@name=N'MS_Description', 
--@value=N'Check constraint [SubTotal] >= (0.00)' ,
-- @level0type=N'SCHEMA',
-- @level0name=N'SalesLT', 
-- @level1type=N'TABLE',
-- @level1name=N'SalesOrderHeader',
-- @level2type=N'CONSTRAINT',
-- @level2name=N'CK_SalesOrderHeader_SubTotal'
--GO
