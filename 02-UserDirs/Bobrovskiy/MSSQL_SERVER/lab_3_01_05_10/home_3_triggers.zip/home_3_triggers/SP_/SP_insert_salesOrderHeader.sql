USE [AdventureWorksLT2008]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- 
-- =============================================
CREATE PROCEDURE [dbo].[SalesLT.SalesOrderHeader.Insert]	 
       @SalesOrderID int = null
      ,@RevisionNumber tinyint = null
      ,@OrderDate datetime = null
      ,@DueDate datetime = null
      ,@ShipDate datetime = null
      ,@Status tinyint = null
      ,@OnlineOrderFlag bit = null
      ,@PurchaseOrderNumber nvarchar(25) = null
      ,@AccountNumber nvarchar(15) = null
      ,@CustomerID int = null
      ,@ShipToAddressID int = null
      ,@BillToAddressID int =null
      ,@ShipMethod  nvarchar(50) = null
      ,@CreditCardApprovalCode  varchar(15) = null
      ,@SubTotal money = null
      ,@TaxAmt  money = null
      ,@Freight  money = null
      ,@Comment varchar(max) = null
      ,@rowguid uniqueidentifier = null
      ,@ModifiedDate datetime = null
      ,@Is nchar(10) = null
      ,@IsDeleted bit = null	

	,@InsertedID int OUTPUT
AS
BEGIN
    SET IDENTITY_INSERT [SalesLT].[SalesOrderHeader]  ON 

	INSERT INTO [SalesLT].[SalesOrderHeader](
	   [SalesOrderID]
      ,[RevisionNumber]
      ,[OrderDate]
      ,[DueDate]
      ,[ShipDate]
      ,[Status]
      ,[OnlineOrderFlag]
      ,[PurchaseOrderNumber]
      ,[AccountNumber]
      ,[CustomerID]
      ,[ShipToAddressID]
      ,[BillToAddressID]
      ,[ShipMethod]
      ,[CreditCardApprovalCode]
      ,[SubTotal]
      ,[TaxAmt]
      ,[Freight]
      ,[Comment]
      ,[rowguid]
      ,[ModifiedDate]
      ,[Is]
      ,[IsDeleted])
	VALUES(
	   @SalesOrderID 
      ,@RevisionNumber 
      ,@OrderDate 
      ,@DueDate
      ,@ShipDate 
      ,@Status 
      ,@OnlineOrderFlag 
      ,@PurchaseOrderNumber 
      ,@AccountNumber 
      ,@CustomerID 
      ,@ShipToAddressID 
      ,@BillToAddressID 
      ,@ShipMethod  
      ,@CreditCardApprovalCode  
      ,@SubTotal 
      ,@TaxAmt  
      ,@Freight  
      ,@Comment 
      ,@rowguid 
      ,@ModifiedDate 
      ,@Is 
      ,@IsDeleted 	    
	);
	
 SET IDENTITY_INSERT [SalesLT].[SalesOrderHeader]  OFF 
 
 RETURN @@IDENTITY;
END

GO


