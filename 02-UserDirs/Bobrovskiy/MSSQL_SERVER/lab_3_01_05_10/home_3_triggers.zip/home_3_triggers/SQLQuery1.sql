--1. �������� ������� ���� ���� 
--�������������� ������ ��������� ������ � 
--�������� SalesOrderDetail, SalesOrderHeader

USE [AdventureWorksLT2008]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- !!!!! before using trigger update have to delete CK_SalesOrderHeader_SubTotal
-- because insert operation 

ALTER TRIGGER [SalesLT].[SalesOrderDetail.FirtsSoftDelete] 
ON [SalesLT].[SalesOrderDetail] 
FOR DELETE
AS
BEGIN
	
	IF @@ROWCOUNT = 0 -- ��������� ������� ���
	RETURN
-- ===========================
    DECLARE @RC int = 0
	DECLARE @SalesOrderID int = (SELECT TOP 1 SalesOrderID FROM Deleted)
	DECLARE @SalesOrderDetailID int = (SELECT TOP 1 SalesOrderDetailID FROM Deleted)
	DECLARE @OrderQty smallint = (SELECT TOP 1 OrderQty FROM Deleted)
	DECLARE @ProductID int = (SELECT TOP 1 ProductID FROM Deleted)
	DECLARE @UnitPrice money = (SELECT TOP 1 UnitPrice FROM Deleted)
	DECLARE @UnitPriceDiscount money = (SELECT TOP 1 UnitPriceDiscount FROM Deleted)
	DECLARE @rowguid uniqueidentifier = NEWID()
	DECLARE @ModifiedDate datetime  = GETDATE()
	DECLARE @IsDeleted bit = 1
	DECLARE @InsertedID int = 0

	EXECUTE @RC = [AdventureWorksLT2008].[dbo].[SalesLT.SalesOrderDetail.Insert] 
	 @SalesOrderID
	,@SalesOrderDetailID
	,@OrderQty
	,@ProductID
	,@UnitPrice
	,@UnitPriceDiscount
	,@rowguid
	,@ModifiedDate
	,@IsDeleted
	,@InsertedID OUTPUT

-- ===========================
	IF @@ERROR != 0
	BEGIN
	  PRINT 'Error occurred during related titles' ROLLBACK TRAN
	END 

 
END;

--  usage delete for current trigger
--	DELETE FROM [AdventureWorksLT2008].[SalesLT].[SalesOrderDetail]
--      WHERE [SalesOrderDetail].SalesOrderDetailID = 110667
--GO


