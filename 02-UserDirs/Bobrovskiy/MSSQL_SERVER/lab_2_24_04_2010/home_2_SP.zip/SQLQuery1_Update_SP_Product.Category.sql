-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
USE [AdventureWorksLT2008]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
--1) �������� ��������� ��������� UPDATE
--   �� ��� �������� �� ������� Product.Category
--==============================================
CREATE PROCEDURE [dbo].[ProductCategory.Update]
	@ParentProductCategoryID int = NULL,
	@Name varchar(50) = null,
	@rowguid uniqueidentifier = null,
	@ModifiedDate datetime = null,

	@UpdatedID int OUTPUT
AS
BEGIN
	UPDATE [AdventureWorksLT2008].[SalesLT].[ProductCategory]
	SET [ProductCategory].[Name] = @Name,
	    [ProductCategory].[rowguid] = @rowguid,
	    [ProductCategory].[ModifiedDate] = @ModifiedDate
	FROM 
	    [AdventureWorksLT2008].[SalesLT].[ProductCategory]
	WHERE
	    [ProductCategory].[ProductCategoryID] = @ParentProductCategoryID
	

 RETURN @@IDENTITY;
END



--GO

--DECLARE	@return_value int,
--		@UpdatedID int

--SELECT	@UpdatedID = 1

--EXEC	@return_value = [dbo].[ProductCategory.Update]
--		@ParentProductCategoryID = 1,
--		@Name = N'Cool Bikes',
--		@rowguid = 'CFBDA25C-DF71-47A7-B81B-64EE161AA37C',
--		@ModifiedDate = N'2010-04-27',
--		@UpdatedID = @UpdatedID OUTPUT

--SELECT	@UpdatedID as N'@UpdatedID'

--SELECT	'Return Value' = @return_value

--GO