-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.

USE [AdventureWorksLT2008]
GO
-- ================================================
-- SP to delete customer from table [SalesLT].Customer by ID
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[SalesLT.Customer.Delete]
	@CustomerID int = NULL,
	@AffectedRows int = 0 OUTPUT
AS
BEGIN
	DELETE FROM 
	      [SalesLT].Customer
	WHERE 
	      [SalesLT].[Customer].[CustomerID] = @CustomerID
	
	RETURN @@ROWCOUNT;
END


--USE [AdventureWorksLT2008]
--GO

--DECLARE	@return_value int,
--		@AffectedRows int

--EXEC	@return_value = [dbo].[SalesLT.Customer.Delete]
--		@CustomerID = 1000,
--		@AffectedRows = @AffectedRows OUTPUT

--SELECT	@AffectedRows as N'@AffectedRows'

--SELECT	'Return Value' = @return_value

--GO
