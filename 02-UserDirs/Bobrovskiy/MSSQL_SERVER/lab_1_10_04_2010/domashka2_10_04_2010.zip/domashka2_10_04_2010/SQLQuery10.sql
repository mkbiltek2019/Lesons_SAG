--10. ����������� �������� � ������� 
--  �������� ���������� ������

select distinct
  Production.ProductModel.Name,
  Production.Product.Name,
  Production.Product.StandardCost,
  Production.Product.ListPrice,  
  Sales.SalesOrderDetail.UnitPriceDiscount,
  (Production.Product.ListPrice - Production.Product.StandardCost)*(1 - Sales.SalesOrderDetail.UnitPriceDiscount) as "Income"

from 
  Sales.SalesOrderHeader inner join 
   (Sales.SalesOrderDetail inner join
      (Sales.SpecialOfferProduct inner join 
          (Production.Product inner join Production.ProductModel 
           on Production.Product.ProductModelID =  Production.ProductModel.ProductModelID )
        on  Sales.SpecialOfferProduct.ProductID = Production.Product.ProductID) 
     on  Sales.SpecialOfferProduct.SpecialOfferID = Sales.SalesOrderDetail.SpecialOfferID)
  on  Sales.SalesOrderHeader.SalesOrderID = Sales.SalesOrderDetail.SalesOrderID
--where 
 --  Sales.SalesOrderDetail.UnitPriceDiscount> 0
order by
  Production.Product.StandardCost;
