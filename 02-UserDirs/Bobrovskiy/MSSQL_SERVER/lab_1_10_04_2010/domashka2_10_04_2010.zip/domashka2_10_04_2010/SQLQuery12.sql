--12. ��������� � ���� ����
-- ����� ������(Address.AddressLine2)
use AdventureWorks
go
select 
   Person.Contact.LastName,
   Person.Contact.LastName,
   Person.Contact.EmailAddress,
   Person.Contact.Phone,
   Person.Contact.AdditionalContactInfo
 from
   Person.Address inner join
   ( Sales.CustomerAddress inner join
        (Sales.Individual inner join Person.Contact 
        on  Sales.Individual.ContactID = Person.Contact.ContactID) 
     on  Sales.CustomerAddress.CustomerID = Sales.Individual.ContactID
   )
   on Person.Address.AddressID = Sales.CustomerAddress.AddressID

where
 Person.Address.AddressLine2 IS NULL