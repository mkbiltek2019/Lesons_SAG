-- 14. �������� � ����������� �����������

use AdventureWorks
go
select 
   Person.Contact.FirstName,
   Person.Contact.LastName,
   Person.Contact.EmailAddress,
   Person.Contact.Phone,
   Sales.SalesOrderDetail.UnitPrice,
   Sales.SalesOrderDetail.OrderQty,
   min(Sales.SalesOrderDetail.UnitPrice*Sales.SalesOrderDetail.OrderQty) as val
 from   
   Person.Contact 
    inner join
   ( Sales.SalesOrderHeader inner join  Sales.SalesOrderDetail on
     Sales.SalesOrderHeader.SalesOrderID = Sales.SalesOrderDetail.SalesOrderID        
   )
   on Person.Contact.ContactID =  Sales.SalesOrderHeader.ContactID 
  
group by
   Person.Contact.FirstName,
   Person.Contact.LastName,
   Person.Contact.EmailAddress,
   Person.Contact.Phone,
   Sales.SalesOrderDetail.UnitPrice,
   Sales.SalesOrderDetail.OrderQty
   
having ((Sales.SalesOrderDetail.UnitPrice*Sales.SalesOrderDetail.OrderQty)>=min(Sales.SalesOrderDetail.UnitPrice*Sales.SalesOrderDetail.OrderQty))

order by val


