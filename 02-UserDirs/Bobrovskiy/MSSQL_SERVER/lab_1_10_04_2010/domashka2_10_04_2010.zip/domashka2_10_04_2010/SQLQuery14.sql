-- 14. �������� � ����������� �����������

use AdventureWorks
go
select 
   Person.Contact.FirstName,
   Person.Contact.LastName,
   Person.Contact.EmailAddress,
   Person.Contact.Phone,
   Sales.SalesOrderDetail.UnitPrice,
   Sales.SalesOrderDetail.OrderQty,
   min(Sales.SalesOrderDetail.UnitPrice*Sales.SalesOrderDetail.OrderQty) as [The cheapest order Value]
 from   
   Person.Contact 
    inner join
   ( Sales.SalesOrderHeader inner join  Sales.SalesOrderDetail on
     Sales.SalesOrderHeader.SalesOrderID = Sales.SalesOrderDetail.SalesOrderID        
   )
   on Person.Contact.ContactID =  Sales.SalesOrderHeader.ContactID 
  
group by
   Person.Contact.FirstName,
   Person.Contact.LastName,
   Person.Contact.EmailAddress,
   Person.Contact.Phone,
   Sales.SalesOrderDetail.UnitPrice,
   Sales.SalesOrderDetail.OrderQty
   
having min(Sales.SalesOrderDetail.UnitPrice*Sales.SalesOrderDetail.OrderQty)<= ALL(
	select 
       Sales.SalesOrderDetail.UnitPrice*Sales.SalesOrderDetail.OrderQty
    from   
	   Person.Contact 
		inner join
	   ( Sales.SalesOrderHeader inner join  Sales.SalesOrderDetail on
		 Sales.SalesOrderHeader.SalesOrderID = Sales.SalesOrderDetail.SalesOrderID        
	   )
	   on Person.Contact.ContactID =  Sales.SalesOrderHeader.ContactID 
);

