-- 8. ��� ���������(Customer), 
-- � �������� ������ � ���� "Washington". ������� Customer, 
-- Address(StateProvince, AddressType)

use AdventureWorks
go
select top 1000
  Person.Contact.FirstName, Person.Contact.MiddleName, Person.Contact.LastName,
  Person.Contact.Phone, Person.Contact.EmailAddress, Person.Contact.AdditionalContactInfo,
  Person.StateProvince.Name, Person.AddressType.Name
from 
  Sales.Customer inner join 
   (Sales.Individual inner join Person.Contact on 
    Sales.Individual.ContactID = Person.Contact.ContactID) on
  Sales.Customer.CustomerID = Sales.Individual.CustomerID,
  
  Sales.SalesTerritory inner join Person.StateProvince on
  Sales.SalesTerritory.TerritoryID = Person.StateProvince.TerritoryID,
  
  Sales.CustomerAddress inner join Person.AddressType on
  Sales.CustomerAddress.AddressTypeID = Person.AddressType.AddressTypeID    
  
where 
  Person.AddressType.Name Like 'Main Office' AND
  Person.StateProvince.Name Like 'Washington'