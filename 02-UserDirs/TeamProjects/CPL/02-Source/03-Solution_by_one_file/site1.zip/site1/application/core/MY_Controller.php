<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    //every controller must inherite MY_Controller
    //to provide some functionality for every controller
    function __construct()
    {
        parent::__construct();
        $emptydata = '';
        $this->main->create($emptydata);
    }
}