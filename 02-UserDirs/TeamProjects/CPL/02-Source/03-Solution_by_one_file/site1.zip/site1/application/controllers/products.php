<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class products extends MY_Controller
{ 
    function __construct()
    {
        parent::__construct();      
    }

    private function _generateCategoryTable()
    {
        $this->load->model('category_model');
        $this->load->model('tables/category_table');
        $categorylist = $this->category_model->getCategories();
        return $this->category_table->generate($categorylist);
    }
    private function _generateProductTable($categoryid)
    {
        $this->load->model('product_model');
        $this->load->model('tables/product_table'); 
        $productlist = $this->product_model->getProductListByCategoryId($categoryid);
        return $this->product_table->generate($productlist);
    }

    private function _setViewData($viewname,$data)
    {
        $completeview = $this->load->view($viewname,$data,true);
        $this->main->reload($completeview);
    }

    function showproducts()
    {    
        $this->load->model('category_model'); 
        $defaultcategoryid = $this->category_model->getDefaultCategoryID();

        $this->showproduct($defaultcategoryid);
    }   

    function showproduct($categoryid)
    {        
        $data['producttable'] = $this->_generateProductTable($categoryid);  
        $data['categorytable'] = $this->_generateCategoryTable();

        $this->_setViewData('allproducts',$data);
    }

    function showdetails($productid)
    {        
       $this->load->model('product_model');
       $this->load->model('tables/product_table'); 
       $productlist = $this->product_model->getProduct($productid);
       $data['producttable'] = $this->product_table->generatedetails($productlist);

       $data['categorytable'] = $this->_generateCategoryTable();

       $this->_setViewData('allproducts',$data);
    }
}
