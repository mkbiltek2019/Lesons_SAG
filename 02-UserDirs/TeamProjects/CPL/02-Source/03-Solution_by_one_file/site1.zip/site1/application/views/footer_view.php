<div class="art-footer">
<div class="art-footer-t"></div>
<div class="art-footer-l"></div>
<div class="art-footer-b"></div>
<div class="art-footer-r"></div>
<div class="art-footer-body">
<!--     <a href="#" class="art-rss-tag-icon" title="RSS"></a>-->
    <div class="art-footer-text">
        <p>Розроблено 2011<a href="http://bobrovsky.google.com"> Bobrovskiy V. V. </a></p>
    </div>
    <div class="cleared"></div>
</div>
</div>
