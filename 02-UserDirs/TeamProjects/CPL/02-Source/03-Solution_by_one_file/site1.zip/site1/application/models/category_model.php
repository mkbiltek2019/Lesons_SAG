<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class category_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    function getCategories()
    {
        $this->db->from('category');    	
    	$result = $this->db->get();
    	
        return $result;
    }

    function getDefaultCategoryID()
    {
        $singlefield = 1;
        $this->db->from('category');
        $this->db->limit($singlefield);//select only single field
    	$result = $this->db->get();

        $row = $result->row_array();

        return $row['id'];
    }
}
