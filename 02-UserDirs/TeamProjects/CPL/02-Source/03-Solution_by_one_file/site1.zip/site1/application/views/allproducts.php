
<div id="tabss">
    <ul>
        <li style="overflow: hidden;">
            <a href="#tabs-1">Категорії продуктів</a>
        </li>
    </ul>

    <div id="tabs-1" class="nice">
        <?php echo $categorytable; ?> 
    </div> 
</div>

<div id="container" class="nice">
    <?php echo $producttable; ?>    
</div>
<br/>
<div class="nice">
    <a href="<?php echo base_url();?>">Повернутись на домашню сторінку</a>
</div>



  

