<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class category_table extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function generate($categorylist)
    {
        $redirectUrl = 'products/showproduct/';

        $this->load->library('table');

        $this->table->set_template($this->createtabletemplate());
        $this->table->clear();
        $this->table->set_heading('', '', '', '');

        foreach ($categorylist->result() as $row) {
            if ($row != null) {
                $this->table->add_row(               
                '<a href="'.site_url($redirectUrl.$row->id,$row->id) . '">'.$row->name.'</a>');
            }
        }

        return $this->table->generate();
    }

    function createtabletemplate() {
        $tmpl = array(
            'table_open' => '<div class="art-content-layout overview-table">',
            'heading_row_start' => '<div>',
            'heading_row_end' => '</div>',
            'heading_cell_start' => '<div>',
            'heading_cell_end' => '</div>',
            'row_start' => '<div class="art-layout-cell">
                             <div class="overview-table-inner">',
            'row_end' => '</div></div>',
            'cell_start' => '<div >
                            <div class="art-content-layout-row">',
            'cell_end' => '</div></div>',
            'row_alt_start' => '<div >
                                <div >',
            'row_alt_end' => '</div></div>',
            'cell_alt_start' => '<div >
                                 <div >',
            'cell_alt_end' => '</div></div>',
            'table_close' => '</div>'
        );

        return $tmpl;
    }

}