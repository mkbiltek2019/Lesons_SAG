<div class="art-content-layout">
<div class="art-content-layout-row">
<div class="art-layout-cell art-content">
    <div class="art-post">
        <div class="art-post-body">
    <div class="art-post-inner art-article">

    <!-- block-content -->
       <h1>Ласкаво просимо!</h1>
               <h2>Найсолодший шоколад тільки у нас.</h2>
    <!-- /block-content -->
    </div>
     </div>
    <div class="cleared"></div>

    </div>
</div>

</div>
</div>
