<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class product_table extends CI_Model {

    function __construct() {
        parent::__construct();
    }

     function generatedetails($productlist)
    {
        $thumbimagepath = base_url().'productimages/full/';
        $priceaddon = '.0 грн';

        $this->load->library('table');

        $this->table->set_template($this->createtabletemplate());
        $this->table->clear();
        $this->table->set_heading('', '', '', '');

        foreach ($productlist->result() as $row) {
            if ($row != null) {
                $this->table->add_row(
                '<img src="'.$thumbimagepath.$row->imagename.
                '" width="400px" height="400px" alt="an image" class="image" />'
                .$row->price.$priceaddon.
                '<p>'.$row->productname.'</p>'.
                '<p>'.$row->description.'</p>');
            }
        }

        return $this->table->generate();
    }

    function generate($productlist) {

        $btnName = 'Детальніший опис';
        $redirectUrl = 'products/showdetails/';
        $thumbimagepath = base_url().'productimages/thumbs/';
        $priceaddon = '.0 грн';

        $this->load->library('table');

        $this->table->set_template($this->createtabletemplate());
        $this->table->clear();
        $this->table->set_heading('', '', '', '');   

        foreach ($productlist->result() as $row) {
            if ($row != null) {
                $this->table->add_row(                
                '<img src="'.$thumbimagepath.$row->imagename.
                '" width="100px" height="100px" alt="an image" class="image" />'
                .$row->price.$priceaddon.
                '<p>'.$row->productname.'</p>'.
                '<p>'.$row->description.'</p>'.
                '<a href="'.site_url($redirectUrl.$row->id,$row->id) . '">'.$btnName.'</a>');
            }
        }

        return $this->table->generate();
    }

    function createtabletemplate() {
        $tmpl = array(
            'table_open' => '<div class="art-content-layout overview-table">',
            'heading_row_start' => '<div>',
            'heading_row_end' => '</div>',
            'heading_cell_start' => '<div>',
            'heading_cell_end' => '</div>',
            'row_start' => '<div class="ui-widget-content ui-corner-all">
                            <div class="art-content-layout-row">',
            'row_end' => '</div></div>',
            'cell_start' => '<div class="art-layout-cell">
                             <div class="overview-table-inner">',
            'cell_end' => '</div></div>',
            'row_alt_start' => '<div class="ui-widget-content ui-corner-all">
                                <div class="art-content-layout-row">',
            'row_alt_end' => '</div></div>',
            'cell_alt_start' => '<div class="art-layout-cell">
                                 <div class="overview-table-inner">',
            'cell_alt_end' => '</div></div>',
            'table_close' => '</div>'
        );

        return $tmpl;
    }

}