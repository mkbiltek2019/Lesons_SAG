<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class site extends MY_Controller
{  
    private $emptydata;
    
    function __construct()
    {
        parent::__construct();

        $this->emptydata = '';        
    } 

    function index()
    {
       $this->_generateDefaultView();
    }

    private function _generateDefaultView()
    {
        $data = $this->load->view('about_view','',true);
        $this->main->reload($data);
    }

    function home()
    {
        //load home page
        $this->_generateDefaultView();
    }   

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */