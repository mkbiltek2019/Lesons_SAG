<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class main
{
    private $data;
    private $menudata;
    private $emptydata;
    
    function create($startupdata)
    {
        $this->emptydata = '';        
        $this->CI =& get_instance();        
        $this->CI->load->library('parser');
        
        $this->setContentData($startupdata);
        $this->setHeaderFooterData();
        $this->setMenuData();   
    } 

    function loadview()
    {        
        $this->CI->parser->parse('site_view', $this->data);        
    }
    
    function setHeaderFooterData()
    {
       $emptydata['data'] = '';
       $this->data['header'] = $this->CI->parser->parse('header_view', $emptydata,true);//$this->CI->load->view('header_view', $emptydata, true);
       $this->data['footer'] = $this->CI->parser->parse('footer_view', $emptydata,true);//$this->CI->load->view('footer_view', $emptydata, true);
    }
    
    function setMenuData()
    {       
        $this->menudata['home'] = 'index.php/site/home';
        $this->menudata['products'] = 'index.php/products/showproducts';
        $this->menudata['about'] = 'index.php/site/about';
        
        $this->data['menu'] =
                    $this->CI->parser->parse('menu_view', $this->menudata,true);                    
    }
    
    function setContentData($viewcontent)
    {
        $concretecontent['concrete_content'] = $viewcontent;
        $this->data['content'] =
                    $this->CI->parser->parse('content_view', $concretecontent,true);
                   
        return $this->data;
    }

    function reload($data)
    {
        $this->setContentData($data);
        $this->loadview();
    }
    
}