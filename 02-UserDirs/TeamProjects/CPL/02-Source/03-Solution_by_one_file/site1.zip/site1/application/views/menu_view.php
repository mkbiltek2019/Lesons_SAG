<div class="art-nav">
    <div class="l"></div>
    <div class="r"></div>
    <ul class="art-menu">        
            
            <li>
                <a href="<?php echo base_url(); ?>{home}" class="active">
                    <span class="l"></span>
                    <span class="r"></span>
                    <span class="t">Домашня</span>
                </a>
            </li>
            
            <li>               
                <!--   add two sub items one -all products second - available products  -->
                 <a href="<?php echo base_url();?>{products}">
                     <span class="l"></span>
                     <span class="r"></span>
                     <span class="t">Продукція</span>
                 </a>
            </li>            
            
    </ul>
</div>