<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class sp_worker
{
    // usage $result = execute($spname, $parameter)
    //$result = execute( 'CALL MyProc(?)', array($parameter));
    function execute($spname, $parameter)
    {
      $this->CI =& get_instance();       

      $result = $this->CI->db->query($spname, $parameter);

      $this->_clean_mysqli_connection($this->CI->db->conn_id);
      return  $result;
    }

    private function _clean_mysqli_connection( $dbc )
    {
        while( mysqli_more_results($dbc) )
        {
            if(mysqli_next_result($dbc))
            {
                $result = mysqli_use_result($dbc);

                if(is_subclass_of($result, 'mysqli_stmt'))
                {
                    mysqli_stmt_free_result($result);
                }
                else
                {
                    unset($result);
                }
            }
        }
    }

}
