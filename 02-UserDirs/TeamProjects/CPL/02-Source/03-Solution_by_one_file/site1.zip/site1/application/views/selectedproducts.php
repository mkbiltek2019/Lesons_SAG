<div class="cleared"></div>
<div id="tabss">
    <ul>
        <li style="overflow: hidden;"><a href="#tabs-1">Filter</a></li>
        <li style="overflow: hidden;"><a href="#tabs-2">Search by</a></li>
    </ul>

    <div id="tabs-1">
       <?php
         echo form_open( base_url().'index.php/filter/data');
         echo '<p>'.form_label('Category :')
                   .form_dropdown('category', $category)
                   .form_label('&nbsp;&nbsp;&nbsp;Vendor :')
                   .form_dropdown('vendor', $vendor)
                   .'</p>';
         $data = array(
              'name'        => 'price',
              'id'          => 'price',
              'value'       => '',
              'maxlength'   => '100',
              'size'        => '40'
            );
         echo  '<p>'
               .form_label('Product price:')
               .form_input($data)
               .'</p>';

         echo '<div class="nice"><button type="submit">Search</button></div>';

         echo form_close();
     ?>
    </div>
    <div id="tabs-2">
      <?php
        echo form_open( base_url().'index.php/filter/search');
        $data = array(
              'name'        => 'productname',
              'id'          => 'productname',
              'value'       => '',
              'maxlength'   => '100',
              'size'        => '80'
            );

        echo '<div class="nice"><p>'
               .form_label('Product name:')
               .form_input($data)
               .'<button type="submit">Search</button>'.
             '</p></div>';
        echo form_close();
      ?>
    </div>

</div>

<div id="container" class="nice">
    <?php  echo $this->product_table->generate($records); ?>

</div>






