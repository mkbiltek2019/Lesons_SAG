<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class product_model extends CI_Model
{    
    function __construct()
    {
        parent::__construct();
    }

    function getProduct($productid)
    {
        $sql = 'call selectproductbyid(?)';
        $result = $this->sp_worker->execute($sql, array($productid));

        //$row = $result->row_array();
        
        return $result;
    }

    function getProductListByCategoryId($categoryid)
    {                
        $sql = 'call getProductlistbycategoryid(?)';        
        $result = $this->sp_worker->execute($sql, array($categoryid));

        return $result;
    }

//    function getall($contentid)
//    {
//        $this->load->library('pagination');
//        $this->load->model('tables/product_table');
//
//        $myconfig['base_url'] = base_url().'index.php/site/navigate2';
//        $myconfig['total_rows'] = $this->db->get('allproducts')->num_rows();
//        $myconfig['per_page'] = 5;
//        $myconfig['num_links'] = 5;
//        $myconfig['full_tag_open'] = '<div class="nice">';
//        $myconfig['full_tag_close'] = '</div>';
//
//        $this->pagination->initialize($myconfig);
//
//        $data['records']= $this->db->get('allproducts',
//                             $myconfig['per_page'],
//                             $contentid);
//       //add filter data
//        $this->load->model('category_model');
//        $this->load->model('vendor_model');
//
//        $data['category'] = $this->category_model->getAllForDropdown();
//        $data['vendor'] = $this->vendor_model->getAllForDropdown();
//
//        return $this->load->view('allproducts',$data, true);
//    }
//
//    function getavailable($contentid)
//    {
//        $this->load->library('pagination');
//        $this->load->model('tables/product_table');
//
//        $myconfig['base_url'] = base_url().'index.php/site/navigate3';
//        $myconfig['total_rows'] = $this->db->get('allproducts')->num_rows();
//        $myconfig['per_page'] = 5;
//        $myconfig['num_links'] = 5;
//        $myconfig['full_tag_open'] = '<div class="nice">';
//        $myconfig['full_tag_close'] = '</div>';
//
//        $this->pagination->initialize($myconfig);
//
//        $data['records']= $this->db->get('availabeproducts',
//                             $myconfig['per_page'],
//                             $contentid);
//        //add filter data
//        $this->load->model('category_model');
//        $this->load->model('vendor_model');
//
//        $data['category'] = $this->category_model->getAllForDropdown();
//        $data['vendor'] = $this->vendor_model->getAllForDropdown();
//
//        return $this->load->view('allproducts',$data, true);
//    }
//
//    function getProductById($id)
//    {
//        $sql = "SELECT p.id, p.name as productname,
//                       c.name as categoryname,
//                       p.price as price,
//                       p.longdescription as description,
//                       p.ingredients as ingredients,
//                       i.name path,
//                       p.fullimage as imagename,
//                       v.fullname as vendorname,
//                       v.address as vendoraddress
//                FROM product as p, category as c, imagepath as i, vendor as v
//                WHERE   p.categoryid = c.id and
//                        p.imagepathid=i.id  and
//                        p.vendorid=v.id  and
//                        p.id=? LIMIT 1";
//
//        $query = $this->db->query($sql, array($id));
//        $row = $query->row_array();
//
//        return $row;//$row['name'];
//    }
//
//    function filterData($categoryid, $vendorid, $price)
//    {
//        if(!is_numeric($categoryid))
//        {
//            $categoryid = '*';
//        }
//
//        if(!is_numeric($vendorid))
//        {
//            $vendorid = '*';
//        }
//
//        if(!is_numeric($price))
//        {
//            $price = 0;
//        }
//
//        $inputArray = array(
//            'categoryid' => $categoryid,
//            'vendorid' => $vendorid,
//            'price' => $price
//        );
//
//        $this->load->model('tables/product_table');
//
//        $sql = 'SELECT p.id, p.name as productname,
//                       c.name as categoryname,
//                       p.price as price,
//                       p.longdescription as description,
//                       p.ingredients as ingredients,
//                       i.name imagepath,
//                       p.fullimage as imagename,
//                       v.fullname as vendorname,
//                       v.address as vendoraddress
//                FROM product as p, category as c, imagepath as i, vendor as v
//                WHERE   p.categoryid = c.id and
//                        p.imagepathid=i.id  and
//                        p.vendorid=v.id  and
//                        p.categoryid LIKE ? and
//                        p.vendorid LIKE ? and
//                        p.price > ?
//                        ';
//
//        $data['records']= $this->db->query($sql, $inputArray);
//
//        //add filter data
//        $this->load->model('category_model');
//        $this->load->model('vendor_model');
//
//        $data['category'] = $this->category_model->getAllForDropdown();
//        $data['vendor'] = $this->vendor_model->getAllForDropdown();
//
//        return $this->load->view('selectedproducts',$data, true);
//    }
//
//    function searchdata($name)
//    {
//        $result = '';
//
//        if($name)
//        {
//          $inputArray = array('productname' => '%'.$name.'%');
//
//        $this->load->model('tables/product_table');
//
//        $sql = 'SELECT p.id, p.name as productname,
//                       c.name as categoryname,
//                       p.price as price,
//                       p.longdescription as description,
//                       p.ingredients as ingredients,
//                       i.name imagepath,
//                       p.fullimage as imagename,
//                       v.fullname as vendorname,
//                       v.address as vendoraddress
//                FROM product as p, category as c, imagepath as i, vendor as v
//                WHERE   p.categoryid = c.id and
//                        p.imagepathid=i.id  and
//                        p.vendorid=v.id  and
//                        p.name LIKE ?
//                        ';
//
//        $data['records']= $this->db->query($sql, $inputArray);
//
//        //add filter data
//        $this->load->model('category_model');
//        $this->load->model('vendor_model');
//
//        $data['category'] = $this->category_model->getAllForDropdown();
//        $data['vendor'] = $this->vendor_model->getAllForDropdown();
//
//        $result = $this->load->view('selectedproducts',$data, true);
//
//        }
//
//        return $result;
//    }
    
}
