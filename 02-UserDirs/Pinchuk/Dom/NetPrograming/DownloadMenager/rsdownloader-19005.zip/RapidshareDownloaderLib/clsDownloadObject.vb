﻿Imports System.Net
Imports System.Windows.Forms

Public Class clsDownloadObject
    Private WithEvents TimerWait As New Timer
    Private WithEvents Wb As New WebClient

    Private _isDownloading As Boolean = False
    Private isReadyToDownload As Boolean
    Private _WaitSeconds As Integer

    Public DestinationFile As String
    'Public WaitTime As Integer
    Public Mirrors As List(Of MirrorServer)
    Public SelectedMirror As MirrorServer

    Public Event ReadyToDownload(ByVal sender As clsDownloadObject)
    Public Event DownloadProgress(ByVal iProgress As Integer, ByVal sender As clsDownloadObject)
    Public Event DownloadCompleted(ByVal sender As clsDownloadObject, ByVal bCompleted As Boolean)

    Sub New(ByVal WaitTime As Integer, ByVal lMirrors As List(Of MirrorServer), ByVal iSize As Integer)
        _WaitSeconds = WaitTime / 1000
        TimerWait.Interval = WaitTime
        Mirrors = lMirrors
        SelectedMirror = lMirrors(0)
        DestinationFile = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\" _
                                                        & IO.Path.GetFileName(lMirrors(0).Url)

        Size = iSize
        TimerWait.Start()
    End Sub

    ''' <summary>
    ''' Start download file from Rapidshare Asynchronous
    ''' </summary>
    ''' <returns>Returns True If Download Started</returns>
    ''' <remarks></remarks>
    Function BeginDownload() As Boolean
        If Not _isDownloading And isReadyToDownload Then
            _isDownloading = True
            Wb.DownloadFileAsync(New Uri(SelectedMirror.Url), DestinationFile)
        End If

        Return _isDownloading
    End Function

    Sub CancelDownload()
        If Wb.IsBusy Then Wb.CancelAsync()
    End Sub

    Private Sub TimerWait_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TimerWait.Tick
        TimerWait.Stop()
        isReadyToDownload = True
        RaiseEvent ReadyToDownload(Me)
    End Sub

    Private Sub Wb_DownloadFileCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.AsyncCompletedEventArgs) Handles Wb.DownloadFileCompleted
        _isDownloading = False
        If e.Cancelled Or e.Error IsNot Nothing Then
            RaiseEvent DownloadCompleted(Me, False)
        Else
            RaiseEvent DownloadCompleted(Me, True)
        End If
    End Sub

    Private Sub Wb_DownloadProgressChanged(ByVal sender As Object, ByVal e As System.Net.DownloadProgressChangedEventArgs) Handles Wb.DownloadProgressChanged
        RaiseEvent DownloadProgress(e.ProgressPercentage, Me)
    End Sub

    Public ReadOnly Property WaitSeconds() As Integer
        Get
            Return _WaitSeconds
        End Get
    End Property

    Function IsDownloading() As Boolean
        Return _isDownloading
    End Function

    Private _Size As Integer
    Public Property Size() As Integer
        Get
            Return _Size
        End Get
        Set(ByVal value As Integer)
            _Size = value
        End Set
    End Property

End Class
