﻿Option Explicit On
Option Strict On
Imports System.Net
Imports System.Text.RegularExpressions

Public Class clsRsDownloadManager
    Private _DownloadAvailable As Boolean = False
    Private _Filename As String

    Public Enum UnavailableReasons
        AlreadyDownloading = 0
        FileDoesntExist = 1
    End Enum

#Region "Events"
    Public Event DownloadPrepared(ByVal sender As clsDownloadObject)

    Public Event TryLater(ByVal iMinutes As Short)

    Public Event DownloadUnavailable(ByVal eReason As UnavailableReasons)

    Public Event UnknownException(ByVal eError As Exception)



#End Region



    Private Function FindFreeServer(ByVal sHtml As String) As String
        Return Regex.Match(sHtml, "(?<=id=\""ff\""\saction=\"").*(?=\""\smethod)").Value
    End Function
    Private Function GetWaitingTime(ByVal sHtml As String) As Integer
        Return CInt(Regex.Match(sHtml, "(?<=var\sc=)\d+").Value)
    End Function
    Private Function GetSize(ByVal sHtml As String) As Integer
        Return CInt(Regex.Match(sHtml, "\d+(?=\sKB)").Value)
    End Function
    Private Function GetTryAgainTime(ByVal sHtml As String) As Object
        Return Regex.Match(sHtml, "\d+(?=\sminutes)").Value
    End Function
    Private Function GetMirrorServers(ByVal sHtml As String) As List(Of MirrorServer)
        Dim MirrorList As New List(Of MirrorServer)
        For Each M As Match In Regex.Matches(sHtml, "\<input.*name=\""mirror\"".*")
            MirrorList.Add(New MirrorServer(M.Value))
        Next
        Return MirrorList
    End Function

    Sub PrepareDownload(ByVal sRsLink As String)
        Dim Wb As New WebClient
        AddHandler Wb.DownloadStringCompleted, AddressOf DownloadStringCompleted
        Wb.DownloadStringAsync(New Uri(sRsLink))
    End Sub

    Private Sub DownloadStringCompleted(ByVal sender As Object, ByVal e As DownloadStringCompletedEventArgs)
        If Not e.Cancelled And e.Error Is Nothing Then

            Dim Url As String = FindFreeServer(e.Result)

            If Url = "" Then
                RaiseEvent DownloadUnavailable(UnavailableReasons.FileDoesntExist)
            Else
                Dim Wb As WebClient = DirectCast(sender, WebClient)
                AddHandler Wb.UploadStringCompleted, AddressOf UploadStringCompleted

                Wb.UploadStringAsync(New Uri(Url), "dl.start=Free")
            End If



        End If
    End Sub

    Private Sub UploadStringCompleted(ByVal sender As Object, ByVal e As UploadStringCompletedEventArgs)
        If Not e.Cancelled And e.Error Is Nothing Then

            Try
                Dim Obj As New clsDownloadObject((GetWaitingTime(e.Result) + 3) * 1000, _
                                                             GetMirrorServers(e.Result), GetSize(e.Result))
                RaiseEvent DownloadPrepared(Obj)
            Catch exCast As InvalidCastException
                Dim Time As Object = GetTryAgainTime(e.Result)
                If IsNumeric(Time) Then
                    RaiseEvent TryLater(CShort(Time))
                Else
                    If e.Result.ToLower.Contains("please wait until the download is completed") Then
                        RaiseEvent DownloadUnavailable(UnavailableReasons.AlreadyDownloading)
                    Else
                        RaiseEvent DownloadUnavailable(UnavailableReasons.FileDoesntExist)
                    End If
                End If
            Catch ex As Exception
                RaiseEvent UnknownException(ex)
            End Try
        End If
    End Sub

End Class
Public Class MirrorServer
    Public Name As String
    Public Url As String

    Sub New(ByVal sHtml As String)
        Name = Regex.Match(sHtml, "(?<=\>).*(?=\<br)").Value.Trim
        Url = Regex.Match(sHtml, "http\:\/\/.*(?=\\')").Value
    End Sub

End Class
