﻿Imports System.Net
Imports RapidshareDownloaderLib

Public Class MainForm

    Dim WithEvents RsMgr As New clsRsDownloadManager
    Dim CurrentDownload As clsDownloadObject

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Button1.Text = "Download" Then
            Label1.Text = "Preparing Download..."
            RsMgr.PrepareDownload(TextBox1.Text)
            Button1.Text = "Cancel"
            TextBox1.Enabled = False
        Else
            If CurrentDownload Is Nothing Then Exit Sub
            If CurrentDownload.IsDownloading Then CurrentDownload.CancelDownload()
            Label1.Text = "Cancelled.."
            Button1.Text = "Download"
            TextBox1.Enabled = True
        End If
    End Sub
 
    Private Sub RsMgr_DownloadPrepared(ByVal sender As clsDownloadObject) Handles RsMgr.DownloadPrepared
        'AddHandler sender.SecondsToWait, AddressOf SecondsToWait
        AddHandler sender.ReadyToDownload, AddressOf ReadyToDownload
        CurrentDownload = sender
        Label1.Text = sender.WaitSeconds & " Seconds to begin download.."
        Label2.Text = sender.Size & " KB"
    End Sub
    Private Sub RsMgr_DownloadUnavailable(ByVal eReason As RapidshareDownloaderLib.clsRsDownloadManager.UnavailableReasons) Handles RsMgr.DownloadUnavailable
        If eReason = clsRsDownloadManager.UnavailableReasons.AlreadyDownloading Then
            Label1.Text = "You're already downloading a file..."
        Else
            Label1.Text = "File doesn't exist!"
        End If
    End Sub
    Private Sub RsMgr_TryLater(ByVal iMinutes As Short) Handles RsMgr.TryLater
        Label1.Text = "Try again in " & iMinutes & " Minutes.."
        Button1.Text = "Download"
        TextBox1.Enabled = True
    End Sub


    Sub ReadyToDownload(ByVal sender As clsDownloadObject)
        AddHandler sender.DownloadProgress, AddressOf DownloadProgress
        AddHandler sender.DownloadCompleted, AddressOf DownloadCompleted
        sender.BeginDownload()
    End Sub
    Sub DownloadProgress(ByVal iProgress As Integer, ByVal sender As clsDownloadObject)
        ProgressBar1.Value = iProgress
        Label1.Text = "Downloading.."
    End Sub
    Sub DownloadCompleted(ByVal sender As clsDownloadObject, ByVal bCompleted As Boolean)
        Label1.Text = "Completed!"
        Button1.Enabled = True
        TextBox1.Enabled = True
    End Sub


End Class
