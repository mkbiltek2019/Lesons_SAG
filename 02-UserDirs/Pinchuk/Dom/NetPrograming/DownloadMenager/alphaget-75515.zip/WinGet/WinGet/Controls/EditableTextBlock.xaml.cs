﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AlphaGet.Controls
{
    /// <summary>
    /// Logica di interazione per EditableTextBlock.xaml
    /// </summary>
    public partial class EditableTextBlock : UserControl
    {
        public String DefaultForEmpy
        {
            get;
            set;
        }

        public EditableTextBlock()
        {
            InitializeComponent();
            DefaultForEmpy = "<empty>";
        }

        protected void txtblk_MouseDown(object sender, MouseButtonEventArgs e)
        {
            TextBox txt = (TextBox)((StackPanel)((TextBlock)sender).Parent).Children[1];
            txt.Visibility = Visibility.Visible;
            ((TextBlock)sender).Visibility = Visibility.Collapsed;

            txt.Text = ((TextBlock)sender).Text;
        }

        protected void txtbox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBlock tb = (TextBlock)((StackPanel)((TextBox)sender).Parent).Children[0];
            tb.Text = ((TextBox)sender).Text;
            tb.Visibility = Visibility.Visible;
            ((TextBox)sender).Visibility = Visibility.Collapsed;

            tb.Text = ((TextBox)sender).Text == "" ? DefaultForEmpy : ((TextBox)sender).Text;
        }
    }
}
