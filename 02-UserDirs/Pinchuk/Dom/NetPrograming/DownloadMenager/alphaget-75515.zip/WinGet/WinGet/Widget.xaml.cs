﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using Microsoft.WindowsAPICodePack.Shell;
using Microsoft.WindowsAPICodePack.Taskbar;

namespace AlphaGet
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class Widget : Window, INativeBehavioral
    {
        private NativeBehaviors m_NativeBehaviors;
        private MainWindow mainWindow;

        public Widget(MainWindow mainWin)
        {
            InitializeComponent();

            mainWindow = mainWin;
            // Snapping Windows
            m_NativeBehaviors = new NativeBehaviors(this);
            SnapToBehavior stb = new SnapToBehavior();
            stb.OriginalForm = this;
            NativeBehaviors.Add(stb);
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void changeSize(object sender, RoutedEventArgs e)
        {
            String name = ((MenuItem)sender).Name;
            switch (name)
            {
                case "size32":
                    this.Width = 32;
                    this.Height = 32;
                    size32.IsChecked = true;
                    size48.IsChecked = false;
                    size64.IsChecked = false;
                    size96.IsChecked = false;
                    size128.IsChecked = false;
                    break;
                case "size48":
                    this.Width = 48;
                    this.Height = 48;
                    size32.IsChecked = false;
                    size48.IsChecked = true;
                    size64.IsChecked = false;
                    size96.IsChecked = false;
                    size128.IsChecked = false;
                    break;
                case "size64":
                    this.Width = 64;
                    this.Height = 64;
                    size32.IsChecked = false;
                    size48.IsChecked = false;
                    size64.IsChecked = true;
                    size96.IsChecked = false;
                    size128.IsChecked = false;
                    break;
                case "size96":
                    this.Width = 96;
                    this.Height = 96;
                    size32.IsChecked = false;
                    size48.IsChecked = false;
                    size64.IsChecked = false;
                    size96.IsChecked = true;
                    size128.IsChecked = false;
                    break;
                case "size128":
                    this.Width = 128;
                    this.Height = 128;
                    size32.IsChecked = false;
                    size48.IsChecked = false;
                    size64.IsChecked = false;
                    size96.IsChecked = false;
                    size128.IsChecked = true;
                    break;

            }
        }

        private void openFolder_Click(object sender, RoutedEventArgs e)
        {
            Process.Start(AlphaGet.Properties.Settings.Default.downloadFolder);
        }

        private void image1_Drop(object sender, DragEventArgs e)
        {
            this.Focus();
            AddDownloads(e.Data.GetData("Text").ToString());
        }

        private void downloadCurrent_Click(object sender, RoutedEventArgs e)
        {
            AddDownloads(Clipboard.GetText());
        }

        private void AddDownloads(string links)
        {
            String[] separator = { Environment.NewLine };
            String[] downloads = links.Split(separator, StringSplitOptions.RemoveEmptyEntries);

            foreach (string link in downloads)
            {
                AddDownload(link);
            }
        }

        private void AddDownload(string link)
        {

            try
            {
                Uri uri = new Uri(link);

                /*if (((MenuItem)(downloadWindows.Items[0])).Name == "noDownloads")
                {
                    downloadWindows.Items.RemoveAt(0);
                }*/

                /*MenuItem item = new MenuItem();
                item.Header = e.Data.GetData("Text").ToString();

                downloadWindows.Items.Insert(0, e.Data.GetData("Text").ToString());*/

                //DownloadWindow window = new DownloadWindow(uri);
                //window.Show();
                //window.Focus();
            }
            catch (UriFormatException)
            {
                MessageBox.Show("Invalid URL: " + link, "WinGet Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Left = SystemParameters.PrimaryScreenWidth - this.Width - 16;
            this.Top = SystemParameters.PrimaryScreenHeight - this.Height - 150;
        }

        private void showInTaskBar_Click(object sender, RoutedEventArgs e)
        {
            this.ShowInTaskbar = AlphaGet.Properties.Settings.Default.showWidgetInTaskBar;
        }

        private void hide_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        public NativeBehaviors NativeBehaviors
        {
            get { return m_NativeBehaviors; }
        }

        private void autoStartWindows_Click(object sender, RoutedEventArgs e)
        {
         /*   if (AlphaGet.Properties.Settings.Default.autoStart)
            {
                autoStartWindows.IsChecked = false;
                AlphaGet.Properties.Settings.Default.autoStart = false;
               
            }
            else
            {
                autoStartWindows.IsChecked = true;
                AlphaGet.Properties.Settings.Default.autoStart = true;

            }*/
        }

        private void showMainWindow_Click(object sender, RoutedEventArgs e)
        {
            mainWindow.Show();
        }
    }
}