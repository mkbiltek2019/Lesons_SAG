﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AlphaGet.Controls
{
    /// <summary>
    /// Logica di interazione per Settings.xaml
    /// </summary>
    public partial class Settings : UserControl
    {
        public Settings()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //AlphaGet.Properties.Settings.Default.widgetSize = comboBox1.SelectedIndex;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            textBoxFolder.Text = AlphaGet.Properties.Settings.Default.downloadFolder;
            comboBox1.SelectedIndex = AlphaGet.Properties.Settings.Default.widgetSize;
            numericaUpDown1.Value = AlphaGet.Properties.Settings.Default.chunksNumber;
            comboBox2.SelectedIndex = AlphaGet.Properties.Settings.Default.userAgent;

            switch (AlphaGet.Properties.Settings.Default.startupMode)
            {
                case 0:
                    radioButton0.IsChecked = true;
                    break;
                case 1:
                    radioButton1.IsChecked = true;
                    break;
                case 2:
                    radioButton2.IsChecked = true;
                    break;
            }
        }

        private void comboBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBox2.SelectedIndex == comboBox2.Items.Count - 1)
            {
                button1.IsEnabled = true;
            }
            else
            {
                button1.IsEnabled = false;
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            UserAgentWindow window = new UserAgentWindow();
            if (window.ShowDialog() == true)
            {
                AlphaGet.Properties.Settings.Default.customUserAgent = window.textBox1.Text;
            }

        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            AlphaGet.Properties.Settings.Default.Save();
        }
    }
}
