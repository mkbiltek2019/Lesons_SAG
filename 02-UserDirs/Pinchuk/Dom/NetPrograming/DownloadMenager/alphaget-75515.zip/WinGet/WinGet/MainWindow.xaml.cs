﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Collections.ObjectModel;
using System.Net;
using Fluent;
using AlphaGet.Controls;

namespace AlphaGet
{
    /// <summary>
    /// Logica di interazione per FullView.xaml
    /// </summary>
    public partial class MainWindow : RibbonWindow
    {
        private Widget widget;
        private WebClient _webClient = new WebClient();
        private ObservableCollection<DownloadData> downloadCollection = new ObservableCollection<DownloadData>();

        public ObservableCollection<DownloadData> DownloadCollection { get { return downloadCollection; } }

        public MainWindow()
        {
            downloadCollection.Add(new DownloadData
            {
                Icon = Utils.GetAssoiciatedIcon(@"C:\Windows\System32\notepad.exe"),
                Status = "Downloading",
                Filenane = "PPP",
                Url = "PPP"
            });
            widget = new Widget(this);
            InitializeComponent();
        }

        private void AddDownload(string link)
        {
            Uri uri = new Uri(link);
                String fileName = System.IO.Path.Combine(AlphaGet.Properties.Settings.Default.downloadFolder, System.IO.Path.GetFileName(uri.LocalPath));
                downloadCollection.Add(new DownloadData
                {
                    Icon = Utils.GetAssoiciatedIcon(@"C:\Windows\System32\notepad.exe"),
                    Status = "Downloading",
                    Filenane = System.IO.Path.GetFileName(uri.LocalPath),
                    Url = uri.ToString()
                });
        }

        private void openFolder_Click(object sender, RoutedEventArgs e)
        {
            Process.Start(AlphaGet.Properties.Settings.Default.downloadFolder);
        }

        private void RibbonWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void showProgramWin_Click(object sender, RoutedEventArgs e)
        {
            this.Show();
        }

        private void showWidget_Click(object sender, RoutedEventArgs e)
        {
            widget.Show();
        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void menuNewCategory_Click(object sender, RoutedEventArgs e)
        {
            categoriesItem.Items.Insert(0, new EditableTextBlock());
        }

        private void detailsButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentChunksView.Visibility == System.Windows.Visibility.Collapsed)
            {
                currentChunksView.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                currentChunksView.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        private void addDownloadButton_Click(object sender, RoutedEventArgs e)
        {
            AddDownloadWindow downWin = new AddDownloadWindow();
            if (downWin.ShowDialog() == true)
            {
                
            }
        }

        private void RibbonWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (AlphaGet.Properties.Settings.Default.startupMode != 0)
            {
                this.Visibility = System.Windows.Visibility.Hidden;
                if (AlphaGet.Properties.Settings.Default.startupMode == 1)
                    widget.Show();
            }
        }


    }
}
