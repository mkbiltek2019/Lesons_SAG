﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AlphaGet.Controls
{
    /// <summary>
    /// Logica di interazione per NumericaUpDown.xaml
    /// </summary>
    public partial class NumericaUpDown : UserControl
    {
        public int Value
        {
            get;
            set;
        }

        public int MinValue
        {
            get;
            set;
        }
        public int MaxValue
        {
            get;
            set;
        }

        public NumericaUpDown()
        {
            Value = 0;
            MinValue = int.MinValue;
            MaxValue = int.MaxValue;
            InitializeComponent();
        }

        private void minus_Click(object sender, RoutedEventArgs e)
        {
            if (Value > MinValue)
                Value--;
            textBox1.Text = Value.ToString();
        }

        private void plus_Click(object sender, RoutedEventArgs e)
        {
            if (Value < MaxValue)
                Value++;
            textBox1.Text = Value.ToString();
        }

        private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            { 
               int newValue = int.Parse(textBox1.Text);

               if (newValue > MaxValue)
               {
                   textBox1.Text = Value.ToString();
                   return;
               }

               if (newValue < MinValue)
               {
                   textBox1.Text = Value.ToString();
                   return;
               }
               Value = newValue;
            }
            catch
            {
                textBox1.Text = Value.ToString();
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            textBox1.Text = Value.ToString();
        }
    }
}
