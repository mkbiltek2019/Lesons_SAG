﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AlphaGet
{
    /// <summary>
    /// Logica di interazione per UserAgentWindow.xaml
    /// </summary>
    public partial class UserAgentWindow : Window
    {
        public UserAgentWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            textBox1.Text = AlphaGet.Properties.Settings.Default.customUserAgent;
        }
    }
}
