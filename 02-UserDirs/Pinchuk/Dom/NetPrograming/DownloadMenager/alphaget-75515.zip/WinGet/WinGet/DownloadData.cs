﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Media;

namespace AlphaGet
{
    public class DownloadData
    {
        public string Status {get; set; }
        public ImageSource Icon { get; set; }
        public string Filenane { get; set; }
        public string Url { get; set; }
        public int Progress { get; set; }

    }
}