﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//M1k4
namespace AlphaGet
{
    public interface INativeBehavioral
    {
        NativeBehaviors NativeBehaviors { get; }
    }
}
