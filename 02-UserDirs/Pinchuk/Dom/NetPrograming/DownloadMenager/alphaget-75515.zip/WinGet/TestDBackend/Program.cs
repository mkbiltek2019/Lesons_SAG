﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AlphaGet;

namespace TestDBackend
{
    class Program
    {
        static void Main(string[] args)
        {
            HTTPDownloadProcessor downloader = new HTTPDownloadProcessor(@"C:\Prova", 20, new Uri("http://www.kernel.org/pub/linux/kernel/v2.6/ChangeLog-2.6.1"), "");

            Console.WriteLine(downloader.FileSize);
            Console.WriteLine(downloader.ChunkSize);
            downloader.StartDownload();
            Console.ReadKey();
        }
    }
}
