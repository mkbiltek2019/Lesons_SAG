/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Jobs
 File Name:FileCopyJobCreator.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using BitsDownloadMgr.Interop;
using System.Collections.ObjectModel;

namespace BitsDownloadMgr.Jobs
{
    /// <summary>
    /// Creates a new file copy job.  
    /// </summary>
	public partial class FileCopyJobCreator : Form, ICreateJob
	{
        /// <summary>
        /// Constructor
        /// </summary>
		public FileCopyJobCreator()
		{
			InitializeComponent();
		}
		private void FileCopyJobCreator_Load(object sender, EventArgs e)
		{
			
		}

        /// <summary>
        /// Collection of files to be copied. 
        /// </summary>
		public Collection<string> FilesToCopy
		{
			get
			{
                Collection<string> filesToCopy = new Collection<string>(); 
                foreach (string item in fileListBox.Items)
                {
                    filesToCopy.Add(item); 
                }
				return filesToCopy;
			}
		}

        /// <summary>
        /// Path to the destination folder
        /// </summary>
		public string DestinationFolder
		{
			get { return destFolderPath.Text.Trim(); }
		}

		#region ICreateJob Members

        /// <summary>
        /// Creates the job
        /// </summary>
        /// <param name="manager"></param>
        /// <param name="ownerWindow"></param>
        /// <returns></returns>
		public CopyJob CreateJob(CopyManager manager, IWin32Window ownerWindow)
		{
			if (this.ShowDialog() == DialogResult.OK)
			{
				Collection<FileInfo> fileInfoList = new Collection<FileInfo>();
				string targetFolder = FileUtilities.NormalizeDirectoryPath(this.DestinationFolder);
				System.IO.DirectoryInfo destDirectory =
					FileUtilities.GetDirectoryInfo(targetFolder, true); 
				foreach(string fileToCopy in FilesToCopy)
				{
					System.IO.FileInfo sourceFile = new System.IO.FileInfo(fileToCopy); 
					fileInfoList.Add(
						new FileInfo(
							sourceFile.FullName, 
							sourceFile.FullName.Replace(sourceFile.DirectoryName, destDirectory.FullName)));
				}
				CopyJob newJob =  manager.CreateJob(
					"File Copy Job", "File Copy Job", 
					BitsJobType.Download, BitsJobPriority.High);
				newJob.AddFiles(fileInfoList);
				return newJob; 
			}
			else { return null; }
		}

        /// <summary>
        /// Text Description 
        /// </summary>
		public string Description
		{
			get { return "File Copy Job"; }
		}

        /// <summary>
        /// Explanatory help text
        /// </summary>
		public string HelpText
		{
			get { return "Creates a copy job from individually selected files."; }
		}
		#endregion

		private void button1_Click(object sender, EventArgs e)
		{
			if (selectFilesDialog.ShowDialog() == DialogResult.OK)
			{
				//get the list of selected files.  
				foreach (string fileName in selectFilesDialog.FileNames)
				{
					if (!fileListBox.Items.Contains(fileName))
					{
						fileListBox.Items.Add(fileName); 
					}
				}
			}
		}

		private void fileListBox_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete)
			{
				if (fileListBox.SelectedItems.Count > 0)
				{
					if (MessageBox.Show(
						"Are you sure you want to remove the selected files from the job?", "Confirm File Removal",
						MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1,
                        this.RightToLeftLayout ? MessageBoxOptions.RightAlign & MessageBoxOptions.RtlReading : 0)
                        == DialogResult.Yes)
					{
						//Get the selected items.  
						//Have to do this because the selected items collection will change as we loop.  
						//this causes an exception.  
						string[] filesToDelete = new string[fileListBox.SelectedItems.Count];
						fileListBox.SelectedItems.CopyTo(filesToDelete, 0); 
						foreach (string fileToDelete in filesToDelete)
						{
							fileListBox.Items.Remove(fileToDelete); 
						}
					}
				}
			}
		}

		private void browseDestinationFolder_Click(object sender, EventArgs e)
		{
			string initialFolder;
			string dialogTitle;
			
			dialogTitle = "Select Destination Directory";
			
			initialFolder = destFolderPath.Text.Trim();

			//if there is nothing in the initial path, use the desktop.  
			if (initialFolder.Length == 0)
			{
				initialFolder = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop);
			}

			//now that we have the initial folder, show the Folder Browse dialog;
			folderBrowserDialog.Description = dialogTitle;
			folderBrowserDialog.SelectedPath = initialFolder;
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				destFolderPath.Text = folderBrowserDialog.SelectedPath;
			}
		}

        private void OKButton_Click(object sender, EventArgs e)
        {

        }
	}
}
