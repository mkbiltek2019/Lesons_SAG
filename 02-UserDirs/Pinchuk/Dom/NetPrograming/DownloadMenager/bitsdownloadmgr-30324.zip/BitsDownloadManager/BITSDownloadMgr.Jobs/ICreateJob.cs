/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Jobs
 File Name:ICreateJob.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using BitsDownloadMgr.Interop;

namespace BitsDownloadMgr.Jobs
{
    /// <summary>
    /// Interface for creating Download Jobs
    /// </summary>
	public interface ICreateJob
	{
		/// <summary>
		/// Creates a new CopyJob.
		/// </summary>
		/// <param name="manager">The manager that will be used to create the job</param>
		/// <param name="ownerWindow">The owner window for the operation</param>
		/// <returns>The newly created CopyJob or null if the job creation was cancelled by the user.</returns>
		CopyJob CreateJob(CopyManager manager, System.Windows.Forms.IWin32Window ownerWindow);

        /// <summary>
        /// Description of the Job Creator
        /// </summary>
		string Description
		{ get;}

        /// <summary>
        /// Help text for the user.
        /// </summary>
		string HelpText
		{ get;}

	}
}

