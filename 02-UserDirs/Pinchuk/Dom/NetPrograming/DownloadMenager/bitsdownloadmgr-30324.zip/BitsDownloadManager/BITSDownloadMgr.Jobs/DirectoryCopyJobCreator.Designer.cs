/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Jobs
 File Name:DirectoryCopyJobCreator.Designer.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

namespace BitsDownloadMgr.Jobs
{
    
	partial class DirectoryCopyJobCreator
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.destFolderPath = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.srcFolderPath = new System.Windows.Forms.TextBox();
			this.browseSourceFolder = new System.Windows.Forms.Button();
			this.browseDestinationFolder = new System.Windows.Forms.Button();
			this.cancelButton = new System.Windows.Forms.Button();
			this.OKButton = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.includeSubdirectoriesChk = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// destFolderPath
			// 
			this.destFolderPath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			this.destFolderPath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
			this.destFolderPath.Location = new System.Drawing.Point(109, 72);
			this.destFolderPath.Name = "destFolderPath";
			this.destFolderPath.Size = new System.Drawing.Size(317, 20);
			this.destFolderPath.TabIndex = 7;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 75);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(98, 15);
			this.label2.TabIndex = 6;
			this.label2.Text = "Destination Folder:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 49);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(77, 15);
			this.label1.TabIndex = 5;
			this.label1.Text = "Source Folder:";
			// 
			// srcFolderPath
			// 
			this.srcFolderPath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			this.srcFolderPath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
			this.srcFolderPath.Location = new System.Drawing.Point(109, 46);
			this.srcFolderPath.Name = "srcFolderPath";
			this.srcFolderPath.Size = new System.Drawing.Size(317, 20);
			this.srcFolderPath.TabIndex = 4;
			this.srcFolderPath.Validating += new System.ComponentModel.CancelEventHandler(this.sourceValidating);
			// 
			// browseSourceFolder
			// 
			this.browseSourceFolder.Location = new System.Drawing.Point(427, 46);
			this.browseSourceFolder.Name = "browseSourceFolder";
			this.browseSourceFolder.Size = new System.Drawing.Size(22, 20);
			this.browseSourceFolder.TabIndex = 8;
			this.browseSourceFolder.Text = "...";
			this.browseSourceFolder.Click += new System.EventHandler(this.browseForFolder);
			// 
			// browseDestinationFolder
			// 
			this.browseDestinationFolder.Location = new System.Drawing.Point(427, 72);
			this.browseDestinationFolder.Name = "browseDestinationFolder";
			this.browseDestinationFolder.Size = new System.Drawing.Size(22, 20);
			this.browseDestinationFolder.TabIndex = 9;
			this.browseDestinationFolder.Text = "...";
			this.browseDestinationFolder.Click += new System.EventHandler(this.browseForFolder);
			// 
			// cancelButton
			// 
			this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cancelButton.Location = new System.Drawing.Point(351, 98);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new System.Drawing.Size(75, 23);
			this.cancelButton.TabIndex = 10;
			this.cancelButton.Text = "Cancel";
			this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
			// 
			// OKButton
			// 
			this.OKButton.Location = new System.Drawing.Point(270, 98);
			this.OKButton.Name = "OKButton";
			this.OKButton.Size = new System.Drawing.Size(75, 23);
			this.OKButton.TabIndex = 11;
			this.OKButton.Text = "OK";
			this.OKButton.Click += new System.EventHandler(this.OKButton_Click);
			this.OKButton.Validating += new System.ComponentModel.CancelEventHandler(this.OKButton_Validating);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(12, 9);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(414, 37);
			this.label3.TabIndex = 12;
			this.label3.Text = "This will create a new BITS job that will copy all files from the source director" +
				"y to the destination directory.";
			// 
			// includeSubdirectoriesChk
			// 
			this.includeSubdirectoriesChk.AutoSize = true;
			this.includeSubdirectoriesChk.Checked = true;
			this.includeSubdirectoriesChk.CheckState = System.Windows.Forms.CheckState.Checked;
			this.includeSubdirectoriesChk.Location = new System.Drawing.Point(109, 101);
			this.includeSubdirectoriesChk.Name = "includeSubdirectoriesChk";
			this.includeSubdirectoriesChk.Size = new System.Drawing.Size(133, 19);
			this.includeSubdirectoriesChk.TabIndex = 13;
			this.includeSubdirectoriesChk.Text = "Include Subdirectories";
			// 
			// DirectoryCopyJobCreator
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.cancelButton;
			this.ClientSize = new System.Drawing.Size(450, 125);
			this.Controls.Add(this.includeSubdirectoriesChk);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.OKButton);
			this.Controls.Add(this.cancelButton);
			this.Controls.Add(this.browseDestinationFolder);
			this.Controls.Add(this.browseSourceFolder);
			this.Controls.Add(this.destFolderPath);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.srcFolderPath);
			this.Font = new System.Drawing.Font("Franklin Gothic Book", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Name = "DirectoryCopyJobCreator";
			this.Text = "Create Directory Copy Job";
			this.Load += new System.EventHandler(this.DirectoryCopyJobCreator_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox destFolderPath;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox srcFolderPath;
		private System.Windows.Forms.Button browseSourceFolder;
		private System.Windows.Forms.Button browseDestinationFolder;
		private System.Windows.Forms.Button cancelButton;
		private System.Windows.Forms.Button OKButton;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
		private System.Windows.Forms.CheckBox includeSubdirectoriesChk;
	}
}
