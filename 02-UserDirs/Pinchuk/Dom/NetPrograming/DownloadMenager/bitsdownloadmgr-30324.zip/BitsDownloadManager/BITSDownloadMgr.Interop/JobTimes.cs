/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Interop
 File Name:JobTimes.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using BitsDownloadMgr.Interop;
namespace BitsDownloadMgr.Interop
{
	public class JobTimes
	{
		//TODO: JobTimes implementation
		internal JobTimes(_BG_JOB_TIMES nativeObject)
		{
			CreationTime = DateTime.FromFileTime(nativeObject.CreationTime);
			ModificationTime = DateTime.FromFileTime(nativeObject.ModificationTime);
			TransferCompletionTime = DateTime.FromFileTime(nativeObject.TransferCompletionTime); 
		}

		private DateTime _creationTime;
		/// <summary>
		/// Time that the job was created. 
		/// </summary>
		public DateTime CreationTime
		{
			get { return _creationTime; }
			private set { _creationTime = value; }
		}

		private DateTime _modificationTime;
		/// <summary>
		/// Time when the job was last modified. 
		/// </summary>
		public DateTime ModificationTime
		{
			get { return _modificationTime; }
			private set { _modificationTime = value; }
		}

		private DateTime _transferCompletionTime;

		/// <summary>
		/// Time that the job completed transfer
		/// </summary>
		public DateTime TransferCompletionTime
		{
			get { return _transferCompletionTime; }
			private set { _transferCompletionTime = value; }
		}

		
	}
}

