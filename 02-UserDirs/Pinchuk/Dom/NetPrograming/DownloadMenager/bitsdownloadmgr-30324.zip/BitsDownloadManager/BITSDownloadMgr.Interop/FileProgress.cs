/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Interop
 File Name:FileProgress.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using BitsDownloadMgr.Interop;
namespace BitsDownloadMgr.Interop
{
	/// <summary>
	///	Details the progress of a specific file.
	/// </summary>
	/// <remarks>
	/// Wrapper wround the _BG_FILE_PROGRESS structure  
	/// </remarks>
	public class FileProgress
	{
		
		internal FileProgress(_BG_FILE_PROGRESS nativeObject)
		{
			BytesTotal = nativeObject.BytesTotal;
			BytesTransferred = nativeObject.BytesTransferred;
			Completed = nativeObject.Completed != 0; 
		}

		/// <summary>
		/// Total number of bytes for the file.
		/// </summary>
		private ulong _bytesTotal;

		public ulong BytesTotal
		{
			get { return _bytesTotal; }
			private set { _bytesTotal = value; }
		}

		
		/// <summary>
		/// Total number of bytes that have already been transferred. 
		/// </summary>
		private ulong _bytesTransferred;

		public ulong BytesTransferred
		{
			get { return _bytesTransferred; }
			private set { _bytesTransferred = value; }
		}


		public decimal PercentComplete
		{
			get
			{
				if (BytesTotal > 0)
				{
					return ((decimal)BytesTransferred / (decimal)BytesTotal) ;
				}
				else
				{
					return 0;
				}
			}
		}
		/// <summary>
		/// True if the file download has been completed. 
		/// </summary>
		private bool _completed;

		public bool Completed
		{
			get { return _completed; }
			private set { _completed = value; }
		}


	}
}

