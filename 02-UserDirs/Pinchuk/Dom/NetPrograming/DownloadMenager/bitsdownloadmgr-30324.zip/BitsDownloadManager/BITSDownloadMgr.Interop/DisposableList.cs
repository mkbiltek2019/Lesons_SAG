/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Interop
 File Name:DisposableList.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace BitsDownloadMgr.Interop
{
	/// <summary>
	/// Generic list class that also supports IDispose.
	/// Collection for objects that need to be disposed.  s
	/// </summary>
	public class DisposableCollection<T>:Collection<T>, IDisposable
        where T:IDisposable 
	{

		~DisposableCollection()
		{
			Dispose(false); 
		}
		#region IDisposable Members

		public void Dispose()
		{
			Dispose(true);
            GC.SuppressFinalize(this); 
		}
		private void Dispose(bool disposing)
		{
			if (disposing)
			{
				foreach (IDisposable containedItem in this)
				{
					containedItem.Dispose();
				}
                GC.SuppressFinalize(this);
			}
		}
		#endregion
    }
    [Serializable()]
    public class DisposableDictionary<TKey, TValue> : System.Collections.Generic.Dictionary<TKey, TValue>, IDisposable
        where TValue:IDisposable
    {
        public DisposableDictionary()
        {
        }
        protected DisposableDictionary(SerializationInfo info, StreamingContext context)
            : base(info, context) { }

        #region IDisposable Members

        ~DisposableDictionary()
        {
            Dispose(false); 
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this); 
        }
        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                foreach (IDisposable containedItem in this.Values)
                {
                    containedItem.Dispose(); 
                }
                GC.SuppressFinalize(this); 
            }
        }

        #endregion
    }
}

