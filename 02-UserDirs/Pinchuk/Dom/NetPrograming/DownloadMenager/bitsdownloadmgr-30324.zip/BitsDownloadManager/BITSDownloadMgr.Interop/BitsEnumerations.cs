/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Interop
 File Name:BitsEnumerations.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

namespace BitsDownloadMgr.Interop
{
	/// <summary>
	/// The BitsJobState enumeration type defines constant values for the 
	/// different states of a job
	/// </summary>
	public enum BitsJobState
	{
		/// <summary>
		/// Specifies that the job is in the queue and waiting to run. 
		/// If a user logs off while their job is transferring, the job 
		/// transitions to the queued state
		/// </summary>
		Queued = 0,

		/// <summary>
		/// Specifies that BITS is trying to connect to the server. If the 
		/// connection succeeds, the state of the job becomes 
		/// BG_JOB_STATE_TRANSFERRING; otherwise, the state becomes 
		/// BG_JOB_STATE_TRANSIENT_ERROR
		/// </summary>
		Connecting = 1,

		/// <summary>
		/// Specifies that BITS is transferring data for the job
		/// </summary>
		Transferring = 2,

		/// <summary>
		/// Specifies that the job is suspended (paused)
		/// </summary>
		Suspended = 3,

		/// <summary>
		/// Specifies that a non-recoverable error occurred (the service is 
		/// unable to transfer the file). When the error can be corrected, 
		/// such as an access-denied error, call the IBackgroundCopyJob::Resume 
		/// method after the error is fixed. However, if the error cannot be 
		/// corrected, call the IBackgroundCopyJob::Cancel method to cancel 
		/// the job, or call the IBackgroundCopyJob::Complete method to accept 
		/// the portion of a download job that transferred successfully.
		/// </summary>
		Error = 4,

		/// <summary>
		/// Specifies that a recoverable error occurred. The service tries to 
		/// recover from the transient error until the retry time value that 
		/// you specify using the IBackgroundCopyJob::SetNoProgressTimeout method 
		/// expires. If the retry time expires, the job state changes to 
		/// BG_JOB_STATE_ERROR
		/// </summary>
		TransientError = 5,

		/// <summary>
		/// Specifies that your job was successfully processed
		/// </summary>
		Transferred = 6,

		/// <summary>
		/// Specifies that you called the IBackgroundCopyJob::Complete method 
		/// to acknowledge that your job completed successfully
		/// </summary>
		Acknowledged = 7,

		/// <summary>
		/// Specifies that you called the IBackgroundCopyJob::Cancel method to 
		/// cancel the job (remove the job from the transfer queue)
		/// </summary>
		Canceled = 8,
	}

	/// <summary>
	/// The BitsJobType enumeration type defines constant values that you 
	/// use to specify the type of transfer job, such as download
	/// </summary>
	public enum BitsJobType
	{
		/// <summary>
		/// Specifies that the job downloads files to the client
		/// </summary>
		Download = 0,
        Upload =1, 
        UploadReply = 2,
	}

	/// <summary>
	/// The BitsJobProxyUsage enumeration type defines constant values 
	/// that you use to specify which proxy to use for file transfers
	/// </summary>
	public enum BitsJobProxyUsage
	{
		/// <summary>
		/// Use the proxy and proxy bypass list settings defined by each 
		/// user to transfer files
		/// </summary>
		Preconfigured = 0,

		/// <summary>
		/// Do not use a proxy to transfer files
		/// </summary>
		NoProxy = 1,

		/// <summary>
		/// Use the application's proxy and proxy bypass list to transfer files
		/// </summary>
		ProxyOverride = 2,
	}


	/// <summary>
	/// The BitsJobPriority enumeration type defines the constant values 
	/// that you use to specify the priority level of the job
	/// </summary>
	public enum BitsJobPriority
	{
		/// <summary>
		/// Transfers the job in the foreground
		/// </summary>
		Foreground = 0,

		/// <summary>
		/// Transfers the job in the background. This is the highest background 
		/// priority level. 
		/// </summary>
		High = 1,

		/// <summary>
		/// Transfers the job in the background. This is the default priority 
		/// level for a job
		/// </summary>
		Normal = 2,

		/// <summary>
		/// Transfers the job in the background. This is the lowest background 
		/// priority level
		/// </summary>
		Low = 3,
	}

	/// <summary>
	/// The BitsErrorContext enumeration type defines the constant values 
	/// that specify the context in which the error occurred
	/// </summary>
	public enum BitsErrorContext
	{
		/// <summary>
		/// An error has not occurred
		/// </summary>
		None = 0,

		/// <summary>
		/// The error context is unknown
		/// </summary>
		Unknown = 1,

		/// <summary>
		/// The transfer queue manager generated the error
		/// </summary>
		QueueManager = 2,

		/// <summary>
		/// The error was generated while the queue manager was 
		/// notifying the client of an event
		/// </summary>
		QueueManagerNotification = 3,

		/// <summary>
		/// The error was related to the specified local file. For example, 
		/// permission was denied or the volume was unavailable
		/// </summary>
		LocalFile = 4,

		/// <summary>
		/// The error was related to the specified remote file. 
		/// For example, the URL is not accessible
		/// </summary>
		RemoteFile = 5,

		/// <summary>
		/// The transport layer generated the error. These errors are general 
		/// transport failures; errors not specific to the remote file
		/// </summary>
		GeneralTransport = 6,
	}

	/// <summary>
	/// This BitsEnumJobTypes enumeration is used when enumeration 
	/// active BITS jobs to specify whether all jobs are enumerated or 
	/// only those owned by the current user.  
	/// </summary>
	public enum BitsEnumJobType
	{
		CurrentUser = 0, AllUsers = 1
	}


}
