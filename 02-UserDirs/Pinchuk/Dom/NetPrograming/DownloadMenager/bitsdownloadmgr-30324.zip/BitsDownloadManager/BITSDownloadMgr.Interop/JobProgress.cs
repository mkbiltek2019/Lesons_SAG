/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Interop
 File Name:JobProgress.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using BitsDownloadMgr.Interop;
namespace BitsDownloadMgr.Interop
{

	/// <summary>
	/// Details the progress of a job
	/// </summary>
	/// <remarks>
	/// Wrapper class around a _BG_JOB_PROGRESS structire.  
	/// </remarks>
	public sealed class JobProgress
	{
		
		internal JobProgress(_BG_JOB_PROGRESS nativeProgress)
		{
			BytesTotal = nativeProgress.BytesTotal; 
			BytesTransferred = nativeProgress.BytesTransferred; 
			FilesTotal= nativeProgress.FilesTotal; 
			FilesTransferred = nativeProgress.FilesTransferred ;
		}

		private ulong _bytesTotal;
		/// <summary>
		/// Total number of bytes for the job
		/// </summary>
		public ulong BytesTotal
		{
			get { return _bytesTotal; }
			private set { _bytesTotal = value; }
		}

		private ulong _bytesTransferred;

		/// <summary>
		/// Total number of bytes already transferred.  
		/// </summary>
		public ulong BytesTransferred
		{
			get { return _bytesTransferred; }
			private set { _bytesTransferred = value; }
		}

		private ulong _filesTotal;

		/// <summary>
		/// Total number of files in the job
		/// </summary>
		public ulong FilesTotal
		{
			get { return _filesTotal; }
			set { _filesTotal = value; }
		}

		private ulong _filesTransferred;

		/// <summary>
		/// Total number of files that have been completely transferred. 
		/// </summary>
		public ulong FilesTransferred
		{
			get { return _filesTransferred; }
			set { _filesTransferred = value; }
		}
		public override string  ToString()
		{
 			return string.Format(
				"Bytes: {0} of {1}  Files: {2} of {3}",
				_bytesTransferred, _bytesTotal , 
				_filesTransferred, _filesTotal, 
                System.Globalization.CultureInfo.CurrentCulture.TextInfo);
		}

	}

}

