/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Interop
 File Name:CopyError.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using BitsDownloadMgr.Interop;

namespace BitsDownloadMgr.Interop
{
	public sealed class  CopyError:IDisposable
	{
		private IBackgroundCopyError _nativeError;
		internal CopyError(IBackgroundCopyError nativeError)
		{
			_nativeError = nativeError; 
		}

		//TODO: Implement properties for IBackgroundCopyError 

		public string Description
		{
			get
			{
				string errDesc = "";
				_nativeError.GetErrorDescription((uint)1033   , out errDesc);
				return errDesc; 
			}
		}

		#region CleanUp Code 
		#region IDisposable Members

		void IDisposable.Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this); 
		}
			
		#endregion

		private void Dispose(bool disposing)
		{
			if (_nativeError != null)
			{
				System.Runtime.InteropServices.Marshal.ReleaseComObject(_nativeError); 
			}
		}

		~CopyError()
		{
			Dispose(false); 
		}
		#endregion 
	}
}

