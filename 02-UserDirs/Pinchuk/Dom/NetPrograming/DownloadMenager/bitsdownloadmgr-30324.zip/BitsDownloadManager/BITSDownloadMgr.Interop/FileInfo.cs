/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.Interop
 File Name:FileInfo.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using BitsDownloadMgr.Interop;


namespace BitsDownloadMgr.Interop
{
	/// <summary>
	/// Details information about a file in a job
	/// </summary>
	/// <remarks>
	/// Wrapper class for _BG_FILE_INFO Structure.  
	/// </remarks>
	public class FileInfo
	{
		//private _BG_FILE_INFO _nativeFileInfo; 
		internal FileInfo(_BG_FILE_INFO nativeObject)
		{
			RemoteName = nativeObject.RemoteName;
			LocalName = nativeObject.LocalName; 
		}
		public FileInfo(string remoteName, string localName)
		{
			LocalName = localName;
			RemoteName = remoteName; 
		}

		private string _remoteName;

		public string RemoteName
		{
			get { return _remoteName; }
			private set { _remoteName = value; }
		}

		private string _localName;

		public string LocalName
		{
			get { return _localName; }
			private set { _localName = value; }
		}

		internal _BG_FILE_INFO GetNativeFileInfo()
		{
			_BG_FILE_INFO info;
			info.LocalName = this.LocalName;
			info.RemoteName = this.RemoteName;
			return info; 
		}

	}
}

