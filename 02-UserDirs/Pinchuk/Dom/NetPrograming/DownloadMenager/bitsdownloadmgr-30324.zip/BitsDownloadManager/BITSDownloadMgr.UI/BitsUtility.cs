/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.UI
 File Name:BitsUtility.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using BitsDownloadMgr.Interop;
using System.Windows.Forms; 

namespace BitsDownloadMgr.UI
{
    internal static class BitsUtility
	{
		private static CopyManager _copyManager = new CopyManager();

        /// <summary>
        /// Global instance of the CopyManager for the current process.
        /// </summary>
        public static CopyManager CopyManager
		{
			get
			{
				return _copyManager;
			}
		}
        public static void showBitsError(System.Runtime.InteropServices.COMException ex, string addlInfo)
        {
            MessageBox.Show("The operation failed with HResult " + ex.ErrorCode.ToString("X") + "\n" + addlInfo); 
        }
	}
}

