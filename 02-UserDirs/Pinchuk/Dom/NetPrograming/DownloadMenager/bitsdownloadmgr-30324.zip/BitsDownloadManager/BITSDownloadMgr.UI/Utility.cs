/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.UI
 File Name:Utility.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Windows.Forms; 
namespace BitsDownloadMgr.UI
{
    static class Utility
    {
        public static IFormatProvider NumberFormatProvider
        {
            get
            {
                return CultureInfo.CurrentCulture.NumberFormat;
            }
        }
        public static bool IsRightToLeft
        {
            get
            {
                return CultureInfo.CurrentCulture.TextInfo.IsRightToLeft;
            }
        }
        public static DialogResult ShowMessageBox(string Message, string Title)
        {
            return ShowMessageBox(Message, Title, MessageBoxButtons.OK, MessageBoxIcon.Information); 
        }
        public static DialogResult ShowMessageBox(string Message, string Title, MessageBoxButtons Buttons, MessageBoxIcon Icon)
        {
            return MessageBox.Show(
                Message, Title, Buttons, Icon, MessageBoxDefaultButton.Button1,
                IsRightToLeft ? MessageBoxOptions.RightAlign & MessageBoxOptions.RtlReading : 0);
        }
    }
}

