/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.UI
 File Name:CreatorSettings.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using BitsDownloadMgr.Jobs;


namespace BitsDownloadMgr.UI
{
	static class CreatorSettings
	{
		public static List<JobCreator> GetJobCreators()
		{
			List<JobCreator> creatorList = new List<JobCreator>(); 
			//TODO: this should be dynamic.  
			
			foreach (string jobCreatorClassName in Properties.Settings.Default.JobCreators)
			{
                try
                {
                    JobCreator dirJobCreator = new JobCreator(jobCreatorClassName);
                    creatorList.Add(dirJobCreator);
                }
                catch (ArgumentException)
                {
                    //type could not be created ... skip for now.  
                }
			}

			

			return creatorList; 
		}
	}
    /// <summary>
    /// Wrapper representing the job creators registered with the application.
    /// </summary>
	class JobCreator:ICreateJob
	{
		public JobCreator(string className)
		{
			_className = className; 
			//create an instance of the class to get the other information. 

			System.Type jobType = GetJobCreatorType();
            if (jobType == null)
            {
                throw new ArgumentException("Type could not be created"); 
            }
			ICreateJob jobCreator = (ICreateJob)Activator.CreateInstance(jobType);
			_description = jobCreator.Description;
			_helpText = jobCreator.HelpText; 
		}
		private string _className;

		public string ClassName
		{
			get { return _className;}
		}

		public Type GetJobCreatorType()
		{
			return Type.GetType(this._className); 
		}


        #region ICreateJob Members

        public BitsDownloadMgr.Interop.CopyJob CreateJob(BitsDownloadMgr.Interop.CopyManager manager, System.Windows.Forms.IWin32Window ownerWindow)
        {
            ICreateJob jobCreator = (ICreateJob)Activator.CreateInstance(this.GetJobCreatorType());
            return jobCreator.CreateJob(manager, ownerWindow);
        }
        private string _description;

        public string Description
        {
            get { return _description; }
        }

        private string _helpText;

        public string HelpText
        {
            get { return _helpText; }
        }
        #endregion

	}
}

