/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.UI
 File Name:SettingsForm.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BitsDownloadMgr.UI
{
    internal partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
        }

        private void SettingsForm_Load(object sender, EventArgs e)
        {
            BitsDownloadMgr.UI.Properties.BytesDisplayOption[] units = 
                (BitsDownloadMgr.UI.Properties.BytesDisplayOption[])Enum.GetValues(typeof(BitsDownloadMgr.UI.Properties.BytesDisplayOption)); 
            
            foreach(BitsDownloadMgr.UI.Properties.BytesDisplayOption unit in units)
            {
                bytesDisplayUnit.Items.Add(unit); 
            }
            bytesDisplayUnit.SelectedItem = BitsDownloadMgr.UI.Properties.Settings.Default.BytesDisplay; 
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            BitsDownloadMgr.UI.Properties.Settings.Default.BytesDisplay =
                (BitsDownloadMgr.UI.Properties.BytesDisplayOption)bytesDisplayUnit.SelectedItem;
            BitsDownloadMgr.UI.Properties.Settings.Default.Save(); 
        }
    }
}
