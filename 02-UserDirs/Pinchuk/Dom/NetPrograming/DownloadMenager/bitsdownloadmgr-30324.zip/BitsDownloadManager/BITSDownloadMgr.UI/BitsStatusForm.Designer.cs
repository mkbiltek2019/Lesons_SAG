/***********************************************************************************************************
============================================================================================================
 Bits Download Manager
 http://www.codeplex.com/BITSDownloadMgr

 Component:BITSDownloadMgr.UI
 File Name:BitsStatusForm.Designer.cs
 
 
============================================================================================================
 Copyright (C) 2004-2007 Microsoft Corporation

 This source is subject to the Microsoft Public License (Ms-PL).
 See http:www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
 All other rights reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
 OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
 LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
 FITNESS FOR A PARTICULAR PURPOSE.
============================================================================================================
***********************************************************************************************************/

namespace BitsDownloadMgr.UI
{
    internal partial class BitsStatusForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
                _jobList.Dispose(); 
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BitsStatusForm));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.jobListView = new System.Windows.Forms.ListView();
            this.displayName = new System.Windows.Forms.ColumnHeader();
            this.description = new System.Windows.Forms.ColumnHeader();
            this.jobState = new System.Windows.Forms.ColumnHeader();
            this.jobPriority = new System.Windows.Forms.ColumnHeader();
            this.bytesProgress = new System.Windows.Forms.ColumnHeader();
            this.filesProgress = new System.Windows.Forms.ColumnHeader();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.resumeJobToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmJobToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pauseJobToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelJobToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.priorityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foregroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.fileListView = new System.Windows.Forms.ListView();
            this.remoteNameColumn = new System.Windows.Forms.ColumnHeader();
            this.localNameColumn = new System.Windows.Forms.ColumnHeader();
            this.bytesTransferredColumn = new System.Windows.Forms.ColumnHeader();
            this.percentCompleteColumn = new System.Windows.Forms.ColumnHeader();
            this.label2 = new System.Windows.Forms.Label();
            this.standardToolStrip = new System.Windows.Forms.ToolStrip();
            this.newJobDropDown = new System.Windows.Forms.ToolStripDropDownButton();
            this.refreshView = new System.Windows.Forms.ToolStripButton();
            this.optionsButton = new System.Windows.Forms.ToolStripButton();
            this.jobControlStrip = new System.Windows.Forms.ToolStrip();
            this.resumeJob = new System.Windows.Forms.ToolStripButton();
            this.confirmJob = new System.Windows.Forms.ToolStripButton();
            this.pauseJob = new System.Windows.Forms.ToolStripButton();
            this.cancelJob = new System.Windows.Forms.ToolStripButton();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.currentTransferRate = new System.Windows.Forms.ToolStripStatusLabel();
            this.avgTransferRate = new System.Windows.Forms.ToolStripStatusLabel();
            this.jobProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.standardToolStrip.SuspendLayout();
            this.jobControlStrip.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.splitContainer1);
            resources.ApplyResources(this.toolStripContainer1.ContentPanel, "toolStripContainer1.ContentPanel");
            resources.ApplyResources(this.toolStripContainer1, "toolStripContainer1");
            this.toolStripContainer1.Name = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.jobControlStrip);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.standardToolStrip);
            // 
            // splitContainer1
            // 
            resources.ApplyResources(this.splitContainer1, "splitContainer1");
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.jobListView);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.fileListView);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            // 
            // jobListView
            // 
            resources.ApplyResources(this.jobListView, "jobListView");
            this.jobListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.displayName,
            this.description,
            this.jobState,
            this.jobPriority,
            this.bytesProgress,
            this.filesProgress});
            this.jobListView.ContextMenuStrip = this.contextMenuStrip1;
            this.jobListView.GridLines = true;
            this.jobListView.HideSelection = false;
            this.jobListView.MultiSelect = false;
            this.jobListView.Name = "jobListView";
            this.jobListView.UseCompatibleStateImageBehavior = false;
            this.jobListView.View = System.Windows.Forms.View.Details;
            this.jobListView.SelectedIndexChanged += new System.EventHandler(this.jobListView_selectedIndexChanged);
            // 
            // displayName
            // 
            resources.ApplyResources(this.displayName, "displayName");
            // 
            // description
            // 
            resources.ApplyResources(this.description, "description");
            // 
            // jobState
            // 
            resources.ApplyResources(this.jobState, "jobState");
            // 
            // jobPriority
            // 
            resources.ApplyResources(this.jobPriority, "jobPriority");
            // 
            // bytesProgress
            // 
            resources.ApplyResources(this.bytesProgress, "bytesProgress");
            // 
            // filesProgress
            // 
            resources.ApplyResources(this.filesProgress, "filesProgress");
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resumeJobToolStripMenuItem,
            this.confirmJobToolStripMenuItem,
            this.pauseJobToolStripMenuItem,
            this.cancelJobToolStripMenuItem,
            this.priorityToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            // 
            // resumeJobToolStripMenuItem
            // 
            this.resumeJobToolStripMenuItem.Image = global::BitsDownloadMgr.UI.Properties.Resources.ResumeJob;
            resources.ApplyResources(this.resumeJobToolStripMenuItem, "resumeJobToolStripMenuItem");
            this.resumeJobToolStripMenuItem.Name = "resumeJobToolStripMenuItem";
            this.resumeJobToolStripMenuItem.Click += new System.EventHandler(this.doResumeJob);
            // 
            // confirmJobToolStripMenuItem
            // 
            this.confirmJobToolStripMenuItem.Image = global::BitsDownloadMgr.UI.Properties.Resources.ConfirmJob;
            resources.ApplyResources(this.confirmJobToolStripMenuItem, "confirmJobToolStripMenuItem");
            this.confirmJobToolStripMenuItem.Name = "confirmJobToolStripMenuItem";
            this.confirmJobToolStripMenuItem.Click += new System.EventHandler(this.doCompleteJob);
            // 
            // pauseJobToolStripMenuItem
            // 
            this.pauseJobToolStripMenuItem.Image = global::BitsDownloadMgr.UI.Properties.Resources.PauseJob;
            resources.ApplyResources(this.pauseJobToolStripMenuItem, "pauseJobToolStripMenuItem");
            this.pauseJobToolStripMenuItem.Name = "pauseJobToolStripMenuItem";
            this.pauseJobToolStripMenuItem.Click += new System.EventHandler(this.doResumeJob);
            // 
            // cancelJobToolStripMenuItem
            // 
            this.cancelJobToolStripMenuItem.Image = global::BitsDownloadMgr.UI.Properties.Resources.CancelJob;
            resources.ApplyResources(this.cancelJobToolStripMenuItem, "cancelJobToolStripMenuItem");
            this.cancelJobToolStripMenuItem.Name = "cancelJobToolStripMenuItem";
            this.cancelJobToolStripMenuItem.Click += new System.EventHandler(this.doJobCancel);
            // 
            // priorityToolStripMenuItem
            // 
            this.priorityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.foregroundToolStripMenuItem,
            this.highToolStripMenuItem,
            this.normalToolStripMenuItem,
            this.lowToolStripMenuItem});
            resources.ApplyResources(this.priorityToolStripMenuItem, "priorityToolStripMenuItem");
            this.priorityToolStripMenuItem.Name = "priorityToolStripMenuItem";
            // 
            // foregroundToolStripMenuItem
            // 
            this.foregroundToolStripMenuItem.Name = "foregroundToolStripMenuItem";
            resources.ApplyResources(this.foregroundToolStripMenuItem, "foregroundToolStripMenuItem");
            this.foregroundToolStripMenuItem.Tag = "0";
            this.foregroundToolStripMenuItem.Click += new System.EventHandler(this.priorityItemClicked);
            // 
            // highToolStripMenuItem
            // 
            this.highToolStripMenuItem.Name = "highToolStripMenuItem";
            resources.ApplyResources(this.highToolStripMenuItem, "highToolStripMenuItem");
            this.highToolStripMenuItem.Tag = "1";
            this.highToolStripMenuItem.Click += new System.EventHandler(this.priorityItemClicked);
            // 
            // normalToolStripMenuItem
            // 
            this.normalToolStripMenuItem.Name = "normalToolStripMenuItem";
            resources.ApplyResources(this.normalToolStripMenuItem, "normalToolStripMenuItem");
            this.normalToolStripMenuItem.Tag = "2";
            this.normalToolStripMenuItem.Click += new System.EventHandler(this.priorityItemClicked);
            // 
            // lowToolStripMenuItem
            // 
            this.lowToolStripMenuItem.Name = "lowToolStripMenuItem";
            resources.ApplyResources(this.lowToolStripMenuItem, "lowToolStripMenuItem");
            this.lowToolStripMenuItem.Tag = "3";
            this.lowToolStripMenuItem.Click += new System.EventHandler(this.priorityItemClicked);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // fileListView
            // 
            resources.ApplyResources(this.fileListView, "fileListView");
            this.fileListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.remoteNameColumn,
            this.localNameColumn,
            this.bytesTransferredColumn,
            this.percentCompleteColumn});
            this.fileListView.GridLines = true;
            this.fileListView.HideSelection = false;
            this.fileListView.MultiSelect = false;
            this.fileListView.Name = "fileListView";
            this.fileListView.UseCompatibleStateImageBehavior = false;
            this.fileListView.View = System.Windows.Forms.View.Details;
            // 
            // remoteNameColumn
            // 
            resources.ApplyResources(this.remoteNameColumn, "remoteNameColumn");
            // 
            // localNameColumn
            // 
            resources.ApplyResources(this.localNameColumn, "localNameColumn");
            // 
            // bytesTransferredColumn
            // 
            resources.ApplyResources(this.bytesTransferredColumn, "bytesTransferredColumn");
            // 
            // percentCompleteColumn
            // 
            resources.ApplyResources(this.percentCompleteColumn, "percentCompleteColumn");
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // standardToolStrip
            // 
            resources.ApplyResources(this.standardToolStrip, "standardToolStrip");
            this.standardToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newJobDropDown,
            this.refreshView,
            this.optionsButton});
            this.standardToolStrip.Name = "standardToolStrip";
            // 
            // newJobDropDown
            // 
            this.newJobDropDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newJobDropDown.Image = global::BitsDownloadMgr.UI.Properties.Resources.NewCopyJob;
            resources.ApplyResources(this.newJobDropDown, "newJobDropDown");
            this.newJobDropDown.Name = "newJobDropDown";
            // 
            // refreshView
            // 
            this.refreshView.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.refreshView.Image = global::BitsDownloadMgr.UI.Properties.Resources.RefreshView;
            resources.ApplyResources(this.refreshView, "refreshView");
            this.refreshView.Name = "refreshView";
            this.refreshView.Click += new System.EventHandler(this.doRefreshView);
            // 
            // optionsButton
            // 
            this.optionsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.optionsButton.Image = global::BitsDownloadMgr.UI.Properties.Resources.Options;
            resources.ApplyResources(this.optionsButton, "optionsButton");
            this.optionsButton.Name = "optionsButton";
            this.optionsButton.Click += new System.EventHandler(this.optionsButton_Click);
            // 
            // jobControlStrip
            // 
            resources.ApplyResources(this.jobControlStrip, "jobControlStrip");
            this.jobControlStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resumeJob,
            this.confirmJob,
            this.pauseJob,
            this.cancelJob});
            this.jobControlStrip.Name = "jobControlStrip";
            // 
            // resumeJob
            // 
            this.resumeJob.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.resumeJob.Image = global::BitsDownloadMgr.UI.Properties.Resources.ResumeJob;
            resources.ApplyResources(this.resumeJob, "resumeJob");
            this.resumeJob.Name = "resumeJob";
            this.resumeJob.Click += new System.EventHandler(this.doResumeJob);
            // 
            // confirmJob
            // 
            this.confirmJob.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.confirmJob.Image = global::BitsDownloadMgr.UI.Properties.Resources.ConfirmJob;
            resources.ApplyResources(this.confirmJob, "confirmJob");
            this.confirmJob.Name = "confirmJob";
            this.confirmJob.Click += new System.EventHandler(this.doCompleteJob);
            // 
            // pauseJob
            // 
            this.pauseJob.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pauseJob.Image = global::BitsDownloadMgr.UI.Properties.Resources.PauseJob;
            resources.ApplyResources(this.pauseJob, "pauseJob");
            this.pauseJob.Name = "pauseJob";
            this.pauseJob.Click += new System.EventHandler(this.doJobPause);
            // 
            // cancelJob
            // 
            this.cancelJob.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cancelJob.Image = global::BitsDownloadMgr.UI.Properties.Resources.CancelJob;
            resources.ApplyResources(this.cancelJob, "cancelJob");
            this.cancelJob.Name = "cancelJob";
            this.cancelJob.Click += new System.EventHandler(this.doJobCancel);
            // 
            // BottomToolStripPanel
            // 
            resources.ApplyResources(this.BottomToolStripPanel, "BottomToolStripPanel");
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(0);
            // 
            // TopToolStripPanel
            // 
            resources.ApplyResources(this.TopToolStripPanel, "TopToolStripPanel");
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(0);
            // 
            // RightToolStripPanel
            // 
            resources.ApplyResources(this.RightToolStripPanel, "RightToolStripPanel");
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(0);
            // 
            // LeftToolStripPanel
            // 
            resources.ApplyResources(this.LeftToolStripPanel, "LeftToolStripPanel");
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(0);
            // 
            // ContentPanel
            // 
            resources.ApplyResources(this.ContentPanel, "ContentPanel");
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentTransferRate,
            this.avgTransferRate,
            this.jobProgressBar});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            // 
            // currentTransferRate
            // 
            resources.ApplyResources(this.currentTransferRate, "currentTransferRate");
            this.currentTransferRate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.currentTransferRate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.currentTransferRate.Name = "currentTransferRate";
            // 
            // avgTransferRate
            // 
            resources.ApplyResources(this.avgTransferRate, "avgTransferRate");
            this.avgTransferRate.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.avgTransferRate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.avgTransferRate.Name = "avgTransferRate";
            // 
            // jobProgressBar
            // 
            this.jobProgressBar.Name = "jobProgressBar";
            resources.ApplyResources(this.jobProgressBar, "jobProgressBar");
            this.jobProgressBar.Step = 2;
            this.jobProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            // 
            // BitsStatusForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStripContainer1);
            this.Name = "BitsStatusForm";
            this.Load += new System.EventHandler(this.BitsStatusForm_Load);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.standardToolStrip.ResumeLayout(false);
            this.standardToolStrip.PerformLayout();
            this.jobControlStrip.ResumeLayout(false);
            this.jobControlStrip.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
		private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
		private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
		private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
		private System.Windows.Forms.ToolStripContentPanel ContentPanel;
		private System.Windows.Forms.ToolStrip standardToolStrip;
		private System.Windows.Forms.ToolStripDropDownButton newJobDropDown;
		private System.Windows.Forms.ToolStripContainer toolStripContainer1;
		private System.Windows.Forms.ToolStripButton refreshView;
		private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ToolStrip jobControlStrip;
		private System.Windows.Forms.ToolStripButton resumeJob;
		private System.Windows.Forms.ToolStripButton pauseJob;
        private System.Windows.Forms.ToolStripButton cancelJob;
        private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel currentTransferRate;
        private System.Windows.Forms.ToolStripStatusLabel avgTransferRate;
        private System.Windows.Forms.ToolStripProgressBar jobProgressBar;
        private System.Windows.Forms.ListView jobListView;
        private System.Windows.Forms.ColumnHeader displayName;
        private System.Windows.Forms.ColumnHeader description;
        private System.Windows.Forms.ColumnHeader bytesProgress;
        private System.Windows.Forms.ColumnHeader filesProgress;
        private System.Windows.Forms.ColumnHeader jobState;
        private System.Windows.Forms.ColumnHeader jobPriority;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem priorityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem foregroundToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumeJobToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pauseJobToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelJobToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton confirmJob;
        private System.Windows.Forms.ToolStripMenuItem confirmJobToolStripMenuItem;
        private System.Windows.Forms.ListView fileListView;
        private System.Windows.Forms.ColumnHeader remoteNameColumn;
        private System.Windows.Forms.ColumnHeader localNameColumn;
        private System.Windows.Forms.ColumnHeader bytesTransferredColumn;
        private System.Windows.Forms.ColumnHeader percentCompleteColumn;
        private System.Windows.Forms.ToolStripButton optionsButton;
	}
}
