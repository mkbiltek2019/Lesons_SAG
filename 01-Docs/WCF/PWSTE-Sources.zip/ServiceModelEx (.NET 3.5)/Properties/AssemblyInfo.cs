﻿// © 2010 IDesign Inc. 
//Questions? Comments? go to 
//http://www.idesign.net

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AssemblyTitle("ServiceModelEx")]
[assembly: AssemblyCompany("IDesign Inc.")]
[assembly: AssemblyProduct("ServiceModelEx")]
[assembly: AssemblyCopyright("IDesign Inc. 2010")]
[assembly: AssemblyVersion("4.0.0.0")]