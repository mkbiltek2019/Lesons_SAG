﻿//2010 IDesign Inc. 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.ObjectModel;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Reflection;
using System.Diagnostics;


namespace ServiceModelEx
{
   [AttributeUsage(AttributeTargets.Class)]
   public class GenericResolverBehaviorAttribute : Attribute,IServiceBehavior
   {
      void IServiceBehavior.AddBindingParameters(ServiceDescription serviceDescription,ServiceHostBase serviceHostBase,Collection<ServiceEndpoint> endpoints,BindingParameterCollection bindingParameters)
      {}

      void IServiceBehavior.ApplyDispatchBehavior(ServiceDescription serviceDescription,ServiceHostBase serviceHostBase)
      {}

      void IServiceBehavior.Validate(ServiceDescription serviceDescription,ServiceHostBase serviceHostBase)
      {
         if(Process.GetCurrentProcess().ProcessName == "w3wp")
         {
            if(Assembly.GetEntryAssembly() == null)
            {
               foreach(ProcessModule module in Process.GetCurrentProcess().Modules)
               {
                  if(module.ModuleName.StartsWith("App_Code.") && module.ModuleName.EndsWith(".dll"))
                  {
                     GenericResolverInstaller.CallingAssembly = Assembly.LoadFrom(module.FileName);
                     break;
                  }
               }
            }
         }
         ServiceHost host = serviceHostBase as ServiceHost;
         host.AddGenericResolver();
      }
   }
}