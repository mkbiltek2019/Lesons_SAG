﻿//2010 IDesign Inc.
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.ServiceModel;
using System.ServiceModel.Description;


namespace ServiceModelEx
{
   public static class GenericResolverInstaller
   {
      internal static Assembly CallingAssembly;

      [MethodImpl(MethodImplOptions.NoInlining)]
      public static void AddGenericResolver(this ServiceHost host,params Type[] typesToResolve)
      {
         if(CallingAssembly == null)
         {
            CallingAssembly = Assembly.GetEntryAssembly() ?? Assembly.GetCallingAssembly();
            VerifyAssembly(CallingAssembly);
         }
         Trace.WriteLine("Found assembly: " + CallingAssembly.FullName);

         Debug.Assert(host.State != CommunicationState.Opened);

         foreach(ServiceEndpoint endpoint in host.Description.Endpoints)
         {
            AddGenericResolver(endpoint,typesToResolve);
         }
      }
      [MethodImpl(MethodImplOptions.NoInlining)]
      public static void AddGenericResolver<T>(this ClientBase<T> proxy,params Type[] typesToResolve) where T : class
      {
         if(CallingAssembly == null)
         {
            CallingAssembly = Assembly.GetEntryAssembly() ?? Assembly.GetCallingAssembly();
            VerifyAssembly(CallingAssembly);
         }
         Trace.WriteLine("Found assembly: " + CallingAssembly.FullName);

         Debug.Assert(proxy.State != CommunicationState.Opened);
         AddGenericResolver(proxy.Endpoint,typesToResolve);
      }
      [MethodImpl(MethodImplOptions.NoInlining)]
      public static void AddGenericResolver<T>(this ChannelFactory<T> factory,params Type[] typesToResolve) where T : class
      {
         if(CallingAssembly == null)
         {
            CallingAssembly = Assembly.GetEntryAssembly() ?? Assembly.GetCallingAssembly();
            VerifyAssembly(CallingAssembly);
         }

         Debug.Assert(factory.State != CommunicationState.Opened);
         AddGenericResolver(factory.Endpoint,typesToResolve);
      }

      static void VerifyAssembly(Assembly assembly)
      {
         if(assembly == null) 
         {
            throw new InvalidOperationException();
         }

         if(CallingAssembly.FullName == typeof(ServiceHost).Assembly.FullName) 
         {
            throw new InvalidOperationException();
         }

         if(CallingAssembly.FullName == typeof(GenericResolverInstaller).Assembly.FullName)
         {
            throw new InvalidOperationException();          
         }
         Trace.WriteLine("Found assembly: " + assembly);
      }
      static void AddGenericResolver(ServiceEndpoint endpoint,Type[] typesToResolve)
      {
         foreach(OperationDescription operation in endpoint.Contract.Operations)
         {
            DataContractSerializerOperationBehavior behavior = operation.Behaviors.Find<DataContractSerializerOperationBehavior>();
            GenericResolver newResolver;

            if(typesToResolve == null || typesToResolve.Any() == false)
            {
               newResolver = new GenericResolver();
            }
            else
            {
               newResolver = new GenericResolver(typesToResolve);
            }

            GenericResolver oldResolver = behavior.DataContractResolver as GenericResolver;
            behavior.DataContractResolver = GenericResolver.Merge(oldResolver,newResolver);
         }
      }
   }
 }


   



