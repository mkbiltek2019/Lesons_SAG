// � 2010 IDesign Inc. 
//Questions? Comments? go to 
//http://www.idesign.net


using System;
using System.Windows.Forms;

namespace CredentialsServiceHost
{
   public partial class HostForm : Form
   {
      public HostForm()
      {
         InitializeComponent();
      }
   }
}