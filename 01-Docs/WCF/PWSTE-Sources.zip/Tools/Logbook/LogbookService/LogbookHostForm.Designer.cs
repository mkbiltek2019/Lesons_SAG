// � 2010 IDesign Inc. 
//Questions? Comments? go to 
//http://www.idesign.net

namespace LogbookService
{
   partial class LogbookHostForm
   {
      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.SuspendLayout();
         // 
         // LogbookHostForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(292,273);
         this.Name = "LogbookHostForm";
         this.Text = "LogbookHostForm";
         this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
         this.ResumeLayout(false);

      }

      #endregion
   }
}