﻿// © 2010 IDesign Inc. 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;


class MyService : IMyContract
{
   public void MyMethod()
   {}
}